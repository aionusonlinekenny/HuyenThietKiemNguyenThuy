-- Author:	Kinnox;
-- Date:	28-05-2021
-- Functions: Support Test;
Include("\\script\\lib\\admin\\point.lua");
Include("\\script\\lib\\admin\\char.lua");
Include("\\script\\lib\\admin\\gm_action.lua");
Include("\\script\\lib\\admin\\item.lua");
Include("\\script\\lib\\admin\\role.lua");
Include("\\script\\lib\\admin\\tool.lua");
Include("\\script\\lib\\admin\\equip.lua");
Include("\\script\\lib\\admin\\movemap.lua");
Include("\\script\\lib\\tasklib.lua");
function main(nNpcIndex)
	local nW,nX,nY = GetWorldPos()
	local szHello = "<color=red>H� Th�ng:<color> <color=orange>Cu�c s�ng n�y bi�t bao �i�u tu�i ��p, ��i hi�p xin h�y b�nh t�nh suy x�t\n<color=green>T�a �� hi�n t�i: B�n ��: "..nW.." - X: "..nX.."-Y: "..nY.."\n"..nW.." - X: "..(nX*32).."-Y: "..(nY*32)..""
	Tab_inSert = {
	"C�c lo�i �i�m/GM_Char",
	"Trang b� xanh./PL_BlueEquip",
	"Chi�n m�./GM_GetHorse",
	"M�t n�./PL_Mask",
	"Trang bi Ho�ng Kim c� b�n./PL_BasicGoldEquip",
	"Trang b� ho�ng kim m�n ph�i VIP/PL_PremiumGoldEquip",
	"M� r�ng r��ng/ExPandBox",
	"Ta kh�ng c�n ng��i d�y b�o/no",
	}
	Say(szHello,getn(Tab_inSert),Tab_inSert);
end;
