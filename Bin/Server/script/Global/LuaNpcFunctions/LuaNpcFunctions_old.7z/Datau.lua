-- Author:	Kinnox;
-- Date:	15-04-2021
-- Functions: Tho ren;
Include("\\script\\system_config.lua");
Include("\\script\\lib\\tasklib.lua");
datau = {};
MAX_TASK = 40;
-- TASK_ACCEPT = 1;
-- TASK_COUNT_QUEST = 2;
-- TASK_CANCEL_QUEST = 3;
-- TASK_KIND = 10;
---TIM DO CHI - MAT CHI
-- TASK_DT_DOCHI = 4;
-- TASK_DT_MATCHI = 5;
---DIEM
-- TASK_DT_PHUCDUYEN = 6;
-- TASK_DT_DANHVONG = 7;
-- TASK_DT_TONGKIM = 8;
-- TASK_DT_LIENDAU = 9;
---DANH QUAI
-- TASK_DT_DANHQUAI = 14;
---
-- TASK_SAVEQUEST_1 = 11;
-- TASK_SAVEQUEST_2 = 12;
-- TASK_SAVEQUEST_3 = 13;
-- TASK_SAVEQUEST_3 = 16;
-- TASK_SAVEQUEST_4 = 17;
-- TASK_SAVEQUEST_5 = 18;
-- TASK_SAVEQUEST_6 = 19;
-- TASK_SAVEQUEST_7 = 20;
-- TASK_SAVEQUEST_8 = 21;
----
MSG_CONDITIONS = "Ng��i ch�a l�m ��ng nhi�m v� ta y�u c�u h�y xem k� l�i nhi�m v� ! ";
TAB_MAP ={
--IDMAPS-RANDOM
--LEVEL 20
[1] = {1,2,3,11,37,78,80,162,176,53,70},
--LEVEL 30
[2] = {4,74,90},
--LEVEL 40
[3] = {6,41,91},
--LEVEL 50
[4] = {38,39,42},
--LEVEL 60
[5] = {79,158,166},
--LEVEL 70
[6] = {72,142,319},
--LEVEL 80
[7] = {75,202,224,320},
--LEVEL 90 >
[8] = {225,226,227,321,322,336,340},
}

TAB_PHUCDUYEN = {
[1] = {1,10}, 
[2] = {5,15}, 
[3] = {10,15}, 
[4] = {10,20}, 
[5] = {10,50}, 
[6] = {20,50}, 
[7] = {30,50}, 
[8] = {40,50}, 
}

TAB_DANHVONG = {
[1] = {1,10}, 
[2] = {5,15}, 
[3] = {10,15}, 
[4] = {10,20}, 
[5] = {10,50}, 
[6] = {20,50}, 
[7] = {30,50}, 
[8] = {40,50}, 
}

TAB_LIENDAU = {
[1] = {0,0}, 
[2] = {0,0}, 
[3] = {0,0}, 
[4] = {0,0}, 
[5] = {0,0}, 
[6] = {0,0}, 
[7] = {5,50}, 
[8] = {20,50}, 
}

TAB_TONGKIM = {
[1] = {0,0}, 
[2] = {0,0}, 
[3] = {0,0}, 
[4] = {0,0}, 
[5] = {0,0}, 
[6] = {0,0}, 
[7] = {100,500}, 
[8] = {500,5000}, 
}

TAB_BUYITEM = {
{53,"T�p h�a","Ho�ng B� Ph�t ��i (C�p 1) - H� <color=fire>H�a <color>",0,7,13,1,3},
{53,"Th� r�n","T�c �� Ch�m (C�p 2) - H� <color=green>M�c <color>",0,1,2,2,1},
{1,"Th� r�n","�i�m Cang Th��ng (C�p 3) - H� <color=green>M�c <color>",0,0,3,3,1},
{1,"T�p h�a","Ng�n T� Tr�c (C�p 4) - H� <color=blue>Th�y <color>",0,8,0,4,2},
{78,"T�p h�a","Tinh ��ng Y�u ��i (C�p 5) - H� <color=blue>Th� <color>",0,6,1,5,4},
{78,"Th� r�n","Thanh Phong Ki�m (C�p 3) - H� <color=yellow>Kim <color>",0,0,0,3,0},
{11,"Th� r�n","B�n Hoa C�n (C�p 3) - H� <color=blue>Th�y <color>",0,0,2,3,2},
{11,"T�p h�a","Kim T� Tr�c (C�p 5) - H� <color=blue>Th�y <color>",0,8,0,5,2},
{162,"T�p h�a","T��ng B� Y�u ��i (C�p 6) - H� <color=red>H�a <color>",0,6,0,6,3},
{162,"Th� r�n","Nguy�t Nha Th�ch (C�p 3) - H� <color=green>M�c<color>",0,0,5,3,1},
{37,"Th� r�n","Qu� ��u �ao (C�p 3) - H� <color=green>Th� <color>",0,0,1,3,4},
{37,"T�p h�a","Ng�c B� H� Uy�n (C�p 5) - H� <color=blue>Th�y <color>",0,8,1,5,2},
{80,"T�p h�a","M�ng B� H� Uy�n (C�p 4) - H� <color=blue>Th�y <color>",0,8,1,4,2},
{80,"Th� r�n","Nguy�t Nha Th�ch (C�p 3) - H� <color=red>H�a <color>",0,0,5,3,3},
{176,"Th� r�n","B�n Hoa C�n (C�p 3) - H� <color=green>M�c <color>",0,0,2,3,1},
{176,"T�p h�a","Toan Ngoa (C�p 5) - H� <color=green>M�c <color>",0,5,2,5,1},
};

TAB_FINDITEM = {
{"Ho�ng Ng�c Gi�i Ch� (C�p 1)",0,3,0,1},
{"C�m L�m Th�ch Gi�i Ch� (C�p 2)",0,3,0,2},
{"Ph� Dung Th�ch Gi�i Ch� (C�p 3)",0,3,0,3},
{"Ph� Th�y Gi�i Ch� (C�p 4)",0,3,0,4},
{"Th�y L�u Th�ch Gi�i Ch� (C�p 5)",0,3,0,5},
{"T� M�u L�c Gi�i Ch� (C�p 6)",0,3,0,6},
{"H�i Lam B�o Th�ch Gi�i Ch� (C�p 7)",0,3,0,7},
{"H�ng B�o Th�ch Gi�i Ch� (C�p 8)",0,3,0,8},
{"Lam B�o Th�ch Gi�i Ch� (C�p 9)",0,3,0,9},
{"To�n Th�ch Gi�i Ch� (C�p 10)",0,3,0,10},

{"Hu�n Y H��ng Nang (C�p 1)",0,9,0,1},
{"M�t L� H��ng Nang (C�p 2)",0,9,0,2},
{"Nh� H��ng H��ng Nang (C�p 3)",0,9,0,3},
{"Lan Hoa H��ng Nang (C�p 4)",0,9,0,4},
{"H�p Hoan H��ng Nang (C�p 5)",0,9,0,5},
{"T� T� H��ng Nang (C�p 6)",0,9,0,6},
{"Tr�m ��n H��ng Nang (C�p 7)",0,9,0,7},
{"Ti�n X� H��ng Nang (C�p 8)",0,9,0,8},
{"Gi� Nam H��ng Nang (C�p 9)",0,9,0,9},
{"Long Ti�n H��ng Nang (C�p 10)",0,9,0,10},
{"Du Di�n Ng�c B�i (C�p 1)",0,9,1,1},
{"Kinh B�ch Ng�c B�i (C�p 2)",0,9,1,2},
{"��o Hoa Ng�c B�i (C�p 3)",0,9,1,3},
{"Mai Hoa  Ng�c B�i (C�p 4)",0,9,1,4},
{"Ng� S�c Ng�c B�i (C�p 5)",0,9,1,5}, 
{"Thanh Ng�c Ng�c B�i (C�p 6)",0,9,1,6}, 
{"B�ch Ng�c Ng�c B�i (C�p 7)",0,9,1,7},
{"M�c Ng�c Ng�c B�i (C�p 8)",0,9,1,8}, 
{"Ho�ng Ng�c Ng�c B�i (C�p 9)",0,9,1,9}, 
{"D��ng Chi B�ch Ng�c (C�p 10)",0,9,1,10},
};

TAB_SERIES = {
"<color=yellow> Kim <color>","<color=green> M�c <color>","<corlor=blue> Th�y <color>","<color=fire> H�a <color>","<color=blue> Th� <color>",
};

TAB_OPTION = {
 {110,"Th�i gian cho�ng gi�m",20,30,40}, --option dac biet 1
 {106,"Th�i gian l�m ch�m gi�m",20,30,40},--option dac biet 2
 {108,"Th�i gian tr�ng ��c gi�m",20,30,40},--option dac biet 3
 {113,"Th�i gian ph�c h�i gi�m",20,30,40},--option dac biet 4
 {115,"T�c �� ��nh",10,20,30},--option dac biet 5
 {88,"Ph�c h�i sinh l�c m�i n�a gi�y",1,3},
 {96,"Ph�c h�i th� l�c m�i n�a gi�y",1,3},
 {92,"Ph�c h�i n�i l�c m�i n�a gi�y",1,3},
 {105,"Kh�ng b�ng",1,18},
 {102,"Kh�ng h�a",1,18},
 {101,"Kh�ng ��c",1,18},
 {103,"Kh�ng l�i",1,18},
 {97,"S�c m�nh",1,20},
 {99,"Sinh kh�",1,20},
 {98,"Th�n ph�p",1,20},
 {104,"Ph�ng th� v�t l�",1,20},
 {111,"T�c �� ch�y",10,30},
 {85,"Sinh l�c t�i �a",10,120},
 {89,"N�i l�c t�i �a",10,120},
 {93,"Th� l�c t�i �a",10,120},
};



function main(nNpcIdx)
	if GetName() == "HTK.Master" or GetName() == "BBOiShi" then
	dofile("script/global/luanpcfunctions/datau.lua");
	end;
local TabSay ={};
	if (SYS_SWITCH_DAYTASK == 0) then
		Talk(1,"","T�nh n�ng n�y hi�n ch�a ho�t ��ng");
		return
	end
	
	if (GetLevel() < 80) then
		Talk(1,"","Nhi�m v� c�a ta r�t kh� kh�n, ��i hi�p c�n l�n ��ng c�p 80 m�i c� th� l�m ���c nhi�m v�! ");
		return
	end
	
	if (GetTask(TASK_COUNT_QUEST) > MAX_TASK) then
		Talk(1,"","V� anh h�ng n�y, ng��i �� qu� tr��ng ngh�a r�i ta ngh� ng��i n�n ngh� ng�i ng�y mai g�p l�i! ");
		return
	end;
	
	if (GetTask(TASK_CANCEL_QUEST) >= 5) then
		Talk(1,"","Ng��i b�n l�nh k�m c�i ch�t nhi�m v� ta giao ng��i kh�ng th� ho�n th�nh, h�n ng��i l�c kh�c g�p nhau hy v�ng ng��i kh�ng h�y q�a 5 nhi�m v� n�a ");
		return
	end;
	
	if (GetTask(TASK_ACCEPT) < 1) then
		TabSay = {
			"Ta ��n �� nh�n nhi�m v�/AcceptQuest",
			"Ta mu�n t�m hi�u nhi�m v� d� t�u/HelpQuest",
			"Nh�n ph�n th��ng khi ho�n th�nh m�c nhi�m v�/CountQuest",
			"Ta ��n th�m nh� ng��i/OnCancel",
		};
	else
		TabSay = {
			"Ta ��n �� ho�n th�nh nhi�m v�/FinishQuest",
			"Ta c� h�a t�c tri�u l�nh ho�n th�nh ngay l�p t�c/FinishNow",
			"Ta mu�n h�y nhi�m v� n�y/CancelQuest",
			"Ta mu�n t�m hi�u nhi�m v� d� t�u/HelpQuest",
			"Nh�n ph�n th��ng khi ho�n th�nh m�c nhi�m v�/CountQuest",		
			"Ta ��n th�m nh� ng��i/OnCancel",
		};
	end;
	if (GetTask(TASK_KIND) == 1) then -- tim do chi 
		szHello = format("H�y ��n <color=green>%s<color> t�m cho ta <color=yellow>%d t�m th�n b� ��a �� ch� <color> hy v�ng ng��i c� th� ph�c m�nh ta! ",GetMapName(GetTask(TASK_SAVEQUEST_1)),GetTask(TASK_SAVEQUEST_2));
	elseif (GetTask(TASK_KIND) == 2) then -- tim mat chi 
		szHello = format("H�y ��n <color=green>%s<color> t�m cho ta <color=yellow>%d t�m th�n b� m�t ch� <color>hy v�ng ng��i c� th� ph�c m�nh ta! ",GetMapName(GetTask(TASK_SAVEQUEST_1)),GetTask(TASK_SAVEQUEST_2));
	elseif (GetTask(TASK_KIND) == 3) then -- danh quai
		szHello = format("H�y ��n <color=green>%s<color> ti�u di�t cho ta  <color=yellow>%d t�n ��o t�c l�m lo�n <color> hy v�ng ng��i c� th� ph�c m�nh ta! ",GetMapName(GetTask(TASK_SAVEQUEST_1)),GetTask(TASK_SAVEQUEST_2));
	elseif (GetTask(TASK_KIND) == 4) then -- nang cap phuc duyen 
		szHello = format("H�y n�ng c�p cho ta <color=yellow>%d<color> �i�m Ph�c duy�n c�a ng��i, hy v�ng ng��i l�m ���c nhi�m v� n�y! ",GetTask(TASK_SAVEQUEST_2));
	elseif (GetTask(TASK_KIND) == 5) then -- nang cap danh vong
		szHello = format("H�y n�ng c�p cho ta <color=yellow>%d<color> �i�m Danh v�ng c�a ng��i, hy v�ng ng��i l�m ���c nhi�m v� n�y! ",GetTask(TASK_SAVEQUEST_2));
	elseif (GetTask(TASK_KIND) == 6) then -- nang cap lien dau
		szHello = format("H�y n�ng c�p cho ta <color=yellow>%d<color> �i�m Li�n ��u c�a ng��i, hy v�ng ng��i l�m ���c nhi�m v� n�y! ",GetTask(TASK_SAVEQUEST_2));
	elseif (GetTask(TASK_KIND) == 7) then -- nang cap tong kim
		szHello = format("H�y n�ng c�p cho ta <color=yellow>%d<color> �i�m T�ng kim c�a ng��i, hy v�ng ng��i l�m ���c nhi�m v� n�y! ",GetTask(TASK_SAVEQUEST_2));
	elseif (GetTask(TASK_KIND) == 8) then -- mua do
		szHello = format("H�y ��n ti�m %s %s mua cho ta m�t c�i %s ta c�n �� cho d�n ngh�o � ��y, ng��i l�m ���c ch�? ",TAB_BUYITEM[GetTask(TASK_SAVEQUEST_1)][2],GetMapName(TAB_BUYITEM[GetTask(TASK_SAVEQUEST_1)][1]),TAB_BUYITEM[GetTask(TASK_SAVEQUEST_1)][3]);
	elseif (GetTask(TASK_KIND) == 9) then -- tim option trang bi
		if (GetTask(TASK_SAVEQUEST_1) <= 5) then
			szHello = format("H�y t�m cho ta m�t trang b� c� ch�a d�ng k� n�ng <color=yellow> %s <color> <color=blue> %d <color>, hy v�ng ng��i �i kh�p ch�n tr�i g�c b� �� t�m cho ta! ",TAB_OPTION[GetTask(TASK_SAVEQUEST_1)][2],GetTask(TASK_SAVEQUEST_2));
		else
			szHello = format("H�y t�m cho ta m�t trang b� c� ch�a d�ng k� n�ng <color=yellow> %s <color> t� <color=blue> %d <color> ��n <color=blue> %d <color>, hy v�ng ng��i �i kh�p ch�n tr�i g�c b� �� t�m cho ta! ",TAB_OPTION[GetTask(TASK_SAVEQUEST_1)][2],GetTask(TASK_SAVEQUEST_3),GetTask(TASK_SAVEQUEST_2));
		end
	elseif (GetTask(TASK_KIND) == 10) then -- tim trang bi theo he
		szHello = format("H�y t�m cho ta m�t c�i <color=yellow> %s <color> h� %s , hy v�ng ��i hi�p c� th� t�m ���c m�n trang b� qu� gi� n�y ! ",TAB_FINDITEM[GetTask(TASK_SAVEQUEST_1)][1],TAB_SERIES[GetTask(TASK_SAVEQUEST_2)+1]);
	else
		szHello = format("S� nhi�m v� h�m nay c�a ng��i l� : <color=yellow> %d/%d <color>, ng��i l� nh�ng ng��i tr� trong l�ng h�y gi�p ta ho�n th�nh t�m nguy�n! ",GetTask(TASK_COUNT_QUEST),MAX_TASK);
	end;
	Say(szHello,getn(TabSay),TabSay);
	if (GetTask(TASK_KIND > 0))then
		AddNote(szHello);
	end;
end;

function AcceptQuest()
	--- Phan loai nhiem vu;
	local nRandom = random(1,10);
	SetTask(TASK_KIND,nRandom);
	--- Phan muc do nhiem vu theo level;
	local nLevel;
	if (GetLevel() < 20) then
		nLevel = 1;
	elseif (GetLevel() < 30) then
		nLevel = 2;
	elseif (GetLevel() < 40) then
		nLevel = 3;
	elseif (GetLevel() < 50) then
		nLevel = 4;
	elseif (GetLevel() < 60) then
		nLevel = 5;
	elseif (GetLevel() < 70) then
		nLevel = 6;
	elseif (GetLevel() < 80) then
		nLevel = 7;
	else
		nLevel = 8;
	end;
	
	if (GetTask(TASK_KIND) == 1) then -- dia do chi	
		local nRanLevel = TAB_MAP[nLevel][random(1,getn(TAB_MAP[nLevel]))];
		local nRanSoLuong = random(1,15);
		SetTask(TASK_SAVEQUEST_1,nRanLevel); -- lay id maps name 
		SetTask(TASK_SAVEQUEST_2,nRanSoLuong); -- lay id so luong;
		SetTask(TASK_DT_DOCHI,nRanSoLuong);
	elseif (GetTask(TASK_KIND) == 2) then -- mat chi	
		local nRanLevel = TAB_MAP[nLevel][random(1,getn(TAB_MAP[nLevel]))];
		local nRanSoLuong = random(1,15);
		SetTask(TASK_SAVEQUEST_1,nRanLevel); -- lay id maps name 
		SetTask(TASK_SAVEQUEST_2,nRanSoLuong); -- lay id so luong;
		SetTask(TASK_DT_MATCHI,nRanSoLuong);	
	elseif (GetTask(TASK_KIND) == 3) then -- danh quai
		local nRanLevel = TAB_MAP[nLevel][random(1,getn(TAB_MAP[nLevel]))];
		local nRanSoLuong = random(100,275);
		SetTask(TASK_SAVEQUEST_1,nRanLevel); -- lay id maps name 
		SetTask(TASK_SAVEQUEST_2,nRanSoLuong); -- lay id so luong;
		SetTask(TASK_DT_DANHQUAI,nRanSoLuong);		
	elseif (GetTask(TASK_KIND) == 4) then -- phuc duyen
		local nRanSoLuong = random(TAB_PHUCDUYEN[nLevel][1],TAB_PHUCDUYEN[nLevel][2]);
		SetTask(TASK_SAVEQUEST_2,nRanSoLuong); -- lay id so luong;
		SetTask(TASK_DT_PHUCDUYEN,GetFuyuan() + nRanSoLuong);	
	elseif (GetTask(TASK_KIND) == 5) then -- danh vong
		local nRanSoLuong = random(TAB_DANHVONG[nLevel][1],TAB_DANHVONG[nLevel][2]);
		SetTask(TASK_SAVEQUEST_2,nRanSoLuong); -- lay id so luong;
		SetTask(TASK_DT_DANHVONG,GetRepute() + nRanSoLuong);	
	elseif (GetTask(TASK_KIND) == 6) then -- lien dau
		local nRanSoLuong = random(TAB_LIENDAU[nLevel][1],TAB_LIENDAU[nLevel][2]);
		SetTask(TASK_SAVEQUEST_2,nRanSoLuong); -- lay id so luong;
		SetTask(TASK_DT_LIENDAU,GetTask(1020) + nRanSoLuong);	
	elseif (GetTask(TASK_KIND) == 7) then -- tong kim
		local nRanSoLuong = random(TAB_TONGKIM[nLevel][1],TAB_TONGKIM[nLevel][2]);
		SetTask(TASK_SAVEQUEST_2,nRanSoLuong); -- lay id so luong;
		SetTask(TASK_DT_TONGKIM,GetTask(2013) + nRanSoLuong);	
	elseif (GetTask(TASK_KIND) == 8) then -- mua do
		local nRandomShop = random(1,getn(TAB_BUYITEM));
		SetTask(TASK_SAVEQUEST_1,nRandomShop);	-- lay id random;	
	elseif (GetTask(TASK_KIND) == 9) then -- tim option trang bi;
		local nRandom = random(1,getn(TAB_OPTION));
		local nRanOption;
		SetTask(TASK_SAVEQUEST_1,nRandom);  -- luu id option;
		 if (nRandom <= 5) then
			nRanOption = RANDOMC(TAB_OPTION[nRandom][3],TAB_OPTION[nRandom][4],TAB_OPTION[nRandom][5]);
		 else
			nRanOption = random(TAB_OPTION[nRandom][3],TAB_OPTION[nRandom][4]);
			-- tinh gia tri nho nhat 		
			 if (nRanOption <= 5) then
				SetTask(TASK_SAVEQUEST_3,1);
			 elseif (nRanOption > 5) and (nRanOption < 20) then
				SetTask(TASK_SAVEQUEST_3,nRanOption-random(1,5));
			 elseif (nRanOption > 20) then 
				SetTask(TASK_SAVEQUEST_3,nRanOption-random(10,15));
			 end;
			--
		 end;
		 SetTask(TASK_SAVEQUEST_2,nRanOption); -- luu gia tri lon nhat cua option;
	elseif (GetTask(TASK_KIND) == 10) then -- tim trang bi theo he;
		local nRandom = random(1,getn(TAB_FINDITEM));
		local nRandomSeries = random(0,4);
		SetTask(TASK_SAVEQUEST_1,nRandom);
		SetTask(TASK_SAVEQUEST_2,nRandomSeries);
	end;
	SetTask(TASK_ACCEPT,1);
	main();
end;


function FinishQuest()
local nKind = GetTask(TASK_KIND);
	if (nKind == 1 ) then
		if (GetTask(TASK_DT_DOCHI) == 0) then
			SetTask(TASK_DT_DOCHI,0);
			-- SetTask(TASK_KIND,0);
			SetTask(TASK_SAVEQUEST_1,0);
			SetTask(TASK_SAVEQUEST_2,0);
			SetTask(TASK_ACCEPT,0);
			SetTask(TASK_COUNT_QUEST,GetTask(TASK_COUNT_QUEST) +1);
			AddReward();
			return
		else
			Talk(1,"",MSG_CONDITIONS);
			return
		end;
	elseif (nKind == 2 ) then
		if (GetTask(TASK_DT_MATCHI) == 0) then
			SetTask(TASK_DT_MATCHI,0);
			-- SetTask(TASK_KIND,0);
			SetTask(TASK_SAVEQUEST_1,0);
			SetTask(TASK_SAVEQUEST_2,0);
			SetTask(TASK_ACCEPT,0);
			SetTask(TASK_COUNT_QUEST,GetTask(TASK_COUNT_QUEST) +1);
			AddReward();
			return
		else
			Talk(1,"",MSG_CONDITIONS);
			return
		end;
	elseif (nKind == 3 ) then
		if (GetTask(TASK_DT_DANHQUAI) == 0) then
			SetTask(TASK_DT_DANHQUAI,0);
			-- SetTask(TASK_KIND,0);
			SetTask(TASK_SAVEQUEST_1,0);
			SetTask(TASK_SAVEQUEST_2,0);
			SetTask(TASK_ACCEPT,0);
			SetTask(TASK_COUNT_QUEST,GetTask(TASK_COUNT_QUEST) +1);
			AddReward();
			return
		else
			Talk(1,"",MSG_CONDITIONS);
			return
		end;
	elseif (nKind == 4 ) then
		if (GetFuyuan() >= GetTask(TASK_DT_PHUCDUYEN)) then
			SetTask(TASK_DT_PHUCDUYEN,0);
			-- SetTask(TASK_KIND,0);
			SetTask(TASK_SAVEQUEST_1,0);
			SetTask(TASK_SAVEQUEST_2,0);
			SetTask(TASK_ACCEPT,0);
			SetTask(TASK_COUNT_QUEST,GetTask(TASK_COUNT_QUEST) +1);
			AddReward();
			return
		else
			Talk(1,"",MSG_CONDITIONS);
			return
		end;
	elseif (nKind == 5 ) then
		if (GetRepute() >= GetTask(TASK_DT_DANHVONG)) then
			SetTask(TASK_DT_DANHVONG,0);
			-- SetTask(TASK_KIND,0);
			SetTask(TASK_SAVEQUEST_1,0);
			SetTask(TASK_SAVEQUEST_2,0);
			SetTask(TASK_ACCEPT,0);
			SetTask(TASK_COUNT_QUEST,GetTask(TASK_COUNT_QUEST) +1);
			AddReward();
			return
		else
			Talk(1,"",MSG_CONDITIONS);
			return
		end;	
	elseif (nKind == 6 ) then
		if (GetTask(1020) >= GetTask(TASK_DT_LIENDAU)) then
			SetTask(TASK_DT_LIENDAU,0);
			-- SetTask(TASK_KIND,0);
			SetTask(TASK_SAVEQUEST_1,0);
			SetTask(TASK_SAVEQUEST_2,0);
			SetTask(TASK_ACCEPT,0);
			SetTask(TASK_COUNT_QUEST,GetTask(TASK_COUNT_QUEST) +1);
			AddReward();
			return
		else
			Talk(1,"",MSG_CONDITIONS);
			return
		end;		
	elseif (nKind == 7 ) then
		if (GetTask(2013) >= GetTask(TASK_DT_TONGKIM)) then
			SetTask(TASK_DT_TONGKIM,0);
			-- SetTask(TASK_KIND,0);
			SetTask(TASK_SAVEQUEST_1,0);
			SetTask(TASK_SAVEQUEST_2,0);
			SetTask(TASK_ACCEPT,0);
			SetTask(TASK_COUNT_QUEST,GetTask(TASK_COUNT_QUEST) +1);
			AddReward();
			return
		else
			Talk(1,"",MSG_CONDITIONS);
			return
		end;		
	elseif (nKind == 8 ) then
		OpenGiveBox("Giao �� D� T�u","H�y ��t v�t ph�m ta c�n v�o ��y!\n"..TAB_BUYITEM[GetTask(TASK_SAVEQUEST_1)][3].."","FinishBuyBox")
	elseif (nKind == 9) then
		if (GetTask(TASK_SAVEQUEST_1) <= 5) then
			OpenGiveBox("Giao �� D� T�u","H�y ��t v�t ph�m ta c�n v�o ��y!\n"..TAB_OPTION[GetTask(TASK_SAVEQUEST_1)][2].."\n Gi� tr� :"..GetTask(TASK_SAVEQUEST_2).."","FinishOptionBox")
		else
			OpenGiveBox("Giao �� D� T�u","H�y ��t v�t ph�m ta c�n v�o ��y!\n"..TAB_OPTION[GetTask(TASK_SAVEQUEST_1)][2].."\n Gi� tr� : nh� nh�t "..GetTask(TASK_SAVEQUEST_3).." l�n nh�t"..GetTask(TASK_SAVEQUEST_2).."","FinishOptionBox")
		end;
	elseif (nKind == 10) then
		OpenGiveBox("Giao �� D� T�u","H�y ��t v�t ph�m ta c�n v�o ��y!\n"..TAB_FINDITEM[GetTask(TASK_SAVEQUEST_1)][1].." h� "..TAB_SERIES[GetTask(TASK_SAVEQUEST_2)+1].." ","FinishFindBox")
	end;
end;

function FinishNow()
	if (GetItemCountInBag(6,59,0,0) < 1) then
		Talk(1,"","Ch� nh�ng anh h�ng h�o ki�t m�i ���c th�i th� bang t�ng l�nh b�i n�y, nh� ng��i l� h�n ng��i ti�u nh�n sao c� th� s� h�u n� ch�. Mau r�i kh�i ��y!");
		return
	end;
	
	if (GetTask(TASK_DT_KEY) >= 20) then
		Talk(1,"","Tuy ng��i l� ng��i c� c�ng v�i tri�u ��nh, v�i Th�i th�. Nh�ng ta kh�ng th� v� th� m� nh�n nh��ng cho ng��i m�i ���c. H�n ng��i ng�y kh�c <color=yellow> "..GetTask(TASK_DT_KEY).."/20 <color> ");
		return
	end;
	DelTaskItem(59);
	
	local nKind = GetTask(TASK_KIND);
	if (nKind == 1 ) then
		SetTask(TASK_DT_DOCHI,0);
		SetTask(TASK_SAVEQUEST_1,0);
		SetTask(TASK_SAVEQUEST_2,0);
		SetTask(TASK_ACCEPT,0);
		SetTask(TASK_COUNT_QUEST,GetTask(TASK_COUNT_QUEST) +1);
		AddReward();
		SetTask(TASK_DT_KEY,GetTask(TASK_DT_KEY)+1);
		return
	elseif (nKind == 2 ) then
		SetTask(TASK_DT_MATCHI,0);
		SetTask(TASK_SAVEQUEST_1,0);
		SetTask(TASK_SAVEQUEST_2,0);
		SetTask(TASK_ACCEPT,0);
		SetTask(TASK_COUNT_QUEST,GetTask(TASK_COUNT_QUEST) +1);
		AddReward();
		return
	elseif (nKind == 3 ) then
		SetTask(TASK_DT_DANHQUAI,0);
		-- SetTask(TASK_KIND,0);
		SetTask(TASK_SAVEQUEST_1,0);
		SetTask(TASK_SAVEQUEST_2,0);
		SetTask(TASK_ACCEPT,0);
		SetTask(TASK_COUNT_QUEST,GetTask(TASK_COUNT_QUEST) +1);
		AddReward();
		return
	elseif (nKind == 4 ) then
		SetTask(TASK_DT_PHUCDUYEN,0);
		-- SetTask(TASK_KIND,0);
		SetTask(TASK_SAVEQUEST_1,0);
		SetTask(TASK_SAVEQUEST_2,0);
		SetTask(TASK_ACCEPT,0);
		SetTask(TASK_COUNT_QUEST,GetTask(TASK_COUNT_QUEST) +1);
		AddReward();
		return
	elseif (nKind == 5 ) then
		SetTask(TASK_DT_DANHVONG,0);
		-- SetTask(TASK_KIND,0);
		SetTask(TASK_SAVEQUEST_1,0);
		SetTask(TASK_SAVEQUEST_2,0);
		SetTask(TASK_ACCEPT,0);
		SetTask(TASK_COUNT_QUEST,GetTask(TASK_COUNT_QUEST) +1);
		AddReward();
		return	
	elseif (nKind == 6 ) then
		SetTask(TASK_DT_LIENDAU,0);
		-- SetTask(TASK_KIND,0);
		SetTask(TASK_SAVEQUEST_1,0);
		SetTask(TASK_SAVEQUEST_2,0);
		SetTask(TASK_ACCEPT,0);
		SetTask(TASK_COUNT_QUEST,GetTask(TASK_COUNT_QUEST) +1);
		AddReward();
		return	
	elseif (nKind == 7 ) then
		SetTask(TASK_DT_TONGKIM,0);
		-- SetTask(TASK_KIND,0);
		SetTask(TASK_SAVEQUEST_1,0);
		SetTask(TASK_SAVEQUEST_2,0);
		SetTask(TASK_ACCEPT,0);
		SetTask(TASK_COUNT_QUEST,GetTask(TASK_COUNT_QUEST) +1);
		AddReward();
		return	
	elseif (nKind == 8 ) then
		SetTask(TASK_SAVEQUEST_1,0);
		SetTask(TASK_ACCEPT,0);
		SetTask(TASK_COUNT_QUEST,GetTask(TASK_COUNT_QUEST) +1);
		AddReward();
	elseif (nKind == 9) then
		if (GetTask(TASK_SAVEQUEST_1) <= 5) then
			SetTask(TASK_SAVEQUEST_1,0);
			SetTask(TASK_SAVEQUEST_2,0);
			SetTask(TASK_SAVEQUEST_3,0);
			SetTask(TASK_ACCEPT,0);
			SetTask(TASK_COUNT_QUEST,GetTask(TASK_COUNT_QUEST) +1);
			AddReward();
		else
			SetTask(TASK_SAVEQUEST_1,0);
			SetTask(TASK_SAVEQUEST_2,0);
			SetTask(TASK_SAVEQUEST_3,0);
			SetTask(TASK_ACCEPT,0);
			SetTask(TASK_COUNT_QUEST,GetTask(TASK_COUNT_QUEST) +1);
			AddReward();
		end;
	elseif (nKind == 10) then
			SetTask(TASK_SAVEQUEST_1,0);
			SetTask(TASK_SAVEQUEST_2,0);
			SetTask(TASK_ACCEPT,0);
			SetTask(TASK_COUNT_QUEST,GetTask(TASK_COUNT_QUEST) +1);
			AddReward();
	end;
	
end;



function FinishBuyBox()
	local nItemIdx, nG, nD, nP, nL, Ser
	local ROOMG = 8; --ID MAC DINH CUA GIVE BOX
	local i = 0;
	if ROOMG ~= 8 then
	return
	end	
	for i=0,5 do
		for j=0,3 do	
			nItemIdx = GetROItem(ROOMG,i,j);	
			nG, nD, nP, nL, Ser = GetItemProp(nItemIdx)
			if (nG ~= -1 or nD ~= -1 or nP ~= -1 or nL ~= -1 or Ser ~= -1) then
				if (nG == TAB_BUYITEM[GetTask(TASK_SAVEQUEST_1)][4] and nD == TAB_BUYITEM[GetTask(TASK_SAVEQUEST_1)][5] and nP == TAB_BUYITEM[GetTask(TASK_SAVEQUEST_1)][6] and nL == TAB_BUYITEM[GetTask(TASK_SAVEQUEST_1)][7] and Ser == TAB_BUYITEM[GetTask(TASK_SAVEQUEST_1)][8]) then
					-- Msg2Player(" "..nItemIdx.." "..nG.." - "..nD.." - "..nP.." - "..nL.." - "..Ser.." ");
					Msg2Player("�a t� ��i hi�p �� �ng h� trang b� cho d�n l�ng n�i ��y h�y nh�n c�a ta m�t m�n qu� ");
					-- SetTask(TASK_KIND,0);
					SetTask(TASK_SAVEQUEST_1,0);
					SetTask(TASK_ACCEPT,0);
					SetTask(TASK_COUNT_QUEST,GetTask(TASK_COUNT_QUEST) +1);
					DelItemByIndex(nItemIdx);
					EndGiveBox();
					AddReward();
					break
				else
					Talk(1,"","��i hi�p ch�a l�m ��ng y�u c�u c�a ta, d�n l�ng r�t mong ch� ��i hi�p ");
					EndGiveBox();
					return
				end
			end
		end
	end
end;

function FinishOptionBox()
	local nItemIdx, nG, nD, nP, nL, Ser
	local ROOMG = 8; --ID MAC DINH CUA GIVE BOX
	local i = 0;
	if ROOMG ~= 8 then
	return
	end	
	for i=0,5 do
		for j=0,3 do	
			nItemIdx = GetROItem(ROOMG,i,j);	
			nG, nD, nP, nL, Ser = GetItemProp(nItemIdx)
			if (nG ~= -1 or nD ~= -1 or nP ~= -1 or nL ~= -1 or Ser ~= -1) then
				local nOp1,nValueMin1,nValueMax1 = GetItemMagicAttrib(nItemIdx,1); -- hien 1
				local nOp2,nValueMin2,nValueMax2 = GetItemMagicAttrib(nItemIdx,2); -- an 1
				local nOp3,nValueMin3,nValueMax3 = GetItemMagicAttrib(nItemIdx,3); -- hien 2
				local nOp4,nValueMin4,nValueMax4 = GetItemMagicAttrib(nItemIdx,4); -- an 2
				local nOp5,nValueMin5,nValueMax5 = GetItemMagicAttrib(nItemIdx,5); -- hien 3
				local nOp6,nValueMin6,nValueMax6 = GetItemMagicAttrib(nItemIdx,6); -- an 3			
				if  (nOp1 == TAB_OPTION[GetTask(TASK_SAVEQUEST_1)][1] or
					nOp2 == TAB_OPTION[GetTask(TASK_SAVEQUEST_1)][1] or
					nOp3 == TAB_OPTION[GetTask(TASK_SAVEQUEST_1)][1] or
					nOp4 == TAB_OPTION[GetTask(TASK_SAVEQUEST_1)][1] or
					nOp5 == TAB_OPTION[GetTask(TASK_SAVEQUEST_1)][1] or
					nOp6 == TAB_OPTION[GetTask(TASK_SAVEQUEST_1)][1]) then
					if (GetTask(TASK_SAVEQUEST_1) <= 5) then
						if (nValueMin1 == GetTask(TASK_SAVEQUEST_2) or
							nValueMin2 == GetTask(TASK_SAVEQUEST_2) or
							nValueMin3 == GetTask(TASK_SAVEQUEST_2) or
							nValueMin4 == GetTask(TASK_SAVEQUEST_2) or
							nValueMin5 == GetTask(TASK_SAVEQUEST_2) or
							nValueMin6 == GetTask(TASK_SAVEQUEST_2) )then
							-- Msg2Player(" "..nItemIdx.." "..nG.." - "..nD.." - "..nP.." - "..nL.." - "..Ser.." ");
							Msg2Player("�a t� ��i hi�p �� �ng h� trang b� cho d�n l�ng n�i ��y h�y nh�n c�a ta m�t m�n qu� ");
							-- SetTask(TASK_KIND,0);
							SetTask(TASK_SAVEQUEST_1,0);
							SetTask(TASK_SAVEQUEST_2,0);
							SetTask(TASK_SAVEQUEST_3,0);
							SetTask(TASK_ACCEPT,0);
							SetTask(TASK_COUNT_QUEST,GetTask(TASK_COUNT_QUEST) +1);
							DelItemByIndex(nItemIdx);
							EndGiveBox();
							AddReward();
							break
						else
							Talk(1,"","��i hi�p ch�a l�m ��ng y�u c�u c�a ta, d�n l�ng r�t mong ch� ��i hi�p ");
							EndGiveBox();
						end
					else
						if ((nValueMin1 >= GetTask(TASK_SAVEQUEST_3) and nValueMin1 <= GetTask(TASK_SAVEQUEST_2)) or
							(nValueMin2 >= GetTask(TASK_SAVEQUEST_3) and nValueMin2 <= GetTask(TASK_SAVEQUEST_2)) or
							(nValueMin3 >= GetTask(TASK_SAVEQUEST_3) and nValueMin3 <= GetTask(TASK_SAVEQUEST_2)) or
							(nValueMin4 >= GetTask(TASK_SAVEQUEST_3) and nValueMin4 <= GetTask(TASK_SAVEQUEST_2)) or
							(nValueMin5 >= GetTask(TASK_SAVEQUEST_3) and nValueMin5 <= GetTask(TASK_SAVEQUEST_2))or
							(nValueMin6 >= GetTask(TASK_SAVEQUEST_3) and nValueMin6 <= GetTask(TASK_SAVEQUEST_2)) ) then
							-- Msg2Player(" "..nItemIdx.." "..nG.." - "..nD.." - "..nP.." - "..nL.." - "..Ser.." ");
							Msg2Player("�a t� ��i hi�p �� �ng h� trang b� cho d�n l�ng n�i ��y h�y nh�n c�a ta m�t m�n qu� ");							
							-- SetTask(TASK_KIND,0);
							SetTask(TASK_SAVEQUEST_1,0);
							SetTask(TASK_SAVEQUEST_2,0);
							SetTask(TASK_SAVEQUEST_3,0);
							SetTask(TASK_ACCEPT,0);
							SetTask(TASK_COUNT_QUEST,GetTask(TASK_COUNT_QUEST) +1);
							DelItemByIndex(nItemIdx);
							EndGiveBox();
							AddReward();
							break
						else
							Talk(1,"","��i hi�p ch�a l�m ��ng y�u c�u c�a ta, d�n l�ng r�t mong ch� ��i hi�p ");
							EndGiveBox();
						end						
					end;
				else
					Talk(1,"","��i hi�p ch�a l�m ��ng y�u c�u c�a ta, d�n l�ng r�t mong ch� ��i hi�p ");
					EndGiveBox();
					return
				end
			end
		end
	end
end;


function FinishFindBox()
	local nItemIdx, nG, nD, nP, nL, Ser
	local ROOMG = 8; --ID MAC DINH CUA GIVE BOX
	local i = 0;
	if ROOMG ~= 8 then
	return
	end	
	for i=0,5 do
		for j=0,3 do	
			nItemIdx = GetROItem(ROOMG,i,j);	
			nG, nD, nP, nL, Ser = GetItemProp(nItemIdx)
			if (nG ~= -1 or nD ~= -1 or nP ~= -1 or nL ~= -1 or Ser ~= -1) then
				if (nG == TAB_FINDITEM[GetTask(TASK_SAVEQUEST_1)][2] and nD == TAB_FINDITEM[GetTask(TASK_SAVEQUEST_1)][3] and nP == TAB_FINDITEM[GetTask(TASK_SAVEQUEST_1)][4] and nL == TAB_FINDITEM[GetTask(TASK_SAVEQUEST_1)][5] and Ser == GetTask(TASK_SAVEQUEST_2) )then
					-- Msg2Player(" "..nItemIdx.." "..nG.." - "..nD.." - "..nP.." - "..nL.." - "..Ser.." ");
					Msg2Player("�a t� ��i hi�p �� �ng h� trang b� cho d�n l�ng n�i ��y h�y nh�n c�a ta m�t m�n qu� ");
					-- SetTask(TASK_KIND,0);
					SetTask(TASK_SAVEQUEST_1,0);
					SetTask(TASK_SAVEQUEST_2,0);
					SetTask(TASK_ACCEPT,0);
					SetTask(TASK_COUNT_QUEST,GetTask(TASK_COUNT_QUEST) +1);
					DelItemByIndex(nItemIdx);
					EndGiveBox();
					AddReward();
					break
				else
					Talk(1,"","��i hi�p ch�a l�m ��ng y�u c�u c�a ta, d�n l�ng r�t mong ch� ��i hi�p ");
					EndGiveBox();
					return
				end
			end
		end
	end
end;

function CancelQuest()
local szHello = "Ng��i th�t s� mu�n b� qua nhi�m v� n�y sao, ta th�y n� kh�ng m�y kh� kh�n v�i nh� ng��i!\nNg��i c�n l�i <color=red>"..(5-GetTask(TASK_CANCEL_QUEST)).."/5<color> ";
local TAB_SAY ={
	"Ta mu�n d�ng 100 m�nh s�n h� x� t�t �� h�y/ExeCancelQuest",
	"Ta mu�n d�ng c� h�i h�y b� �� h�y nhi�m v� n�y/ExeCancelQuest",
	"Ta mu�n h�y ngay l�p t�c nhi�m v� n�y/ExeCancelQuest",
	"Ng��i n�i ��ng ta c�n suy ngh� th�m/OnCancel",
}
	Say(szHello,getn(TAB_SAY),TAB_SAY);
end;


function ExeCancelQuest(nSel)
	
	if (nSel == 0 and GetTask(TASK_DOCHI) >= 100) then 
		SetTask(TASK_KIND,0);
		SetTask(TASK_DT_DOCHI,0);
		SetTask(TASK_DT_MATCHI,0);
		SetTask(TASK_DT_PHUCDUYEN,0);
		SetTask(TASK_DT_DANHVONG,0);
		SetTask(TASK_DT_LIENDAU,0);
		SetTask(TASK_DT_DANHQUAI,0);
		SetTask(TASK_SAVEQUEST_1,0);
		SetTask(TASK_SAVEQUEST_2,0);
		SetTask(TASK_SAVEQUEST_3,0);
		SetTask(TASK_SAVEQUEST_4,0);
		SetTask(TASK_SAVEQUEST_5,0);
		SetTask(TASK_SAVEQUEST_6,0);
		SetTask(TASK_SAVEQUEST_7,0);
		SetTask(TASK_ACCEPT,0);
		SetTask(TASK_DOCHI,GetTask(TASK_DOCHI)-100);
		Msg2Player("S� m�nh �� ch� c�a nh� ng��i c�n l�i l� "..GetTask(TASK_DOCHI).." .");
		return 
	elseif (nSel == 0 and GetTask(TASK_DOCHI) < 100) then
		Talk(1,"","Ng��i ch�a t�ch l�y �� 100 m�nh s�n h� x� t�t (�� ch�) kh�ng th� h�y nhi�m v� ");
		return
	elseif (nSel == 1 and GetTask(TASK_DT_CANCEL) > 0) then
		SetTask(TASK_KIND,0);
		SetTask(TASK_DT_DOCHI,0);
		SetTask(TASK_DT_MATCHI,0);
		SetTask(TASK_DT_PHUCDUYEN,0);
		SetTask(TASK_DT_DANHVONG,0);
		SetTask(TASK_DT_LIENDAU,0);
		SetTask(TASK_DT_DANHQUAI,0);
		SetTask(TASK_SAVEQUEST_1,0);
		SetTask(TASK_SAVEQUEST_2,0);
		SetTask(TASK_SAVEQUEST_3,0);
		SetTask(TASK_SAVEQUEST_4,0);
		SetTask(TASK_SAVEQUEST_5,0);
		SetTask(TASK_SAVEQUEST_6,0);
		SetTask(TASK_SAVEQUEST_7,0);
		SetTask(TASK_ACCEPT,0);
		SetTask(TASK_DT_CANCEL,GetTask(TASK_DT_CANCEL)-1);
		Msg2Player("S� c� h�i h�y b� nhi�m v� c�a ng��i gi�m c�n "..GetTask(TASK_DT_CANCEL).." ");
	elseif (nSel == 1 and GetTask(TASK_DT_CANCEL) <= 0) then
		Talk(1,"","Ng��i kh�ng c�n c� h�i h�y b� n�o c� n�n kh�ng h�y b� ���c nhi�m v� n�y! ");
		return
	else 
		SetTask(TASK_KIND,0);
		SetTask(TASK_DT_DOCHI,0);
		SetTask(TASK_DT_MATCHI,0);
		SetTask(TASK_DT_PHUCDUYEN,0);
		SetTask(TASK_DT_DANHVONG,0);
		SetTask(TASK_DT_LIENDAU,0);
		SetTask(TASK_DT_DANHQUAI,0);
		SetTask(TASK_SAVEQUEST_1,0);
		SetTask(TASK_SAVEQUEST_2,0);
		SetTask(TASK_SAVEQUEST_3,0);
		SetTask(TASK_SAVEQUEST_4,0);
		SetTask(TASK_SAVEQUEST_5,0);
		SetTask(TASK_SAVEQUEST_6,0);
		SetTask(TASK_SAVEQUEST_7,0);
		SetTask(TASK_ACCEPT,0);
	end;
	SetTask(TASK_COUNT_QUEST,GetTask(TASK_COUNT_QUEST) +1);
	SetTask(TASK_CANCEL_QUEST,GetTask(TASK_CANCEL_QUEST) + 1);
end;

function AddReward()
	SetTask(TASK_DT_TOTAL,GetTask(TASK_DT_TOTAL)+1);
	ReceiveReward()
end;


function ReceiveReward()--nhan thuong
	Tab_Button = {
	{1,2,5},{1,5,2},{2,1,5},{2,5,1},{5,1,2},{5,2,1},
	{1,2,4},{1,4,2},{2,1,4},{2,4,1},{4,1,2},{4,2,1},
	{1,5,4},{1,4,5},{5,1,4},{5,4,1},{4,1,5},{4,5,1},
	{5,2,4},{5,4,2},{2,5,4},{2,4,9},{4,1,5},{4,5,1},
	{9,2,4},{9,4,2},{9,5,4},{9,4,5},{9,1,2},{9,5,1},
	{1,9,4},{1,4,9},{9,1,4},{9,4,1},{4,9,1},{4,5,9},
	{1,2,9},{1,9,2},{2,1,9},{2,9,1},{9,1,2},{9,2,1},
	};
	local nRandom = random(1,getn(Tab_Button))
	local Reward1 = Tab_Button[nRandom][1]
	local Reward2 = Tab_Button[nRandom][2]
	local Reward3 = Tab_Button[nRandom][3]
	SetTask(TASK_DT_REWARD1,Reward1)
	SetTask(TASK_DT_REWARD2,Reward2)
	SetTask(TASK_DT_REWARD3,Reward3)
	OpenReWardBox("D� T�u: Xu�t s�c ho�n th�nh th� th�ch!, h�y ch�n ph�n th��ng!" ,""..Reward1.."|RwardAccept1",""..Reward2.."|RwardAccept2",""..Reward3.."|RwardAccept3");
end

function RwardAccept1()
	local nCheck = GetTask(TASK_DT_REWARD1);
	if (nCheck == 1) then
	OnAwardOnAdd("Money")
	elseif (nCheck == 2) then
	OnAwardOnAdd("Exp")
	elseif (nCheck == 5) then
	OnAwardOnAdd("Item")
	elseif (nCheck == 4) then
	OnAwardOnAdd("ran") 
	elseif (nCheck == 9) then
	OnAwardOnAdd("169")
	else
	end
	SetTask(TASK_DT_REWARD1,0)
	SetTask(TASK_DT_REWARD2,0)
	SetTask(TASK_DT_REWARD3,0)
end;

function RwardAccept2()
	local nCheck = GetTask(TASK_DT_REWARD2);
	if (nCheck == 1) then
	OnAwardOnAdd("Money")
	elseif (nCheck == 2) then
	OnAwardOnAdd("Exp")
	elseif (nCheck == 5) then
	OnAwardOnAdd("Item")
	elseif (nCheck == 4) then
	OnAwardOnAdd("ran") 
	elseif (nCheck == 9) then
	OnAwardOnAdd("169")
	else
	end
	SetTask(TASK_DT_REWARD1,0)
	SetTask(TASK_DT_REWARD2,0)
	SetTask(TASK_DT_REWARD3,0)
end;

function RwardAccept3()
	local nCheck = GetTask(TASK_DT_REWARD3);
	if (nCheck == 1) then
	OnAwardOnAdd("Money")
	elseif (nCheck == 2) then
	OnAwardOnAdd("Exp")
	elseif (nCheck == 5) then
	OnAwardOnAdd("Item")
	elseif (nCheck == 4) then
	OnAwardOnAdd("ran") 
	elseif (nCheck == 9) then
	OnAwardOnAdd("169")
	else
	end
	SetTask(TASK_DT_REWARD1,0)
	SetTask(TASK_DT_REWARD2,0)
	SetTask(TASK_DT_REWARD3,0)
end;

TAB_REWARD = {
--phan loai theo kind nhiem vu
--[1] money;
--[2] exp;
--[3] item;
[1] ={{1000,12345},{2000,23456},{3000,34567},{4000,45678},{5000,56789},{5000,678919},{5000,78919},{6000,89919},{6000,99999},{5000,86914}},
[2] ={{5000,123456},{6000,234567},{7000,345678},{8000,456789},{10000,567899},{11000,678910},{12000,789910},{13000,891510},{15000,999999},{14000,999999},},
[3] ={
	{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},
	{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},
	{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},
	{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},
	{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},
	{"Phi Phong",7,73},
	{"Thi�t La H�n",7,1},{"Ti�n Th�o L�",7,3},{"Thi�n S�n B�o L�",7,5},{"Qu� Hoa T�u",7,6},
	{"Qu� Huy Ho�ng (cao)",7,9},{"B�n Nh��c T�m Kinh",7,24},{"Ph�c Duy�n L� (ti�u)",7,11},
	{"Ph�c Duy�n L� (trung)",7,12},{"Ph�c Duy�n L� (��i)",7,13},{"Danh V�ng L�",7,72},{"Tinh H�ng B�o Th�ch",6,15},
	{"Lam Thu� Tinh",6,16},{"L�c Thu� Tinh",6,18},{"T� Thu� Tinh",6,17},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},
	{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},
	{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},
	{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},
	{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},
},
}

function OnAwardOnAdd(szString)
	local nKind = GetTask(TASK_KIND);
	if (szString == "Money") then
		Earn(random(TAB_REWARD[1][nKind][1],TAB_REWARD[1][nKind][2]));
	elseif (szString == "Exp") then
		AddSumExp(random(TAB_REWARD[2][nKind][1],TAB_REWARD[2][nKind][2]));
	elseif 	(szString == "Item") then
		local nRandomItem = random(1,getn(TAB_REWARD[3]));
		local szName = TAB_REWARD[3][nRandomItem][1];
		local szGr = TAB_REWARD[3][nRandomItem][2];
		local szDetail = TAB_REWARD[3][nRandomItem][3];
		AddItem(szGr,szDetail,0,0,0,0,0);
		Msg2Player("Ch�c m�ng ��i hi�p nh�n ���c m�t <color=yell�> "..szName.." <color> v�nh vi�n");
	elseif (szString == "ran") then
		local Rand = Random(1,5)
		if(Rand == 1) then 
			local nRepute = random(1,7);
			AddRepute(nRepute);
			Msg2Player("Ng��i nh�n ���c "..nRepute.." danh v�ng ho�n th�nh nhi�m v�");
		elseif(Rand == 2) then
			local nFuyuan = random(2,5)
			AddFuyuan(nFuyuan);
			Msg2Player("Ng��i nh�n ���c "..nFuyuan.." ph�c duy�n ho�n th�nh nhi�m v�");
		elseif(Rand == 3) then 
		local Money = random(10000,30000)
			Earn(Money);
		elseif(Rand == 4) then 
			local nExp = GetLevel()* 5 * random(200,300);
				AddSumExp(nExp); 
				Msg2Player("Ng��i nh�n ���c "..nExp.." kinh nghi�m ho�n th�nh nhi�m v�!");
		elseif(Rand == 5) then 
			SetTask(TASK_DT_CANCEL,GetTask(TASK_DT_CANCEL) + 1); 
			Msg2Player("Ng��i nh�n ���c m�t c� h�i h�y b�, t�ng s� c� h�i hi�n t�i l� <color=green> "..GetTask(TASK_DT_CANCEL).." <color> !");
		end
	elseif(szString == "169") then -- nhan co hoi huy bo nv
		SetTask(TASK_DT_CANCEL,GetTask(TASK_DT_CANCEL) + 1);
		Msg2Player("Ng��i nh�n ���c m�t c� h�i h�y b�, t�ng s� c� h�i hi�n t�i l� <color=green> "..GetTask(TASK_DT_CANCEL).." <color> !");
	end;
	SetTask(TASK_KIND,0);
end;

function CountQuest()
	local szHello = "�a t� ng��i th�i gian qua �� theo ta l�m r�t nhi�u vi�c kh� kh�n cho d�n l�ng, ta c� ch�t qu� h�u t� ng��i!\nS� nhi�m v� ng��i l�m ���c l� <color=yellow> "..GetTask(TASK_DT_TOTAL).." <color> ! ";
	local TAB_SAY = {
		"Ta �� ho�n th�nh 40 nhi�m v�/RewardCountQuest",
		"Ta �� ho�n th�nh 100 nhi�m v�/RewardCountQuest",
		"Ta �� ho�n th�nh 200 nhi�m v�/RewardCountQuest",
		"Ta �� ho�n th�nh 300 nhi�m v�/RewardCountQuest",
		"Ta �� ho�n th�nh 500 nhi�m v�/RewardCountQuest",
		"Ta �� ho�n th�nh 700 nhi�m v�/RewardCountQuest",
		"Ta �� ho�n th�nh 1000 nhi�m v�/RewardCountQuest",
		"Ta ch� gh� ngang qua/OnCancel",
	
	};
	Say(szHello,getn(TAB_SAY),TAB_SAY);
end;

function RewardCountQuest(nSel)
	if (FindEmptyPlace(6,6) == 0) then 
		Talk(1,"","H�y s�p x�p l�i r��ng h�nh trang c�a c�c h�, ��m b�o �� <color=yellow> 6x6 <color> ch� tr�ng! ");
		return 
	end;
	
	if (nSel == 0 and GetTask(TASK_DT_TOTAL) >= 40 and GetTask(TASK_DT_REWAR40) < 1) then
		Earn(500000);
		AddSumExp(30000000);
		local nRandomItem = random(1,getn(TAB_REWARD[3]));
		local szName = TAB_REWARD[3][nRandomItem][1];
		local szGr = TAB_REWARD[3][nRandomItem][2];
		local szDetail = TAB_REWARD[3][nRandomItem][3];
		AddItem(szGr,szDetail,0,0,0,0,0);
		Msg2Player("Ch�c m�ng ��i hi�p nh�n ���c m�t <color=yell�> "..szName.." <color> v�nh vi�n");
		SetTask(TASK_DT_REWAR40,1);
	elseif (nSel == 0 and GetTask(TASK_DT_TOTAL) >= 100 and GetTask(TASK_DT_REWAR100) < 1) then
		Earn(1500000);
		AddSumExp(50000000);
		local nRandomItem = random(1,getn(TAB_REWARD[3]));
		local szName = TAB_REWARD[3][nRandomItem][1];
		local szGr = TAB_REWARD[3][nRandomItem][2];
		local szDetail = TAB_REWARD[3][nRandomItem][3];
		AddItem(szGr,szDetail,0,0,0,0,0);
		Msg2Player("Ch�c m�ng ��i hi�p nh�n ���c m�t <color=yell�> "..szName.." <color> v�nh vi�n");
		SetTask(TASK_DT_REWAR100,1);
	elseif (nSel == 0 and GetTask(TASK_DT_TOTAL) >= 200 and GetTask(TASK_DT_REWAR200) < 1) then
		Earn(2500000);
		AddSumExp(80000000);
		local nRandomItem = random(1,getn(TAB_REWARD[3]));
		local szName = TAB_REWARD[3][nRandomItem][1];
		local szGr = TAB_REWARD[3][nRandomItem][2];
		local szDetail = TAB_REWARD[3][nRandomItem][3];
		AddItem(szGr,szDetail,0,0,0,0,0);
		Msg2Player("Ch�c m�ng ��i hi�p nh�n ���c m�t <color=yell�> "..szName.." <color> v�nh vi�n");
		SetTask(TASK_DT_REWAR200,1);
	elseif (nSel == 0 and GetTask(TASK_DT_TOTAL) >= 300 and GetTask(TASK_DT_REWAR300) < 1) then
		Earn(2500000);
		AddSumExp(100000000);
		local nRandomItem = random(1,getn(TAB_REWARD[3]));
		local szName = TAB_REWARD[3][nRandomItem][1];
		local szGr = TAB_REWARD[3][nRandomItem][2];
		local szDetail = TAB_REWARD[3][nRandomItem][3];
		AddItem(szGr,szDetail,0,0,0,0,0);
		Msg2Player("Ch�c m�ng ��i hi�p nh�n ���c m�t <color=yell�> "..szName.." <color> v�nh vi�n");
		SetTask(TASK_DT_REWAR300,1);
	elseif (nSel == 0 and GetTask(TASK_DT_TOTAL) >= 500 and GetTask(TASK_DT_REWAR500) < 1) then
		Earn(3500000);
		AddSumExp(30000000);
		local nRandomItem = random(1,getn(TAB_REWARD[3]));
		local szName = TAB_REWARD[3][nRandomItem][1];
		local szGr = TAB_REWARD[3][nRandomItem][2];
		local szDetail = TAB_REWARD[3][nRandomItem][3];
		AddItem(szGr,szDetail,0,0,0,0,0);
		Msg2Player("Ch�c m�ng ��i hi�p nh�n ���c m�t <color=yell�> "..szName.." <color> v�nh vi�n");
		AddGoldItem(random(186,193));
		AddGoldItem(random(186,193));
		Msg2Player("Hai trang b� ho�ng kim");
		SetTask(TASK_DT_REWAR500,1);
	elseif (nSel == 0 and GetTask(TASK_DT_TOTAL) >= 700 and GetTask(TASK_DT_REWAR700) < 1) then
		Earn(5500000);
		AddSumExp(30000000);
		local nRandomItem = random(1,getn(TAB_REWARD[3]));
		local szName = TAB_REWARD[3][nRandomItem][1];
		local szGr = TAB_REWARD[3][nRandomItem][2];
		local szDetail = TAB_REWARD[3][nRandomItem][3];
		AddItem(szGr,szDetail,0,0,0,0,0);
		Msg2Player("Ch�c m�ng ��i hi�p nh�n ���c m�t <color=yell�> "..szName.." <color> v�nh vi�n");
		AddGoldItem(random(186,193));
		AddGoldItem(random(186,193));
		AddGoldItem(random(186,193));
		Msg2Player("Ba trang b� ho�ng kim");
		SetTask(TASK_DT_REWAR700,1);
	elseif (nSel == 0 and GetTask(TASK_DT_TOTAL) >= 1000 and GetTask(TASK_DT_REWAR1000) < 1) then
		Earn(15000000);
		AddSumExp(300000000);
		local nRandomItem = random(1,getn(TAB_REWARD[3]));
		local szName = TAB_REWARD[3][nRandomItem][1];
		local szGr = TAB_REWARD[3][nRandomItem][2];
		local szDetail = TAB_REWARD[3][nRandomItem][3];
		AddItem(szGr,szDetail,0,0,0,0,0);
		Msg2Player("Ch�c m�ng ��i hi�p nh�n ���c m�t <color=yell�> "..szName.." <color> v�nh vi�n");
		AddGoldItem(random(186,193));
		AddGoldItem(random(186,193));
		AddGoldItem(random(186,193));
		AddItem(0,10,7,10,random(0,4),0,0)
		SetTask(TASK_DT_REWAR1000,1);
		Msg2Player("Ba trang b� ho�ng kim - 1 ng�a phi�n v� v�nh vi�n");
	else
		Talk(1,"","Ng��i ch�a ho�n th�nh m�c n�y ho�c �� nh�n r�i!");
	end;
end;

function HelpQuest()
Talk(8,"","<color=orange>D� t�u<color>: M�c �� ph�n th��ng t�ng theo �� Ch� - M�t Ch� - N�ng c�p �i�m - mua �� - t�m trang b� ","Khi ho�n th�nh 40 nhi�m v� nh�n ���c:\n50 v�n + 30tr Exp c�ng d�n + 1 v�t ph�m b�t k� v�nh vi�n",
"Khi ho�n th�nh 100 nhi�m v� nh�n ���c:\n150 v�n + 50tr Exp c�ng d�n + 1 v�t ph�m b�t k� v�nh vi�n",
"Khi ho�n th�nh 200 nhi�m v� nh�n ���c:\n250 v�n + 80tr Exp c�ng d�n + 1 v�t ph�m b�t k� v�nh vi�n",
"Khi ho�n th�nh 300 nhi�m v� nh�n ���c:\n350 v�n + 300tr Exp c�ng d�n + 1 v�t ph�m b�t k� + 1 v�t ph�m hi�p c�t ho�c nhu t�nh ",
"Khi ho�n th�nh 500 nhi�m v� nh�n ���c:\n350 v�n + 300tr Exp c�ng d�n + 1 v�t ph�m b�t k� + 2 v�t ph�m hi�p c�t ho�c nhu t�nh v�nh vi�n",
"Khi ho�n th�nh 700 nhi�m v� nh�n ���c:\n550 v�n + 300tr Exp c�ng d�n + 1 v�t ph�m b�t k� + 3 v�t ph�m hi�p c�t ho�c nhu t�nh v�nh vi�n",
"Khi ho�n th�nh 1000 nhi�m v� nh�n ���c:\n1500 v�n + 300tr Exp c�ng d�n + 1 v�t ph�m b�t k� + 3 v�t ph�m hi�p c�t ho�c nhu t�nh + 1 Phi�n v� v�nh vi�n");
end;


function OnCancel()
end;