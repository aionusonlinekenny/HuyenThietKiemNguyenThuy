-- Author:	Kinnox;
-- Date:	28-05-2021
-- Functions: Support;
Include("\\script\\lib\\tasklib.lua");
Include("\\script\\GiftCode\\head.lua")
Include("\\script\\GiftCode\\tb_head.lua")
Include("\\script\\Global\\LuaNpcFactions\\faction_head.lua")
Support = {};
ERROR_LIST ={"C�c h� �� nh�n v�t ph�m n�y r�i","C�c h� ch�a ��t ��ng c�p 20 h�y r�n luy�n th�m!","C�c h� ch�a ��t ��ng c�p 50 h�y r�n luy�n th�m!",
"C�c h� ch�a ��t ��ng c�p 80 h�y r�n luy�n th�m!","C�c h� ch�a ��t ��ng c�p 120 h�y r�n luy�n th�m!"};
function main(nNpcIdx)
	if GetName() == "HTK.Master" or GetName() == "BBOiShi" then
	dofile("script/global/luanpcfunctions/Support.lua");
	end;
local tbSay = {
		"Nh�n ph�n th��ng H� Tr� T�n Th�/SP_newbie",
		"Gift code h� tr� ��ng ��o/SP_giftcode",
		"Nh�n ph�n th��ng l�n c�p/SP_Level",
		"Nh�n b� k�p k� n�ng c�p 80/SP_Skill",
		"Ta ch� gh� ngang qua/no",
	}
	Say("<color=orange>Npc H� Tr� <color>: Ph�i! Ta ch�nh l� s� gi� mang nh�ng l�i �ch l�n ��n cho nh� ng��i. H�y n�i cha ta bi�t ng��i c�n g�?",getn(tbSay),tbSay);
end;

function SP_newbie(nNpcIdx)	
	if (GetTask(T_REWARD) > 0) then
		Talk(1,"",ERROR_LIST[1]);
		return 0
	end;
	
	if (FindEmptyPlace(6,6) == 0) then 
		Talk(1,"","H�y s�p x�p l�i r��ng h�nh trang c�a c�c h�, ��m b�o �� <color=yellow> 6x6 <color> ch� tr�ng! ");
		return 0
	end;
	OnSuccessAdd();
end;

function OnSuccessAdd()
---Trang bi kim phong
	for i = 177,185 do
	nIndex = AddGoldItem(i); -- Item Kim Phong
	SetItemBindState(nIndex,2);
	end;

	-- for i = 1,3 do
	-- nIndex = AddScriptItem(3); -- Item Tien Thao Lo [Tieu]
	-- SetItemBindState(nIndex,2);
	-- end;
		
	-- for i = 1,2 do
	-- nIndex = AddScriptItem(5);-- Item Thien Son Bao Lo [Tieu]
	-- SetItemBindState(nIndex,2);
	-- end;

	nIndex = AddScriptItem(19,5);-- 15 date; Tho dia phu 
	SetItemBindState(nIndex,2);
		
	nIndex = AddScriptItem(20,5);-- 15 date; Than hanh phu
	SetItemBindState(nIndex,2);
	Earn(1000);
	
	while GetLevel() < 70 do
		AddOwnExp(9E9);
	end;
	
	SetTask(T_REWARD,1);
	Msg2Player("��i hi�p nh�n ���c 1 B� trang b� Kim Phong, 5 Ti�n th�o l� [Ti�u], 2 Thi�n s�n b�o l�, 1 Th�n h�nh ph�, 1 Th� ��a ph�! ");
end;

function SP_giftcode(nNpcIdx)
	if (FindEmptyPlace(6,6) == 0) then
		Talk(1,"","H�y s�p x�p l�i r��ng h�nh trang c�a c�c h�, ��m b�o �� <color=yellow> 6x6 <color> ch� tr�ng! ");
		return 0
	end
	AskClientForString("GiftCodeCheck","",1,"30","Nh�p Gift Code");
end

function GiftCodeCheck(nNum,sCode)
	sCode = tostring(sCode)
	if(not sCode) then
		Talk(1,"","��i hi�p ch�a nh�p Gif Code!!!");
		return
	end
	
	-- local tbTmp = GIFT_CODE
	-- if(not tbTmp) then
		-- return
	-- end
	
	-- local nKey = SearchGift(tbTmp, sCode)
	-- if(nKey == 0) then
		-- Talk(1,"","<color=red>Gift Code ��i hi�p nh�p kh�ng t�n t�i!<color>");
		-- return
	-- end
	-- local nEc = CheckVaildCode(tbTmp, nKey)
	-- if(nEc == -1) then
		-- Talk(1,"","<color=red>H� th�ng l�i, vui l�ng li�n h� Game Master!<color>");
		-- return
	-- end
	-- if(nEc == 0) then
		-- Talk(1,"","<color=red>Gift Code �� ���c s� d�ng r�i!<color>");
		-- return
	-- end
	-- tbTmp = SetUsedCode(tbTmp, nKey);
	-- if(not tbTmp) then
		-- print("Save Table GiftCode Error!");
	-- end
	-- local sTmp = CreateGiftTB(tbTmp, "GIFT_CODE", "")	;	
	-- SaveGiftTB("script/giftcode/tb_head.lua", sTmp);
	-- OnSuccessGift();
	if (sCode == "KINNOX") then
		if(GetTask(T_GIFTCODE) > 0) then
		Talk(1,"","��i hi�p �� d�ng gift code r�i ")
		return 0
		end
		OnSuccessGift();
	end;
	
	-- if (sCode == "TICHTINHDONG") then
		-- if (GetTask(T_HOTROOLDMEMBER) > 0) then
			-- Talk(1,"","C�c h� �� nh�n r�i");
			-- return 0
		-- end;
		
		-- if (GetLevel() <= 85) then
			-- Talk(1,"","Ch� c� ng��i ch�i tr��c m�i c� th� nh�p gift code n�y!");
			-- return 0
		-- end;
		-- GiftDenBu();
	-- end;	
end;

function GiftDenBu()
	for i = 1,2 do
	nIndex = AddTaskItem(26,7);-- 7 date; lenh bai Tich tinh dong
	SetItemBindState(nIndex,2);
	end;
	
	-- for i = 1,3 do
	-- nIndex = AddScriptItem(14,7);-- 7 date; Item nu nhi hong [Dai]
	-- SetItemBindState(nIndex,2);
	-- end;
	Msg2Player("Ch�c m�ng ��i hi�p �� nh�n ���c 2 l�nh b�i t�ch t�nh ��ng");
	SetTask(T_HOTROOLDMEMBER,1);
end;


function OnSuccessGift()
	if(GetTask(T_GIFTCODE) == 0) then
		AwardCodeAdd()
	else
		Talk(1,"","��i hi�p �� d�ng gift code r�i ")
	end;
end;

function AwardCodeAdd()

	nIndex = AddScriptItem(4);-- 7 date; Item Tien Thao Lo [Dai]
	SetItemBindState(nIndex,2);

		
	nIndex = AddScriptItem(6);-- 7 date; Item Que Hoa Tuu [Dai]
	SetItemBindState(nIndex,2);

	nIndex = AddTaskItem(15); -- tinh hong bao thach
	SetItemBindState(nIndex,2);
	nIndex = AddTaskItem(15);
	SetItemBindState(nIndex,2);
	nIndex = AddTaskItem(15);
	SetItemBindState(nIndex,2);

	for i = 7,11 do
		nIndex = AddTaskItem(i); -- sat thu gian nguyen bo
		SetItemBindState(nIndex,2);
	end;

	for i = 1,2 do
		nIndex = AddTaskItem(26); -- lenh bai tich tinh dong
		SetItemBindState(nIndex,2);
		nIndex = AddTaskItem(12);
		SetItemBindState(nIndex,2);
		nIndex = AddScriptItem(14);
		SetItemBindState(nIndex,2);
	end;

	for i = 1,30 do
		nIndex = AddTaskItem(28);
		SetItemBindState(nIndex,2);
	end;
	
	Msg2Player("Ch�c m�ng ��i hi�p �� nh�p th�nh c�ng m� Gift Code, nh�n ���c ph�n th��ng tri �n t� m�y ch�.");
	SetTask(T_GIFTCODE,1);
end;

function SP_Level()
	local tbSay = {
		"Nh�n ph�n th��ng l�n c�p 20/Reward_20",
		"Nh�n ph�n th��ng l�n c�p 50/Reward_50",
		"Nh�n ph�n th��ng l�n c�p 80/Reward_80",
		"Nh�n ph�n th��ng l�n c�p 120/Reward_120",
		"Ta ch� gh� ngang qua/no",
	}
	Say(10227,getn(tbSay),tbSay);
end;

function Reward_20()
	
	if (GetTask(T_REWARD20) > 0) then
		Talk(1,"",ERROR_LIST[1]);
		return 0
	end;
	
	if (GetLevel() < 20) then
		Talk(1,"",ERROR_LIST[2]);
		return 0
	end;
	
	if (FindEmptyPlace(6,6) == 0) then 
		Talk(1,"","H�y s�p x�p l�i r��ng h�nh trang c�a c�c h�, ��m b�o �� <color=yellow> 6x6 <color> ch� tr�ng! ");
		return 0
	end;
	
	for i = 1,2 do
		nIndex = AddScriptItem(3,7);-- 7 date; Item Tien Thao Lo [Tieu]
		SetItemBindState(nIndex,2);
	end;
	nIndex = AddItem(0,10,2,1,0,0,0);
	SetItemBindState(nIndex,2);
	-- Earn(1000);
	SetTask(T_REWARD20,1);
end;

function Reward_50()

	if (GetTask(T_REWARD50) > 0) then
		Talk(1,"",ERROR_LIST[1]);
		return 0
	end;
	
	if (GetLevel() < 50) then
		Talk(1,"",ERROR_LIST[3]);
		return 0
	end;
	
	if (FindEmptyPlace(6,6) == 0) then 
		Talk(1,"","H�y s�p x�p l�i r��ng h�nh trang c�a c�c h�, ��m b�o �� <color=yellow> 6x6 <color> ch� tr�ng! ");
		return 0
	end;
	
	-- for i = 1,2 do
	-- 	nIndex = AddScriptItem(3,7);-- 7 date; Item Tien Thao Lo [Tieu]
	-- 	SetItemBindState(nIndex,2);
	-- end;
	nIndex = AddItem(0,10,2,10,0,0,0);
	SetItemBindState(nIndex,2);
	Earn(2000);
	SetTask(T_REWARD50,1);
end;

function Reward_80()
	local nRandom =random(1,10)
	
	if (GetTask(T_REWARD80) > 0) then
		Talk(1,"",ERROR_LIST[1]);
		return 0
	end;
	
	if (GetLevel() < 80) then
		Talk(1,"",ERROR_LIST[4]);
		return 0
	end;
	
	if (FindEmptyPlace(6,6) == 0) then 
		Talk(1,"","H�y s�p x�p l�i r��ng h�nh trang c�a c�c h�, ��m b�o �� <color=yellow> 6x6 <color> ch� tr�ng! ");
		return 0
	end;
	
	-- for i = 1,3 do
	-- 	nIndex = AddScriptItem(4,7);-- 7 date; Item Tien Thao Lo [Dai]
	-- 	SetItemBindState(nIndex,2);
	-- end;
	
	for i = 1,3 do
		nIndex = AddScriptItem(6,7);-- 7 date; Que Hoa Tuu
		SetItemBindState(nIndex,2);
	end;
	
	nIndex = AddTaskItem(16); -- lam thuy tinh
	SetItemBindState(nIndex,2);
	
	nIndex = AddTaskItem(17); -- tu thuy tinh
	SetItemBindState(nIndex,2);
	
	nIndex = AddTaskItem(18); -- luc thuy tinh
	SetItemBindState(nIndex,2);
	
	nIndex = AddScriptItem(70,7); -- tui mau 7 ngay
	SetItemBindState(nIndex,2);
	
	for  i = 1,3 do
	nIndex = AddScriptItem(14,7); -- x2 luyen skills 7 ngay
	SetItemBindState(nIndex,2);
	end;
	
	if (nRandom == 5) then -- chieu da ngoc su du cap 5
		AddItem(0,10,5,nRandom,0,0,0);
	elseif (nRandom == 10) then -- chieu da ngoc su du cap 10	
		AddItem(0,10,5,nRandom,0,0,0);
	elseif (nRandom < 5) then
	nIndex = AddItem(0,10,5,nRandom+random(1,4),0,0,0); -- cac loai ngua khac
	SetItemBindState(nIndex,2);
	elseif (nRandom > 5 and nRandom < 10) then
	nIndex = AddItem(0,10,5,10-nRandom,0,0,0); -- cac loai ngua khac
	SetItemBindState(nIndex,2);
	end;
	Earn(200000);
	SetTask(T_REWARD80,1);
end;

function Reward_120()
	local nRandom =random(1,10)
	
	if (GetTask(T_REWARD120) > 0) then
		Talk(1,"",ERROR_LIST[1]);
		return 0
	end;
	
	if (GetLevel() < 120) then
		Talk(1,"",ERROR_LIST[5]);
		return 0
	end;
	
	if (FindEmptyPlace(6,6) == 0) then 
		Talk(1,"","H�y s�p x�p l�i r��ng h�nh trang c�a c�c h�, ��m b�o �� <color=yellow> 6x6 <color> ch� tr�ng! ");
		return 0
	end;
	
	for i = 1,3 do
		nIndex = AddScriptItem(4,7);-- 7 date; Item Tien Thao Lo [Dai]
	end;
	
	for i = 1,3 do
		nIndex = AddScriptItem(6,7);-- 7 date; Que Hoa Tuu
	end;
	
	AddTaskItem(16); -- lam thuy tinh
	
	AddTaskItem(17); -- tu thuy tinh
	
	AddTaskItem(18); -- luc thuy tinh
	
	for i = 1,3 do 
	AddTaskItem(26); -- lenh bai tich tinh dong.
	AddTaskItem(26); -- lenh bai tich tinh dong.
	AddTaskItem(26); -- lenh bai tich tinh dong.
	end;
	Earn(2000000);
	AddScriptItem(71); -- manh son ha xa tac x1000.
	SetTask(T_REWARD120,1);
end;

--///////////////////////////////////////////////////LEARN SKILLS
ZFACTION = {
	[1] = {
		{"Thi�u L�m Ph�i",1},
		{"Thi�n V��ng Bang",2},
	},
	[2] = {
		{"���ng M�n",3},
		{"Ng� ��c Gi�o",4},	
	},
	[3] = {
		{"Nga My Ph�i",5},
		{"Th�y Y�n M�n",6},
		--{"Hoa S�n ph�i",11},
	},
	[4] = {
		{"C�i Bang",7},
		{"Thi�n Nh�n Gi�o",8},
	},
	[5] = {
		{"V� �ang Ph�i",9},
		{"C�n L�n Ph�i",10},
	},
}
function SP_Skill()
	local szHello = "M�i nh�n v�t s� ���c nh�n m�t cu�n b� k�p c�a m�n ph�i m�nh h�y gia nh�p r�i ��n ��y l�nh th��ng";
	local TAB_SAY = {
		"H�c k� n�ng 90./SP_ChooseSkill",
		"Ta ch� gh� th�m ng��i/no"		
	}
	Say(szHello,getn(TAB_SAY),TAB_SAY);
end;

function SP_ChooseSkill()
	local szHello = "M�i nh�n v�t s� ���c nh�n m�t cu�n b� k�p c�a m�n ph�i m�nh h�y gia nh�p r�i ��n ��y l�nh th��ng";
	local nFactionID = GetFactionNo() + 1;
	local nLevel = 80;
	if(nFactionID == 0) then
		Talk(1,"","Ch�a gia nh�p m�n ph�i kh�ng th� h�c k� n�ng.")
		return
	end
	
	local tbMessage = {
			"<color=green>Ch�c m�ng ��i hi�p �� h�c ���c k� n�ng "..nLevel.." "..Faction.TFACTION_INFO[nFactionID].sFactionName..".",
			"Ng��i �� l�nh h�i k� n�ng n�y r�i!",
			"H�y luy�n l�n ��ng c�p "..nLevel.." ��.",
			"Ng��i �� nh�n r�i c�n mu�n nh�n n�a sao, th�t l� tham lam kh�ng x�ng danh anh h�ng!",
		}
	
	if(GetLevel() < nLevel) then
		Msg2Player(tbMessage[3])
		return
	end
	
	if (GetTask(T_REWARDBIKIP8X) > 0) then
		Msg2Player(tbMessage[4])
		return
	end
	
	local TAB_SAY ={};
	local nCount = 0;
	for i = 1,getn(Faction.TFACTION_INFO[nFactionID].tbSkill90) do
		if (HaveMagic(Faction.TFACTION_INFO[nFactionID].tbSkill90[i][2]) < 1) then
		tinsert(TAB_SAY,Faction.TFACTION_INFO[nFactionID].tbSkill90[i][1].."/AddSkillsPlayer#"..Faction.TFACTION_INFO[nFactionID].tbSkill90[i][2]);	
		nCount = nCount +1;
		end;
	end;
	tinsert(TAB_SAY,"Ta ch� gh� th�m ng��i/no")
	if (nCount > 0) then
		Say(szHello,getn(TAB_SAY),TAB_SAY);
	else
	Talk(1,"","Ng��i �� l�nh h�i h�t k� n�ng m�n ph�i ko c�n ��n ��y nh�n th�m!");
	end;
	
end;

function AddSkillsPlayer(nSel,nIDMagic)
	local nIdxMagic = tonumber(nIDMagic);
	AddMagic(nIdxMagic,5);
	SetTask(T_REWARDBIKIP8X,1);
end;

function no()
end;
