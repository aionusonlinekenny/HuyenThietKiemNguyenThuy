-- Author:	Kinnox;
-- Date:	15-04-2021
-- Functions: Tham Cuu;

function main(nNpcIdx)
-- dofile("script/global/luanpcfunctions/thamcuu.lua");
ThamCuu(nNpcIdx);
end;

function ThamCuu(nNpcIdx)
	local szHello = "<color=Orange>Th�m C�u<color>: C�c l�o th� kh� tr�n giang h� ��u ��n ��y �� nh� ta l�m n� nh�ng chi�c kh�a b�o m�t ��ng gi�!";
	local tbSay = {
		"M� r�ng r��ng/ExPandBox",
		"Thu�n h�a chi�n m�/HorseSay",
		"Ta ch� gh� ngang qua./OnCancel",
	}
	Say(szHello,getn(tbSay),tbSay);
end;

function ExPandBox()
	local szHello ="<color=red>H� Th�ng:<color> Xin ch�o!"
	Tab_inSert = {
	"M� r��ng 1/ID_ExPandBox_1",
	"M� r��ng 2/ID_ExPandBox_2",
	"M� r��ng 3/ID_ExPandBox_3",
	"M� r��ng 4/ID_ExPandBox_4",
	"M� r��ng 5/ID_ExPandBox_5",
	"M� t�i h�nh trang/ID_EquipItemBox",
	"Ki�m tra r��ng �� m�/ID_GExPandBox",
	"Ta kh�ng c�n ng��i d�y b�o/OnCancel"
	}
	if (GetStoreBox() == 0) then
		Say(szHello,2,Tab_inSert[1],Tab_inSert[8]);
	elseif (GetStoreBox() == 1) then
		Say(szHello,2,Tab_inSert[2],Tab_inSert[8]);
	elseif (GetStoreBox() == 2) then
		Say(szHello,2,Tab_inSert[3],Tab_inSert[8]);
	-- elseif (GetStoreBox() == 3) then
		-- Say(szHello,2,Tab_inSert[4],Tab_inSert[8]);
	-- elseif (GetStoreBox() == 4) then
		-- Say(szHello,2,Tab_inSert[5],Tab_inSert[8]);
	else
		Say(szHello,2,Tab_inSert[6],Tab_inSert[8]);
	end;
end

----------------------------
--
----------------------------
function ID_ExPandBox_1()
	local nSel = 1 ;
	
	if (GetItemCountInBag(6,22,0,0)) < 1 then
		Talk(1,"","Ng��i kh�ng c� Ch�a kh�a r��ng 1");
	return
	end;
	DelTaskItem(22,1);
	SetStoreBox(nSel);
	Msg2Player("C�c h� �� m� th�nh c�ng r��ng "..nSel.."");
end

function ID_ExPandBox_2()
	local nSel = 2 ;
	if (GetItemCountInBag(6,23,0,0)) < 1 then
		Talk(1,"","Ng��i kh�ng c� Ch�a kh�a r��ng 2");
	return
	end;
	DelTaskItem(23,1);
	SetStoreBox(nSel);
	Msg2Player("C�c h� �� m� th�nh c�ng r��ng "..nSel.."");
end

function ID_ExPandBox_3()
	local nSel = 3 ;
	if (GetItemCountInBag(6,24,0,0)) < 1 then
		Talk(1,"","Ng��i kh�ng c� Ch�a kh�a r��ng 3");
	return
	end;
	DelTaskItem(24,1);
	SetStoreBox(nSel);
	Msg2Player("C�c h� �� m� th�nh c�ng r��ng "..nSel.."");
end

function ID_ExPandBox_4()
	-- local nSel = 4 ;
	-- SetStoreBox(nSel);
	-- Msg2Player("C�c h� �� m� th�nh c�ng r��ng "..nSel.."");
end

function ID_ExPandBox_5()
	-- local nSel = 5 ;
	-- SetStoreBox(nSel);
	-- Msg2Player("C�c h� �� m� th�nh c�ng r��ng "..nSel.."");
end


function ID_EquipItemBox()
	if (GetItemCountInBag(6,25,0,0)) < 1 then
		Talk(1,"","Ng��i kh�ng c� Ch�a kh�a t�i h�nh trang");
	return
	end;
	SetExPandBox(1);
	DelTaskItem(25,1);
	Msg2Player("C�c h� �� m� th�nh c�ng t�i h�nh trang!");
end;

function ID_GExPandBox()
	Msg2Player("C�c h� �� m� ��n r��ng th� "..GetStoreBox().."");
end;

function HorseSay()
	local szHello = "<color=Orange>Th�m C�u<color>: C�c l�o th� kh� tr�n giang h� ��u ��n ��y �� nh� ta l�m n� nh�ng chi�c kh�a b�o m�t ��ng gi�!";
	local tbSay = {
		"Thu�n h�a ng�a phi v�n/HorseBox#8",
		"Thu�n h�a ng�a b�n ti�u/HorseBox#6",
		"Thu�n h�a ng�a phi�n v�/HorseBox#7",
		"Ta ch� gh� ngang qua./OnCancel",
	}
	Say(szHello,getn(tbSay),tbSay);
end;

function HorseBox(nSel,nIndex)
	SetTask(899,0);
	local nIndex = tonumber(nIndex);
	SetTask(899,nIndex);
	OpenGiveBox("��t v�t ph�m v�o trong ","Th�n m� th��ng r�t kh� thu�n ph�c, ta c�n 6 B�c ��u Thu�n M� Thu�t m�i c� th� gi�p ng��i. ��t ph�c duy�n c�c lo�i �� t�ng duy�n ph�n v�i th�n m�. Vi�c n�y ta c�n 1000 v�n l��ng m�i gi�p ���c.","HorseExecute")
end;

function HorseExecute()
	local nItemIdx, nG, nD1,nD2,nD3,nD4,nD5,nD6, nP, nL, Ser;
	local nCountItem = 0;
	local nCash = 10000000;
	local ROOMG = 8; --ID MAC DINH CUA GIVE BOX
	local nIndexItem={};
	local i = 0;
	if ROOMG ~= 8 then
	return
	end	
	
	if (GetTask(899) == 8) then
	nD1 = 35;
	nD2 = 36;
	nD3 = 37;
	nD4 = 38;
	nD5 = 39;
	nD6 = 40;
	elseif(GetTask(899) == 6) then
	nD1 = 41;
	nD2 = 42;
	nD3 = 43;
	nD4 = 44;
	nD5 = 45;
	nD6 = 46;	
	else
	nD1 = 47;
	nD2 = 48;
	nD3 = 49;
	nD4 = 50;
	nD5 = 51;
	nD6 = 52;	
	end;
	
	
	
	for i=0,5 do
		for j=0,3 do	
			nItemIdx = GetROItem(ROOMG,i,j);	
			nG, nD, nP, nL, Ser, nLuc = GetItemProp(nItemIdx)
			if (nG ~= -1 or nD ~= -1 or nP ~= -1 or nL ~= -1 or Ser ~= -1) then
				if (nG == 6 and nD == nD1 and nP == 1) then
					nIndexItem[1] = nItemIdx;
					break;
				end;
			end
		end
	end
	
	for i=0,5 do
		for j=0,3 do	
			nItemIdx = GetROItem(ROOMG,i,j);	
			nG, nD, nP, nL, Ser, nLuc = GetItemProp(nItemIdx)
			if (nG ~= -1 or nD ~= -1 or nP ~= -1 or nL ~= -1 or Ser ~= -1) then
				if (nG == 6 and nD == nD2 and nP == 1) then
					nIndexItem[2] = nItemIdx;
					break;
				end;
			end
		end
	end

	for i=0,5 do
		for j=0,3 do	
			nItemIdx = GetROItem(ROOMG,i,j);	
			nG, nD, nP, nL, Ser, nLuc = GetItemProp(nItemIdx)
			if (nG ~= -1 or nD ~= -1 or nP ~= -1 or nL ~= -1 or Ser ~= -1) then
				if (nG == 6 and nD == nD3 and nP == 1) then
					nIndexItem[3] = nItemIdx;
					break;
				end;
			end
		end
	end
	
	for i=0,5 do
		for j=0,3 do	
			nItemIdx = GetROItem(ROOMG,i,j);	
			nG, nD, nP, nL, Ser, nLuc = GetItemProp(nItemIdx)
			if (nG ~= -1 or nD ~= -1 or nP ~= -1 or nL ~= -1 or Ser ~= -1) then
				if (nG == 6 and nD == nD4 and nP == 1) then
					nIndexItem[4] = nItemIdx;
					break;
				end;
			end
		end
	end
	
	for i=0,5 do
		for j=0,3 do	
			nItemIdx = GetROItem(ROOMG,i,j);	
			nG, nD, nP, nL, Ser, nLuc = GetItemProp(nItemIdx)
			if (nG ~= -1 or nD ~= -1 or nP ~= -1 or nL ~= -1 or Ser ~= -1) then
				if (nG == 6 and nD == nD5 and nP == 1) then
					nIndexItem[5] = nItemIdx;
					break;
				end;
			end
		end
	end
	
	for i=0,5 do
		for j=0,3 do	
			nItemIdx = GetROItem(ROOMG,i,j);	
			nG, nD, nP, nL, Ser, nLuc = GetItemProp(nItemIdx)
			if (nG ~= -1 or nD ~= -1 or nP ~= -1 or nL ~= -1 or Ser ~= -1) then
				if (nG == 6 and nD == nD6 and nP == 1) then
					nIndexItem[6] = nItemIdx;
					break;
				end;
			end
		end
	end
	
	local bCountGem =0;
	local nIndexGem = {};
	for i=0,5 do
		for j=0,3 do	
			nItemIdx = GetROItem(ROOMG,i,j);	
			nG, nD, nP, nL, Ser, nLuc = GetItemProp(nItemIdx)
			if (nG ~= -1 or nD ~= -1 or nP ~= -1 or nL ~= -1 or Ser ~= -1) then
				if (nG == 7 and nD >= 11 and nD <= 13 and nP == 1) then
					bCountGem = bCountGem +1;
					nIndexGem[bCountGem] = nItemIdx;
				end;
			end
		end
	end

	local bCount = 0;
	for i = 1,6 do
		if (nIndexItem[i] == nil) then
			Talk(1,"","C�c h� thi�u B�c ��u Thu�n M� Thu�t s� <color=yellow> "..i.."<color>. Ta c�n �� 6 B�c ��u Thu�n M� Thu�t.");
			return
		else
			bCount = bCount + 1;
		end;
	end;
	if (GetCash() < nCash) then
		Talk(1,"","C�ng r�n t�o ra tr�ng s�c r�t l�n, tr�n giang h� n�y ta ch�a m�t l�n n�i th�ch. Mang 1000 v�n ��n ��y.");
		return
	end
	if (bCountGem < 2 ) then
		Talk(1,"","Ta kh�ng th� m�o hi�m khi kh�ng c� ph�c duy�n l� ��nh k�m, r�t nguy hi�m. �t nh�t ph�i c� 2 ph�c duy�n l�(ph�m ch�t c�ng cao duy�n s� c�ng t�t).");
		return
	end
	----------------Tinh ty le
	--Ty le = 5.6 * gem;
	local nPercen = (5.6/3)*bCountGem;
	local nLucky = GetLucky(0);
	---------------
	if (random(1,100) <= nPercen+nLucky) then
		if (bCount >= 6) then
			AddItem(0,10,GetTask(899),10,GetSeries(),0,0)
			for i = 1,6 do
				DelItemByIndex(nIndexItem[i]);
				nIndexItem[i] = nil;
			end
			for i = 1,bCountGem do
				DelItemByIndex(nIndexGem[i]);
				nIndexGem[i] = nil;
			end;
			
			SetTask(899,0);
			nIndexItem = {};
			Msg2Player("<color=yellow> C�c h� thu�n h�a th�nh c�ng m�t chi�n m� trong chi�n thuy�t, v�i s�c phi v�n l� tr��ng xa.<color>");
			EndGiveBox();
		end;
	else
		for i = 1,bCountGem do
			DelItemByIndex(nIndexGem[i]);
			nIndexGem[i] = nil;
		end;
		Msg2Player("<color=cyan>�� l� th�n m� th� thu�n ph�c r�t kh� kh�n, ��ng n�n ch�. m�i vi�c s� th�nh.<color>");
	end;
	Pay(nCash);
end;

function OnCancel()

end;