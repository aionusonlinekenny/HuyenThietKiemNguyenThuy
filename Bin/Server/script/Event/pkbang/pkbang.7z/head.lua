-- Duong Chau
HAT_THAN_TIEN = {
{80064,110976},
{80064,111296},
{80224,111296},
{80224,110944},
{80416,110880},
{80448,111136},
{80576,110816},
{80608,111104},
{80800,110816},
{80928,111072},
{80960,110752},
{80576,111424},
{80192,111776},

};

--------------------
SCRIPT_HAT = "\\script\\event\\pkbang\\hatthantien.lua"
--------------------
SCRIPT_QUA = "\\script\\event\\pkbang\\quathantien.lua"
--------------------
function AddHatThanTien()
	local nSubWorld;
	--So cap
	for i = 1,getn(HAT_THAN_TIEN) do
		SubWorld = SubWorldID2Idx(2);
		nNpcIndex = AddNpc(1117, 1, SubWorld, HAT_THAN_TIEN[i][1], HAT_THAN_TIEN[i][2], 0, "H�t th�n ti�n", 0, 3);
		SetNpcScript(nNpcIndex, SCRIPT_HAT);
		SetNpcParam(nNpcIndex,1,1);
	end;
	--thong bao--
	local commonstr = "<color=green>Qu� th�n ti�n s�p ch�n t�i %s (%d/%d). C�c ��i hi�p h�y chu�n b� thu ho�ch!"
	Msg2SubWorld(format(commonstr,GetMapName(2),floor(HAT_THAN_TIEN[1][1]/256), floor(HAT_THAN_TIEN[1][2]/512)));	
end;

function AddQuaThanTien()
	local nSubWorld;

	for i = 1,getn(HAT_THAN_TIEN) do
		SubWorld = SubWorldID2Idx(2);
		nNpcIndex = AddNpc(1118, 1, SubWorld, HAT_THAN_TIEN[i][1], HAT_THAN_TIEN[i][2], 0, "Qu� th�n ti�n", 0, 3);
		SetNpcScript(nNpcIndex, SCRIPT_QUA);
		SetNpcParam(nNpcIndex,1,1);
	end;
end;

function DelPkBang(Select)
local nH = tonumber(date("%H"))
local nM = tonumber(date("%M"))
	if (Select == 1) then -- Del hat huy hoang
		ClearMapNpcWithName(2,"H�t th�n ti�n");
		AddQuaThanTien();
	else --Del qua huy hoang
		ClearMapNpcWithName(2,"Qu� th�n ti�n");
		if (nM < 40) then
			AddHatThanTien();
		end
	end;
end;


