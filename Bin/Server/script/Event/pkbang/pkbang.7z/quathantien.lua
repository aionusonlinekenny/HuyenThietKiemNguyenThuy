function main(nNpcIndex)
	local nParam = GetNpcParam(nNpcIndex,1);
	if (nParam == 1) then
		TimeBox("�ang nh�t qu�",15,"quathantien",tonumber(nNpcIndex));
	else
		TimeBox("�ang nh�t qu�",15,"quathantien",tonumber(nNpcIndex));
	end;
end;

function quathantien(nNpcIndex)
	if (FindAroundNpc(GetNpcID(2,nNpcIndex)) == 0) then
	return end
	DelNpc(nNpcIndex);
	AddScriptItem(10);
	Msg2Player("��i hi�p �� nh�t ���c m�t qu� huy ho�ng s� c�p.")
end

