----------------------------------
--	Copyright: JX Online by Kinnox
--	Author: Kinnox;
--	Date: 11/11/2021
--	Desc: Binh s� hi�u ph�
----------------------------------
Include("\\script\\item\\battles\\checkmapid.lua")

----------------------------------
--
----------------------------------
function EatMedicine()
	if(GetFightState() == 0) then 
		Say("Kh�ng th� s� d�ng ��o c� n�y khi � tr�ng th�i phi chi�n ��u.", 0) 
		return 0
	end
	local nCamp = nCamp
	if(nCamp == 1) then 
		if (GetMissionV(ZBattle.tbMission.CALLNPCCOUNT_S) >= ZBattle.MAX_CALL_NPC) then 
			Msg2Player("S� l��ng binh s� g�i ra �� ��n gi�i h�n, kh�ng th� g�i th�m.") 
			return 0 
		else 
			SetMissionV(ZBattle.tbMission.CALLNPCCOUNT_S, GetMissionV(ZBattle.tbMission.CALLNPCCOUNT_S) + 1)
		end 
	elseif(nCamp == 2) then 
		if (GetMissionV(ZBattle.tbMission.CALLNPCCOUNT_J) >= ZBattle.MAX_CALL_NPC) then 
			Msg2Player("S� l��ng binh s� g�i ra �� ��n gi�i h�n, kh�ng th� g�i th�m.") 
			return 0
		else 
			SetMissionV(ZBattle.tbMission.CALLNPCCOUNT_J, GetMissionV(ZBattle.tbMission.CALLNPCCOUNT_J) + 1)		
		end 
	end 
	local W, X, Y = GetWorldPos()
	if (GetLevel() >= 40 and GetLevel() <= 79) then
		if(nCamp == 1) then
			CallSjNpc(682, 50, W, X, Y," - T�ng Binh")
		elseif(nCamp == 2) then 
			CallSjNpc(688, 50, W, X, Y," - Kim Binh")
		end 
	elseif (GetLevel() >= 80 and GetLevel() <= 119) then
		if(nCamp == 1) then 
			CallSjNpc(682, 70, W, X, Y," - T�ng Binh") 
		elseif(nCamp == 2) then 
			CallSjNpc(688, 70, W, X, Y," - Kim Binh")
		end 
	else
		if(nCamp == 1) then 
			CallSjNpc(682, 90, W, X, Y," - T�ng Binh")
		elseif(nCamp == 2) then 
			CallSjNpc(688, 90, W, X, Y," - Kim Binh")
		end 
	end
	return 1
end 

----------------------------------
--
----------------------------------
function CallSjNpc(NpcId, NpcLevel, W, X, Y, Name) 
	local sPName = GetName() 
	AddNpc(NpcId, NpcLevel, SubWorldID2Idx(W), ( X - 3 ) * 32, Y * 32, 1, sPName..Name, 0) 
	AddNpc(NpcId, NpcLevel, SubWorldID2Idx(W), ( X +  3 ) * 32, Y * 32, 1, sPName..Name, 0)
end