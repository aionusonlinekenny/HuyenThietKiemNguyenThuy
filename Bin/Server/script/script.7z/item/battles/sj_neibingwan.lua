----------------------------------
--	Copyright: JX Online by Kinnox
--	Author: Kinnox;
--	Date: 11/11/2021
--	Desc: N�i B�ng Ho�n
----------------------------------
Include("\\script\\item\\battles\\checkmapid.lua")

----------------------------------
--
----------------------------------
function EatMedicine() 
	AddSkillState(481, 10, 1, 3240)
	Msg2Player("<color=OrangeRed>��i hi�p s� d�ng m�t n�i b�ng ho�n.<color>")
	return 1
end