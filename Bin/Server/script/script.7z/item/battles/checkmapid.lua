----------------------------------
--	Copyright: JX Online by Kinnox
--	Author: Kinnox;
--	Date: 11/11/2021
--	Desc: Ki�m tra b�n �� T�ng Kim
----------------------------------
Include("\\script\\mission\\battles\\head.lua")

----------------------------------
--
----------------------------------
function OnUse(nItemIdx) 
	local nMapId = SubWorldIdx2ID(SubWorld)
	if(nMapId == ZBattle.FIGHT_MAP) then
		return EatMedicine(nItemIdx)
	end 
	Msg2Player("<color=orangered>��o c� n�y ch� ���c ph�p s� d�ng � chi�n tr��ng.<color>")
	return 0
end
