----------------------------------
--	Copyright: JX Online by Kinnox
--	Author: Kinnox;
--	Date: 11/11/2021
--	Desc: L�nh b�i
----------------------------------
Include("\\script\\item\\battles\\checkmapid.lua")

----------------------------------
--
----------------------------------
function EatMedicine() 
	CastSkill(492, 1)
	Msg2Player("<color=OrangeRed>Ng��i s� d�ng m�t L�nh b�i.<color>")
	return 1
end
