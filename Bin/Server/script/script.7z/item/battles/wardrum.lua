----------------------------------
--	Copyright: JX Online by Kinnox
--	Author: Kinnox;
--	Date: 11/11/2021
--	Desc: Chi�n c�
----------------------------------
Include("\\script\\item\\battles\\checkmapid.lua")

----------------------------------
--
----------------------------------
function EatMedicine() 
	CastSkill(491, 1)
	Msg2Player("<color=OrangeRed>Ng��i s� d�ng m�t Chi�n C�.<color>")
	return 1
end 
