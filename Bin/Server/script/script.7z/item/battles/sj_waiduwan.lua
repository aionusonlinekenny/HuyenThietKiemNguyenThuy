----------------------------------
--	Copyright: JX Online by Kinnox
--	Author: Kinnox;
--	Date: 11/11/2021
--	Desc: Ngo�i ��c Ho�n
----------------------------------
Include("\\script\\item\\battles\\checkmapid.lua")

----------------------------------
--
----------------------------------
function EatMedicine() 
	AddSkillState(485, 5, 1, 3240) 
	Msg2Player("<color=OrangeRed>��i hi�p s� d�ng m�t ngo�i ��c ho�n.<color>")
	return 1
end