----------------------------------
--	Copyright: JX Online by Kinnox
--	Author: Kinnox;
--	Date: 11/11/2021
--	Desc: B� c�u
----------------------------------
Include("\\script\\item\\battles\\checkmapid.lua")

----------------------------------
--
----------------------------------
function EatMedicine()
	local nCurCamp = GetCurCamp()
	local _,nX,nY = GetWorldPos()
	nX = floor(nX / 8)
	nY = floor(nY / 16) 
	local sStr = "<color=orangered><color=wood>"..GetName().." <color>� t�a �� <color=yellow>("..nX..","..nY..")<color> �ang y�u c�u vi�n tr�."
	Msg2MSGroup(ZBattle.tbMission.MAIN, sStr, nCurCamp)
	Msg2Player("<color=orangered>��i hi�p �� s� d�ng m�t b� c�u.<color>")
	return 1
end 
