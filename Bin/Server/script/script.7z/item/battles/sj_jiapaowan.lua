----------------------------------
--	Copyright: JX Online by Kinnox
--	Author: Kinnox;
--	Date: 11/11/2021
--	Desc: Gia B�o Ho�n
----------------------------------
Include("\\script\\item\\battles\\checkmapid.lua")

----------------------------------
--
----------------------------------
function EatMedicine() 
	AddSkillState(493, 2, 1, 3240)
	Msg2Player("<color=OrangeRed>��i hi�p s� d�ng m�t gia b�o ho�n.<color>")
	return 1
end