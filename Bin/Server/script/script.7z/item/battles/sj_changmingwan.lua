----------------------------------
--	Copyright: JX Online by Kinnox
--	Author: Kinnox;
--	Date: 11/11/2021
--	Desc: Tr��ng M�nh Ho�n
----------------------------------
Include("\\script\\item\\battles\\checkmapid.lua")

----------------------------------
--
----------------------------------
function EatMedicine() 
	AddSkillState(488, 5, 1, 3240)
	Msg2Player("<color=OrangeRed>��i hi�p s� d�ng m�t tr��ng m�nh ho�n.<color>")
	return 1
end