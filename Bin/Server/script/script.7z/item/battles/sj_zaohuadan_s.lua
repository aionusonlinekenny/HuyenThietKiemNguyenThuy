 
function OnUse(nIndex)
	local nW = GetWorldPos()
	if nW == 378 or nW == 379 or nW == 380 then
		AddSkillState(472, 5, 1, 54 ) 
		Msg2Player("��i hi�p s� d�ng 1 C�n Kh�n T�o H�a �an (V�a) .")	
		return 1
	end
	return 0
end

