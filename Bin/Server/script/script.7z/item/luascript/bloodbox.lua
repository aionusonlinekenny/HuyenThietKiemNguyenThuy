-- Author: Kinnox
-- Date: 25/12/2021
-- Item: Tui mau tan thu
Include("\\script\\lib\\TaskLib.lua")
Include("\\script\\lib\\Revivepos.lua")
WARNING_TALK = "Kh�ng th� thao t�c li�n t�c, vui l�ng ch� sau<color=yellow> %d gi�y<color> n�a.";

nYr,nMo,nDy,nHr,nMi,nSe,nDyfW = 0,0,0,0,0,0,0;
function OnUse(nNpcIndex)
	BloodBox(nIndex)
end

function BloodBox(nIndex)	
	local nW, nX, nY = GetWorldPos();	
	if (nW ~= 242 and nW ~= 342 and nW ~= 341 and nW ~= 337 and nW ~= 338 and nW ~= 339 and 
	nW ~= 464 and nW ~= 465 and nW ~= 466 and nW ~= 467 and nW ~= 468 and nW ~= 469 and nW ~= 470) then -- map tay tuy, vuot ai, phong lang do;
		if CheckMapNoForTHP(nW) == 1 then
		Talk(1,"", "Kh�ng th� s� d�ng T�i ���c ph�m � ��y.")
		return end	
	end;
	
	
	nYr,nMo,nDy,nHr,nMi,nSe = GetTimeNow();
	local nNowMi = nDy * 24 * 60 * 60 + nHr * 60 * 60 + nMi * 60 + nSe;
	
	if (nNowMi < 15) then
		Talk(1, "",format(WARNING_TALK,nNowMi));
	return end
	
	if (GetTaskTemp(TMP_TGIANMOTUI) == 0) then
		SetTaskTemp(TMP_TGIANMOTUI, nNowMi)
		AddBlood()
		Talk(1, "",format(WARNING_TALK,15));
	return end
	
	local nLasMi = nNowMi - 15;
	if (nLasMi < GetTaskTemp(TMP_TGIANMOTUI)) then
		local nEndMi = GetTaskTemp(TMP_TGIANMOTUI) - nLasMi;
		if (nEndMi <= 15) then
			Talk(1, "",format(WARNING_TALK,nEndMi));
		else
			SetTaskTemp(TMP_TGIANMOTUI,0);
			Talk(1, "","T� ��ng reset th�i gian m� t�i m�u.");
		return end
	return end
	
	AddBlood(nW)
	SetTaskTemp(TMP_TGIANMOTUI, nNowMi);
end


function AddBlood(nW)
	local nMax = 30;
	local nCount = CalcFreeItemCellCount();
	if(GetPKFlag() > 0) then
	Talk(1,"","Ch� s� d�ng t�i m�u trong tr�ng th�i <color=yellow>luy�n c�ng<color>");
	return end;
	
	if (nCount >= nMax) then
		nCount = nMax
	end
	local nIndex;
	if (GetLevel() > 80 or nW == 242 or nW == 342 or nW == 341) then
		for i = 1,nCount do
		nIndex = AddItem(5,2,0,5,0,0,0);
		SetItemBindState(nIndex,2);
		end
	else
		for i = 1,nCount do
		nIndex = AddItem(5,2,0,4,0,0,0);
		SetItemBindState(nIndex,2);
		end
	end

	Msg2Player("��i hi�p nh�n ���c <color=green>x"..nCount.."<color>  d��c ph�m luy�n c�ng!");
end

function no()

end