----------------------------------
--	Copyright: JX Online by Blood Team
--	Author: [S]
--	Date: 16/08/2014
--	Desc: Thi�t la h�n
----------------------------------

----------------------------------
--
----------------------------------
function OnUse(nIdx)
	if(GetHandItem() > 0) then
		Talk(1,"",10267)
		return 0
	end
	local nLevel = GetLevel();
	if(nLevel > 130) then
		Talk(1,"","��ng c�p <color=green>tr�n 130<color> kh�ng th� s� d�ng Thi�t La H�n!")
		return 0
	end
	
	AddOwnExp(300000)
	Msg2Player("B�n ��nh nhau v�i Thi�t La H�n n�a ng�y cu�i c�ng c�ng c� m�t �t kinh nghi�m.") 
	
	return 1
end