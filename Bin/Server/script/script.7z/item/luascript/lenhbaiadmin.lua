
Include("\\script\\lib\\admin\\point.lua");
Include("\\script\\lib\\admin\\char.lua");
Include("\\script\\lib\\admin\\gm_action.lua");
Include("\\script\\lib\\admin\\item.lua");
Include("\\script\\lib\\admin\\role.lua");
Include("\\script\\lib\\admin\\tool.lua");
Include("\\script\\lib\\admin\\equip.lua");
Include("\\script\\lib\\admin\\movemap.lua");
Include("\\script\\lib\\tasklib.lua");
Include("\\script\\global\\LuaNpcFunctions\\Station.lua");
Include("\\script\\global\\LuaNpcFunctions\\datau.lua");
Include("\\script\\mission\\loanchien\\head.lua");
Include("\\script\\mission\\vuotai\\head.lua");
Include("\\script\\mission\\phonglangdo\\head.lua");
Include("\\script\\mission\\liendau\\head.lua");
Include("\\script\\event\\quahuyhoang\\head.lua");
Include("\\script\\event\\hoadang\\head.lua");
Include("\\script\\event\\noichaoyeuthuong\\head.lua");
Include("\\script\\mission\\battles\\head.lua");
Include("\\script\\system_config.lua");

----------------------------------
-- Lenh bai admin
----------------------------------
function OnUse(nNpcIndex)
	-- if (GetName() == "HTK.Master" or GetName() == "BBOiShi") then
	if (GetName() ~= "11") then
		AskClientForNumber("mainx" ,0,1316,"Nh�p l�nh server. ");
	else
		Talk(1,"","Hack � con trai c�t");
	return end;
end

function mainx(nIndex,nID)
	if (tonumber(nID) == 1) then
		dofile("script/item/luascript/lenhbaiadmin.lua")
		Talk(1,"","Reload Sript Successfull! ");
		return
	end;
	local nW,nX,nY = GetWorldPos()
	local szHello = "<color=red>H� Th�ng:<color> <color=orange>Cu�c s�ng n�y bi�t bao �i�u tu�i ��p, Minh Qu�n xin h�y b�nh t�nh suy x�t\n<color=green>T�a �� hi�n t�i: B�n ��: "..nW.." - X: "..nX.."-Y: "..nY.."\n"..nW.." - X: "..(nX*32).."-Y: "..(nY*32)..""
	Tab_inSert = {
	"M� shop m�u/Shop",
	"Nh�n Trang B�/WPlayer_Equip",
	"Nh�n v�t ph�m/GM_Item",
	"M� r�ng r��ng/ExPandBox",
	"Li�n quan ��n nh�n v�t Admin/GM_Char",
	"Di chuy�n v� Ba L�ng Huy�n/movetoBLH",
	"Di chuy�n b�n �� luy�n c�ng/SelectTrainning",
	"Di chuy�n b�n �� ho�t ��ng/MoveMaps",
	"�i�u khi�n m�y ch�/ServerRemote",
	"Thao t�c tr�n ng��i ch�i/Player_Action",
	"Th� h�m/func_Test",
	"Ta kh�ng c�n ng��i d�y b�o/no",
	}
	Say(szHello,getn(Tab_inSert),Tab_inSert);
end;
--script add boss
BOSSTIEU_ARRAY={
{"Di�u Nh�",703,2,{1,6}},
{"Li�u Thanh Thanh",704,1,{2,5}},
{"Tr��ng T�ng Ch�nh",705,4,{3,4}}
};

POSITION_ARRAY={
{53,1672*32,3264*32,"Ba Lang Huyen"},
{53,1672*32,3264*32,"Ba Lang Huyen"},
{53,1672*32,3264*32,"Ba Lang Huyen"},
{53,1672*32,3264*32,"Ba Lang Huyen"},
{53,1672*32,3264*32,"Ba Lang Huyen"},
{53,1672*32,3264*32,"Ba Lang Huyen"},
};

COMMON_INFO = "C� ng��i nh�n th�y <color=Yellow> %s <color> xu�t hi�n t�i %s t�a �� <color=green> %d/%d <color>"

-- function release2bosstieu()
	-- local nNpcIndex = 0;
	-- local nPos = 1;
	-- for i=1,250 do
		-- nPos = RANDOM(1,2);
		-- local SubWorld = SubWorldID2Idx(POSITION_ARRAY[nPos][1]);
		-- nNpcIndex = AddNpc(985, 95, SubWorld, POSITION_ARRAY[nPos][2], POSITION_ARRAY[nPos][3], 0, "Boss t�t", 2, 0);
	-- end
-- end;
function release2bosstieu()
	local nNpcIndex = 0;
	local nPos = 1;
	-- for i=1,250 do
		-- nPos = RANDOM(1,2);
		local SubWorld = SubWorldID2Idx(53);
		nNpcIndex = AddNpc(1677, 95, SubWorld, 49632, 104576, 1, "D�m T�c", 2, 0);
		SetNpcSeries(nNpcIndex,0);
		SetNpcReduceDamge(nNpcIndex, 30);	
		SetNpcScript(nNpcIndex, "\\script\\global\\luanpcmonsters\\ondeath_normal.lua")
	-- end
	

end;

function func_Test()
	-- for i = 2075,2084 do
		-- AddGoldItem(i);
	-- end;

	--SetRank(9)
	--AddSkillState(1585, 20, 1, 24*60*60*18)
	--SendNotification("","Th�ng b�o: Chi�n tr��ng t�ng kim �ang trong giai �o�n b�o danh!");
	--for i = 1, 100 do
		--PlayerIndex = i;
	--SendNotification("","(Lo)<color=red>Th�ng b�o: <color> <color=green>Hoa ��ng<color> �� xu�t hi�n t�i b�n �� Hoa s�n c�nh k� tr��ng t�a �� 999/999 !");
		--			SendNotification("","<pic=138><color=red>Th�ng b�o: <color> <color=green>T�ng kim<color> �ang trong th�i gian b�o danh h�y mau ch�ng tham gia <pic=127> !:U !");
	--SendNotification("","(Lo)<color=red>Th�ng b�o: <color> <color=green>Boss ti�u Ho�ng kim<color> xu�t hi�n t�i T��ng d��ng(T�a ��:217/207), Bi�n kinh(T�a ��:197/203), D��ng ch�u(T�a ��:173/213) <pic="..random(1,140).."> <pic="..random(1,140).."> !");
	--SetLockSongJin("jxkinnox",1);
	--Msg2Player("DEBUG SONG JIN : "..GetLockSongJin("jxkinnox01").."");
	--Msg2Player("Dang long");
	--end;
	--TrembleItem();
	--SendNotification("","<color=red>Th�ng b�o: <color> <color=green>Boss ti�u Ho�ng kim<color> xu�t hi�n t�i T��ng d��ng(T�a ��:217/207), Bi�n kinh(T�a ��:197/203), D��ng ch�u(T�a ��:173/213) (!hh) (qd) (dz) !");
	-- dstop = {};
	-- for i=1,10 do
		-- dstop[getn(dstop)+1] = {"",0,0,0,0,0,0,0};
	-- end;
	-- for i = 1,3 do
	-- AddScriptItem(0);
	-- AddScriptItem(0);
	-- AddScriptItem(0);
	-- AddScriptItem(2);
	-- AddScriptItem(2);
	-- AddScriptItem(2);
	-- AddScriptItem(70);
	-- AddScriptItem(15);
	-- AddScriptItem(16);
	-- end;
	-- SetTitle(258);
	
	-- ClearMapNpcWithName(53,"N�i ch�o y�u th��ng");
	-- local nPlayerIndex = PlayerIndex;
	-- local IDTong;
	-- for i = 1,300 do
		-- PlayerIndex = i
			-- nW,nX,nY = GetWorldPos()
			-- if (nW ~= 380) then
				-- SetTitle(GetTask(self.tbTask.LAST_TITLE))
				-- SetTask(ZBattle.tbTask.LAST_TITLE, 0)
				-- SetTask(ZBattle.tbTask.SERIES,0)
				-- SetTask(ZBattle.tbTask.SERIES_POINT,0)
				-- SetTaskTemp(ZBattle.tbTaskTmp.TITLE,0)
				-- SetTaskTemp(ZBattle.tbTaskTmp.LAST_DEATH,0)
				-- SetTaskTemp(ZBattle.tbTaskTmp.ANTI_POST,0)
				-- SetTask(ZBattle.tbTask.LAST_JOIN, 0);
				-- if (nW ~= 1 and nW ~= 53) then
				 -- SetFightState(0)
				-- end;
			-- end;
			-- if (nW ~= 1 and nW ~= 53) then
				 -- SetFightState(1)
				-- end;
		-- if GetName() == "DuongGiaTuong" then
		
			-- for i = 1,3 do
			-- nIndex = AddScriptItem(131,2); --STG le hop;
			-- SetItemBindState(nIndex,2);
			-- nIndex = AddTaskItem(12,2); --LB PLD;
			-- SetItemBindState(nIndex,2);
			-- nIndex = AddScriptItem(4,2); --TTL DB;
			-- SetItemBindState(nIndex,2);
			-- nIndex = AddScriptItem(6,2); --Que hoa tuu;
			-- SetItemBindState(nIndex,2);
			-- end;
			-- for i = 1,5 do
			-- nIndex = AddTaskItem(59,2); --Hoa toc trieu lenh;
			-- SetItemBindState(nIndex,2);
			-- end;
			-- Earn(1500000);
			-- AddMagic(325,20);
			-- SetTask(7,0);
			-- SetTask(300,0);
			-- for i = 302,318 do
				-- SetTask(i,0);
			-- end;
			-- SetTitle(0);
			-- AddMagic(321,20);
			-- while(GetLevel() < 137) do
			-- AddOwnExp(50999999)
			-- end
			-- SetLevel(118);
			-- for i = 1,50 do
			-- AddScriptItem(115)
			-- end;
			-- SetTask(T_EVENT_MAX1,500);
			-- SetTask(600,0);
			-- SetTask(601,0);
			-- SetLogoutScript(""); 
			-- SetDeathScript("");  
			-- ForbidChangePK(0);
			-- SetFightState(0);
			-- SetPunish(0);
			-- SetLogoutRV(0)
			-- SetRevPos(53,19);
			-- ForbidTownPortal(0);
			-- AddOwnExp(5000000)
			-- Msg2Player("nh�n ���c <color=pink>5.000.000 �i�m kinh nghi�m<color> t� H�ng�Cu�B�");
			-- IDTong = GetTongName();
			
			-- Msg2Player("GM Check Test");
		-- end;
	-- end;
	-- PlayerIndex = nPlayerIndex;
	-- Msg2Player(" "..IDTong.." ")
	-- Msg2SubWorld("K�nh th�ng tin li�n l�c:\nGroup: https://www.facebook.com/groups/volamhuyenthietkiem/\nWebsite: jx-online.com");
	-- Msg2SubWorld("Th�i gian b�o tr� m�y ch� di�n ra v�o 18h00\n Th�i gian support ho�t ��ng: 10h00 -> 23h00");
	-- for i = 1,20 do
		-- AddTaskItem(12);
	-- end;
	-- local n = GetTask(0);
	-- Msg2Player(" "..GetItemCountInBag(6,19,0,0).." ")
	-- for i = 1,30 do
	-- AddScriptItem(136)
	
	-- end;
	-- ChangeOwnFeature(1204,733,999999)
	-- release2bosstieu();
	-- ClearMapNpcWithName(53,"D�m T�c");
	-- AddGoldItem(207);
	--AddItem(0,10,30,10,0,0,0)
	--end;
	--SetTask(600,3);
	--SetTask(602,3);
	-- for i = 1,50 do
		-- AddTaskItem(28);
	-- end;
	--NewWorld(336,1158,2964);
	-- SetTask(TASK_DT_TOTAL,300);
	-- SetTask(TASK_DT_REWAR40,0);
	-- SetTask(TASK_DT_REWAR40,0);
	-- SetTask(TASK_COUNT_QUEST,0);
	-- for i = 729,734 do
		-- Msg2Player(" "..GetTask(i).."");
		-- SetTask(i,0);
	-- end;
	--AddItem(0,0,0,10,1,GetLucky(0),10);
	SetRank(9);
	SetTitle(20);
end;

function OnExchangeItem()
	-- if not nCount or nCount == 0 or nCount > 1 then 
		-- Talk(1,"","y�u c�u b� 1 th� v�o. ")
		-- return 0
	-- end
	local nItemIdx, nG, nD, nP, nL, Ser
	local ROOMG = 8; --ID MAC DINH CUA GIVE BOX
	local i = 0;
	if ROOMG ~= 8 then
	return
	end	
	for i=0,5 do
		for j=0,3 do	
			nItemIdx = GetROItem(ROOMG,i,j);	
			nG, nD, nP, nL, Ser, nLuc = GetItemProp(nItemIdx)
			if (nG ~= -1 or nD ~= -1 or nP ~= -1 or nL ~= -1 or Ser ~= -1) then
				Msg2Player(" "..nItemIdx.." "..nG.." - "..nD.." - "..nP.." - "..nL.." - "..Ser.." - "..nLuc.." ");
				local nOp1,nValueMin1,nValueMax1,zValueMax1 = GetItemMagicAttrib(nItemIdx,1); -- hien 1
				local nOp2,nValueMin2,nValueMax2,zValueMax2 = GetItemMagicAttrib(nItemIdx,2); -- an 1
				local nOp3,nValueMin3,nValueMax3,zValueMax3 = GetItemMagicAttrib(nItemIdx,3); -- hien 2
				local nOp4,nValueMin4,nValueMax4,zValueMax4 = GetItemMagicAttrib(nItemIdx,4); -- an 2
				local nOp5,nValueMin5,nValueMax5,zValueMax5 = GetItemMagicAttrib(nItemIdx,5); -- hien 3
				local nOp6,nValueMin6,nValueMax6,zValueMax6 = GetItemMagicAttrib(nItemIdx,6); -- an 3			
				
				Msg2Player( "Hien1: "..nOp1.." - "..nValueMin1.." - "..nValueMax1.." - "..nValueMax1.."");
				Msg2Player( "An1: "..nOp2.." - "..nValueMin2.." - "..nValueMax2.." - "..nValueMax2.."");
				Msg2Player( "Hien2: "..nOp3.." - "..nValueMin3.." - "..nValueMax3.." - "..nValueMax3.."");
				Msg2Player( "An2: "..nOp4.." - "..nValueMin4.." - "..nValueMax4.." - "..nValueMax4.."");
				Msg2Player( "Hien3: "..nOp5.." - "..nValueMin5.." - "..nValueMax5.." - "..nValueMax5.."");
				Msg2Player( "An3: "..nOp6.." - "..nValueMin6.." - "..nValueMax6.." - "..nValueMax6.."");
				DelItemByIndex(nItemIdx);
				-- nItemIdx = AddItem(nG,nD,nP,nL,Ser,0,0);
				-- nItemIdx = AddItem(nG,nD,nP,nL,Ser,nLuc,0);
				-- nItemIdx= AddItem(nG,nD,nP,nL,Ser);
			end
		end
	end
end

function ReceiveReward()--nhan thuong
	Tab_Button = {
	{1,2,3},{1,3,2},{2,1,3},{2,3,1},{3,1,2},{3,2,1},
	{1,2,4},{1,4,2},{2,1,4},{2,4,1},{4,1,2},{4,2,1},
	{1,3,4},{1,4,3},{3,1,4},{3,4,1},{4,1,3},{4,3,1},
	{3,2,4},{3,4,2},{2,3,4},{2,4,9},{4,1,3},{4,3,1},
	{9,2,4},{9,4,2},{9,3,4},{9,4,3},{9,1,2},{9,3,1},
	{1,9,4},{1,4,9},{9,1,4},{9,4,1},{4,9,1},{4,3,9},
	{1,2,9},{1,9,2},{2,1,9},{2,9,1},{9,1,2},{9,2,1},
	};
	local nRandom = random(1,getn(Tab_Button))
	local Reward1 = Tab_Button[nRandom][1]
	local Reward2 = Tab_Button[nRandom][2]
	local Reward3 = Tab_Button[nRandom][3]
	-- SetTask(175,Reward1)
	-- SetTask(176,Reward2)
	-- SetTask(177,Reward3)
	OpenReWardBox("D� T�u: Xu�t s�c ho�n th�nh th� th�ch!, h�y ch�n ph�n th��ng!" ,""..Reward1.."|RwardAccept1",""..Reward2.."|RwardAccept2",""..Reward3.."|RwardAccept3");
end
----------------------------
--
----------------------------
-- function SelectTrainning()
-- Station:Station(10356);
-- end;
----------------------------
--
----------------------------
function Shop()
Sale(2);
end;
----------------------------
--
----------------------------
function ExPandBox()
	local szHello ="<color=red>H� Th�ng:<color> Xin ch�o!"
	Tab_inSert = {
	"M� r��ng 1/ID_ExPandBox",
	"M� r��ng 2/ID_ExPandBox",
	"M� r��ng 3/ID_ExPandBox",
	"M� r��ng 4/ID_ExPandBox",
	"M� r��ng 5/ID_ExPandBox",
	"M� t�i h�nh trang/ID_EquipItemBox",
	"Ki�m tra r��ng �� m�/ID_GExPandBox",
	"Ta kh�ng c�n ng��i d�y b�o/no"
	}
	Say(szHello,getn(Tab_inSert),Tab_inSert);
end

----------------------------
--
----------------------------
function ID_ExPandBox(nSel)
	local nSel = nSel + 1 ;
	SetStoreBox(nSel);
	Msg2Player("C�c h� �� m� th�nh c�ng r��ng "..nSel.."");
end

function ID_EquipItemBox()
	SetExPandBox(1);
	Msg2Player("C�c h� �� m� th�nh c�ng t�i h�nh trang!");
end
function ID_GExPandBox()
	Msg2Player("C�c h� �� m� ��n r��ng th� "..GetStoreBox().."");
end
----------------------------
--
----------------------------
function movetoBLH()
	SetFightState(0);
	NewWorld(53,1582,3237);
	Msg2Player("Ng�i y�n! ch�ng ta �i Ba L�ng Huy�n.");
end
----------------------------
--
----------------------------
function ServerRemote()
local nW,nX,nY = GetWorldPos()
local szHello = "<color=red>H� Th�ng:<color> <color=orange>Cu�c s�ng n�y bi�t bao �i�u tu�i ��p, Minh Qu�n xin h�y b�nh t�nh suy x�t\n<color=green>T�a �� hi�n t�i: B�n ��: "..nW.." - X: "..nX.."-Y: "..nY..""
	Tab_inSert = {
	"Kh�i ��ng T�ng Kim/ActiveBattle",
	"Kh�i ��ng Li�n ��u/ActiveLienDau",
	"Kh�i ��ng V��t �i/ActiveVuotAi",
	"Kh�i ��ng Phong L�ng ��/ActiveFeiling",
	"Kh�i ��ng Qu� Huy Ho�ng/ActiveHuyHoang",
	"Kh�i ��ng H�t Ho�ng Kim/ActiveQuaHoangKim",
	"Kh�i ��ng Lo�n Chi�n/ActiveLoanChien",
	"Kh�i ��ng Boss Test/ActiveBoss",
	"Kh�i ��ng N�i ch�o y�u th��ng/ActiveNoiChao",
	"Kh�i ��ng Ho�t ��ng PK Bang/ActivePKTong",
	"Kh�i ��ng m�y ch�/OpenServer",
	"Kh�a m�y ch�/CloseServer",
	"Ki�m tra Online/TestALL",
	"Ta kh�ng c�n ng��i d�y b�o/no"
	}
	Say(szHello,getn(Tab_inSert),Tab_inSert);
end;

function ActiveBattle() 
	local nOldSubWorld = SubWorld;
	SubWorld = SubWorldID2Idx(380);
	OpenMission(3);
	-- CloseMission(3)
	SubWorld = nOldSubWorld;
	Msg2SubWorld("Admin kh�i ��ng th�nh c�ng T�ng kim ");
end;

function ActiveLienDau()
	local nOldSubWorld = SubWorld;
	SubWorld = SubWorldID2Idx(396);
	OpenMission(5);
	Msg2SubWorld("Admin kh�i ��ng th�nh c�ng Li�n ��u ");
	SubWorld = nOldSubWorld;
end;

function ActiveVuotAi()
	local nOldSubWorld = SubWorld;
	for i = 464,470 do
		SubWorld = SubWorldID2Idx(i); --mutil vuot ai;
		OpenMission(VA.MAIN.MISSION_VA);
	end;
	SubWorld = nOldSubWorld;
	Msg2SubWorld("Admin kh�i ��ng th�nh c�ng v��t �i ");
end;

function ActiveFeiling()
	local nOldSubWorld = SubWorld;
	for i = 337,339 do
		SubWorld = SubWorldID2Idx(i); -- mutil ben thuyen;
		OpenMission(PLD.MAIN.MISSION_PLD);
	end;
	SubWorld = nOldSubWorld;
	Msg2SubWorld("Admin kh�i ��ng th�nh c�ng Phong L�ng �� ");
end;
Include("\\script\\event\\quahuyhoang\\head.lua");
function ActiveHuyHoang()
	AddHatHuyHoang();
	Msg2SubWorld("Admin kh�i ��ng th�nh c�ng qu� Huy ho�ng ");
end;
function ActiveQuaHoangKim()
	AddHatHoangKim();
	Msg2SubWorld("Admin kh�i ��ng th�nh c�ng qu� Ho�ng kim ");
end;

function ActiveLoanChien()
	local nOldSubWorld = SubWorld;
	SubWorld = SubWorldID2Idx(LC.MAIN.MAP_FIGHT); -- loan chien map;
	OpenMission(LC.MAIN.MISSION_LC);
	SubWorld = nOldSubWorld;
	Msg2SubWorld("Admin kh�i ��ng th�nh c�ng Lo�n chi�n ");
end;

function ActiveBoss()
	Include("\\script\\npclib\\goldboss\\bosstieuhk.lua");
	releasebosstieu();
	Msg2SubWorld("Admin kh�i ��ng th�nh c�ng Boss ti�u ho�ng kim ");
end;

function ActiveNoiChao()
	Include("\\script\\event\\noichao\\head.lua");
	releasenoichao();
	Msg2SubWorld("Admin kh�i ��ng th�nh c�ng N�i ch�o y�u th��ng");
end;

function OpenServer()
	SetGlbMissionV(GBM_OPEN_SERVER,1);
	print("Active Server Huyen thiet Kiem Kinnox Sucessfull!");
	Msg2SubWorld(""..SYS_NAME_SERVER.."<color=green> ch�nh th�c kh�i ��ng, m�i c�c qu� ��ng ��o b�n t�u giang h�. Xin c�m �n qu� ��ng ��o �� �ng h�, ch�c c�c h� b�n t�u vui v�!<color>");
	AddGlobalNews("M�y ch� "..SYS_NAME_SERVER.." ch�nh th�c ra m�t. Ch�c qu� ��ng ��o b�n b�u vui v�!");
end

function CloseServer()
	SetGlbMissionV(GBM_OPEN_SERVER,0);
	print("Close Server "..SYS_NAME_SERVER.." Sucessfull!");
	Msg2SubWorld(""..SYS_NAME_SERVER.."<color=green> ��a v� tr�ng th�i ch� khai m�, qu� ��ng ��o vui l�ng ch� ��i<color>");
	AddGlobalNews("M�y ch� "..SYS_NAME_SERVER.." ��a v� tr�ng th�i ch� khai m�, qu� ��ng ��o vui l�ng ch� ��i");
end;

function ActivePKTong()
	Include("\\script\\event\\pkbang\\head.lua");
	AddBossBang();
	Msg2SubWorld("Admin kh�i ��ng th�nh c�ng ho�t ��ng PK Bang");
end;

function TestALL()
Talk(1,"","So luong Acc online : "..GetPlayerCount().." - "..tonumber(date("%H"))..":"..tonumber(date("%M")).."\nNPC:"..GetNpcCount().."\nITEM:"..GetItemCount().."\nOBJ:"..GetObjCount().." ") 		-- print so acc online ra GS
end;
function no()
end