Include("\\script\\lib\\tasklib.lua");
Include("\\script\\mission\\vuotai\\head.lua");
--Author: Kinnox;
--Date: 17/04/2022;
function OnUse(nIndex)
	-- dofile("script/item/luascript/longhuyethoan.lua")
	if (GetTask(VA.TASK.TVA_JOIN_BOAT) <= 0) then
		Talk(1,"","��i hi�p ch�a tham gia v��t �i");
		return
	end;
	if (GetTask(VA.TASK.TVA_JOIN_BOAT) > 0) then
		SetTask(VA.TASK.TVA_JOIN_BOAT,GetTask(VA.TASK.TVA_JOIN_BOAT) - 1);
		Talk(1,"","��i hi�p s� d�ng v�t ph�m th�nh c�ng!. S� l�n tham gia v��t �i hi�n t�i c�n l�i l� "..(3-GetTask(VA.TASK.TVA_JOIN_BOAT)).."");
	end;
	return 1;
end;