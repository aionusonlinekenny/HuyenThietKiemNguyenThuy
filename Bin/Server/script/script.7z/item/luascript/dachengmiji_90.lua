-- Author:	Kinnox
-- Date:	15-11-2022
-- ��i th�nh b� k�p 9x
Include("\\script\\global\\luanpcfactions\\faction_head.lua")


function OnUse(nIdx)
	if(GetHandItem() > 0) then
		Talk(1,"",10267)
		return 0
	end
	
	if(GetLevel() < 80) then
		Talk(1,"","��ng c�p d��i 80 kh�ng th� h�c ��i th�nh b� k�p")
		return 0
	end
	local nFactionID = GetFactionNo() + 1
	if(nFactionID == 0) then
		Talk(1,"","Ch�a gia nh�p m�n ph�i kh�ng th� h�c ��i th�nh b� k�p.")
		return 0
	end
	local tbSay = {}
	local i
	for i = 1, getn(Faction.TFACTION_INFO[nFactionID].tbSkill90) do
		if(nFactionID == 3) then
			if(i > 4) then
				break
			end
		elseif (nFactionID == 0) or (nFactionID == 1) or (nFactionID == 2) or (nFactionID == 4) or (nFactionID == 5) or (nFactionID == 8) or (nFactionID == 10)  then
			if (i > 3 ) then
				break
			end;
		else
			if(i > 2) then
				break
			end
		end
		tinsert(tbSay, format("%s./OnLearn",Faction.TFACTION_INFO[nFactionID].tbSkill90[i][1]))
	end
	tinsert(tbSay, "Kh�ng mu�n h�c./OnExit")
	SetTaskTemp(0, nIdx)
	Say("Xin m�i l�a ch�n k� n�ng c�n h�c",getn(tbSay), tbSay)
	return 0
end


function OnLearn(nSel)
	local i = tonumber(nSel) + 1
	local nFactionID = GetFactionNo() + 1
	if(nFactionID == 0) then
		Talk(1,"","C� l�i x�y ra vui l�ng b�o GM.")
		return
	end
	if(not Faction.TFACTION_INFO[nFactionID].tbSkill90[i]) then
		Talk(1,"","C� l�i x�y ra vui l�ng b�o GM.")
		return
	end
	local nItemIdx = GetTaskTemp(0)
	if(nFactionID == 3) then
		if(i > 4) then
			Talk(1,"","K� n�ng n�y kh�ng th� h�c ��i th�nh b� k�p.")
			return
		end
	elseif (nFactionID == 1) or (nFactionID == 2) or (nFactionID == 4) or (nFactionID == 5) or (nFactionID == 8) or (nFactionID == 10)  then
		if (i > 3 ) then
			Talk(1,"","K� n�ng n�y kh�ng th� h�c ��i th�nh b� k�p.")
			return
		end;		
	else
		if(i > 2) then
			Talk(1,"","K� n�ng n�y kh�ng th� h�c ��i th�nh b� k�p.")
			return
		end
	end
	local nSkillID = Faction.TFACTION_INFO[nFactionID].tbSkill90[i][2]
	if( HaveMagic(nSkillID) >= 20 ) then
		Talk(1,"","K� n�ng n�y �� �� ��ng c�p t�i �a, kh�ng th� h�c ��i th�nh b� k�p.")
		return
	end

	if(DelItemByIndex(nItemIdx) == 0) then
		Say(10002,0)
		return
	end	
	
	AddMagic(nSkillID, 20)
	Talk(1,"","�� h�c ��i th�nh b� k�p th�nh c�ng.")
end

function OnExit()

end;