-- Author:	Kinnox
-- Date:	31-05-2021
-- Th� vi�n v�t ph�m

if(not ITEM_HEAD) then
ITEM_HEAD = 1

ZUseItem = {}

ZUseItem.tbExpTime = {
--  ID	 Time	Name
	[3] = {60, "Ti�n Th�o L�"},
	[4] = {480, "Ti�n Th�o L� ��c bi�t"},
}

ZUseItem.tbSkillTime = {
	[0] = {60, "Hu� Tuy�n T�u"},
	[14] = {480, "N� Nhi H�ng"},
}

ZUseItem.MAX_FRUIT_PER_DAY = 5
ZUseItem.MAX_GOLD_FRUIT_DAY = 1
ZUseItem.MAX_GOLD_FRUIT = 7
ZUseItem.TV_LIMIT_FRUIT = 40

ZUseItem.tbFuYuan = {
	[11] = {10, "Ph�c Duy�n L� (ti�u)"},
	[12] = {20, "Ph�c Duy�n L� (trung)"},
	[13] = {50, "Ph�c Duy�n L� (��i)"},
}

end