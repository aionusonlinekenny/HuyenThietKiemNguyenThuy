-- Author:	Kinnox
-- Date:	31-05-2021
-- Thi�n S�n B�o L�
Include("\\script\\item\\luascript\\head.lua")
TV_THIENSOWNBAOLO = 2019;

function OnUse(nIdx)
	if(GetHandItem() > 0) then
		Talk(1,"",10267)
		return 0
	end
	local _, nD, _ = GetItemProp(nIdx)
	local nCurTime = GetTask(TV_THIENSOWNBAOLO)
	local nTimeAdd = 30*60*18
	if(nCurTime > 0) then
		Say("C�n <color=red>"..floor(nCurTime/18).." gi�y<color> may m�n, kh�ng th� s� d�ng <color=green> Thi�n s�n b�o l� <color>.", 0)
		return 0
	end
	AddSkillState(441, 1, 1, nTimeAdd)
	SetTask(TV_THIENSOWNBAOLO, nTimeAdd)
	Msg2Player("��i hi�p �� u�ng <color=green> Thi�n S�n B�o L� <color>.")
	return 1
end