--Author: Kinnox;
--Date: 17/04/2022;
Include("\\script\\lib\\Revivepos.lua")
function OnUse(nIndex)
	--dofile("script/item/luascript/lenhbaigoiboss.lua")
	local nW,nX,nY = GetWorldPos();
	local szName = GetName();
	local szMapName = GetMapName(nW);
	nX = nX*32;
	nY = nY*32;
	if (CheckMapNoForTHP(nW) == 1) then
		Talk(1,"", "Kh�ng th� tri�u h�i boss � ��y.")
	return end	
	
	if (GetFightState() < 1) then
		Talk(1,"","Tr�ng th�i phi chi�n ��u kh�ng th� tri�u h�i boss");
		return
	end;
	
	local nNpcIndex = 0;

	local SubWorld = SubWorldID2Idx(nW);
	nNpcIndex = AddNpc(RANDOMC(513,523,511), 95, SubWorld, nX, nY, 1, szName, 2, 0);
	SetNpcName(nNpcIndex,"��o t�c "..szName.."");
	SetNpcReduceDamge(nNpcIndex, 60);	
	SetNpcScript(nNpcIndex, "\\script\\global\\luanpcmonsters\\ondeath_normal.lua")
	--Msg2SubWorld(" ��i hi�p "..GetName().." tri�u h�i Boss HK "..szName.." t�i "..floor(nX/256).." - "..floor(nY/512).." "..szMapName.." ");
	Msg2SubWorld(" ��i hi�p <color=green>"..szName.."<color> tri�u h�i <color=yellow>Boss HK ��o t�c "..szName.."<color> t�i m�t n�i n�o ��!. ");
	
	return 1;
end;