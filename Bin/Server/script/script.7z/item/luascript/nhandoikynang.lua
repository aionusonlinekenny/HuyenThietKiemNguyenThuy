-- Author:	SkyGold
-- Date:	15-09-2015
-- Hu� Tuy�n T�u (k� n�ng)
Include("\\script\\item\\head.lua")


function OnUse(nIdx)
	if(GetHandItem() > 0) then
		Talk(1,"",10267)
		return 0
	end
	local _, nD, _ = GetItemProp(nIdx)
	local nCurTime = GetTask(2014)
	if(nCurTime >= 1 ) then
		Say("C�n <color=red>"..floor(nCurTime/18).." gi�y<color> nh�n 2 kinh nghi�m k� n�ng, kh�ng th� s� d�ng <color=green>N� Nhi H�ng<color> them.", 0)
		return 0
	end
	
	SetTask(2014, (8*60*60*18) )
	Msg2Player("B�n �� u�ng <color=green>N� Nhi H�ng<color>.")
	return 1
end