-- Author:	Kinnox
-- Date:	31-05-2021
-- Qu� Hoa T�u
Include("\\script\\item\\luascript\\head.lua")
TV_QUEHOATUU = 2018;
function OnUse(nIdx)
	if(GetHandItem() > 0) then
		Talk(1,"",10267)
		return 0
	end
	local nName = GetName()
	local nTeamSize = GetTeamSize()
	local nCurTime = GetTask(TV_QUEHOATUU)
	local nTimeAdd = 32400
	if(nCurTime > 0) then
		Say("C�n <color=red>"..floor(nCurTime/18).." gi�y<color> may m�n, kh�ng th� s� d�ng <color=green> Qu� hoa t�u <color>.", 0)
		return 0
	end

	if(nTeamSize > 1) then -- cai nay co team
		for i = 1, nTeamSize do
			PlayerIndex = GetTeamMember(i);
			if PlayerIndex and PlayerIndex > 0 then 
				Msg2Player(""..nName.." d�ng <color=green>Qu� Hoa T�u <color>.")
				AddSkillState(450, 1, 1, nTimeAdd)			
				SetTask(TV_QUEHOATUU, nTimeAdd)
			end
		end
	else -- cai nay danh 1 minh
		Msg2Player("��i hi�p �� u�ng <color=green>Qu� Hoa T�u <color>.")
		AddSkillState(450, 1, 1, nTimeAdd)
		SetTask(TV_QUEHOATUU, nTimeAdd)
	end
	return 1
end
