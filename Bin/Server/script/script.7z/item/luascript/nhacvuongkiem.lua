----------------------------------
--	Copyright: JX Online by Blood Team
--	Author: [S]
--	Date: 16/08/2014
--	Desc: nhac vuong kiem
----------------------------------

----------------------------------
--
----------------------------------
function OnUse(nIdx)
	if(GetHandItem() > 0) then
		Talk(1,"",10267)
		return 0
	end
	AddTaskItem(13);
	Msg2Player("��i hi�p nh�n ���c 1 Nh�c v��ng ki�m, v�t ph�m qu� �� th�nh l�p bang h�i");
	return 1
end