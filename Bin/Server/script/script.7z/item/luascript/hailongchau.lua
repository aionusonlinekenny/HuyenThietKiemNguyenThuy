Include("\\script\\lib\\tasklib.lua");
Include("\\script\\mission\\phonglangdo\\head.lua");
--Author: Kinnox;
--Date: 17/04/2022;
function OnUse(nIndex)
	-- dofile("script/item/luascript/hailongchau.lua")
	if (GetTask(PLD.TASK.TPLD_JOIN_BOAT) <= 0) then
		Talk(1,"","��i hi�p ch�a tham gia phong l�ng ��");
		return
	end;
	if (GetTask(PLD.TASK.TPLD_JOIN_BOAT) > 0) then
		SetTask(PLD.TASK.TPLD_JOIN_BOAT,GetTask(PLD.TASK.TPLD_JOIN_BOAT) - 1);
		Talk(1,"","��i hi�p s� d�ng v�t ph�m th�nh c�ng!. S� l�n tham gia phong l�ng �� hi�n t�i c�n l�i l� "..(3-GetTask(PLD.TASK.TPLD_JOIN_BOAT)).."");
	end;
	return 1;
end;