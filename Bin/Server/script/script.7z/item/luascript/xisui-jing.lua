----------------------------------
--	Copyright: JX Online by Blood Team
--	Author: [S]
--	Date: 16/08/2014
--	Desc: T�y t�y kinh
----------------------------------
Include("\\script\\lib\\TaskLib.lua")
----------------------------------
--
----------------------------------
function OnUse(nIdx)
	if(GetHandItem() > 0) then
		Talk(1,"",10267)
		return 0
	end
	if(GetLevel() < 80) then
		Talk(1,"","Ch�a ��t <color=red>��ng c�p 80<color>, kh�ng th� s� d�ng T�y T�y Kinh.")
		return 0
	end
	local nCurPoint = GetTask(T_TTK) + 5;
	if(nCurPoint > 75) then
		Talk(1,"","�� tu luy�n �� <color=green>15 quy�n<color> T�y T�y Kinh! Kh�ng th� ti�p t�c tu luy�n!")
		return 0
	end
	SetTask(T_TTK,nCurPoint)
	AddProp(5)
	Talk(1,"","Tu luy�n n�a ng�y nh�n ���c <color=green>5 �i�m ti�m n�ng<color>! �� tu luy�n <color=red>"..(nCurPoint/5).." quy�n<color>.")
	return 1
end