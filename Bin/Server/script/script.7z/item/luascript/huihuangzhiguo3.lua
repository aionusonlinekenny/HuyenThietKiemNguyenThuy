Include("\\script\\item\\huihuangzhiguo.lua")
huihuangzhiguo_level = 3
