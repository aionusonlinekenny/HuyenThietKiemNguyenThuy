Include("\\script\\lib\\tasklib.lua")
MAX_HUYHOANG = 5
MAX_HOANGKIM = 1
function OnUse(nIdx)
	local Msg = "H�m nay ��i hi�p �� �n <color=yellow> �� s� qu�<color>, v� c�ng th�ng ti�n qu� nhanh d� g�y t�c d�ng ph�n ngh�ch, ng�y mai h�y ti�p t�c v�y"
	if(GetHandItem() > 0) then
		Talk(1,"","<color=red>Tr�n tay c� v�t ph�m, kh�ng th� thao t�c.<color>")
		return 0
	end
	local szfruitlname = "";
	local award_exp = 0;
	local nPlayerLevel = GetLevel();	
	local _, nD, _ = GetItemProp(nIdx);
	
	if (nD >= 7 and nD <=9) then
		if (GetTask(T_LIMIT_HUYHOANG) > MAX_HUYHOANG) then
			Talk(1,"",Msg);
		return 0;
		end;
	else
		if (GetTask(T_LIMIT_HOANGKIM) > MAX_HOANGKIM) then
			Talk(1,"",Msg);
		return 0;
		end;
	end;
	
	
	if (nD == 7) then
		szfruitlname = "H�t huy ho�ng s� c�p"
		if (nPlayerLevel < 80) then
			award_exp = 500000;
		else
			Msg2Player(""..szfruitlname.." d�nh cho nh�ng k� v� danh ti�u t�t c� ��ng c�p d��i 80");
			return 0;
		end;
	elseif (nD == 8) then
		szfruitlname = "H�t huy ho�ng trung c�p"
		if (nPlayerLevel >= 80 and nPlayerLevel < 100) then
			award_exp = 1500000;
		else
			Msg2Player(""..szfruitlname.." d�nh cho nh�ng ��i hi�p c� ��ng c�p t� 80 ��n 100");
			return 0;
		end;
	elseif (nD == 9) then
		szfruitlname = "H�t huy ho�ng cao c�p"
		if (nPlayerLevel >= 100 ) then
			award_exp = 2500000;
		else
			Msg2Player(""..szfruitlname.." d�nh cho nh�ng ��i hi�p c� ��ng c�p t� 100 tr� l�n");
			return 0;
		end;
	else
		szfruitlname = "H�t ho�ng kim"
		if (nPlayerLevel >= 100) then
			award_exp = 5500000;
		else
			Msg2Player(""..szfruitlname.." d�nh cho nh�ng ��i hi�p c� ��ng c�p t� 100 tr� l�n");
			return 0;
		end;
	end;
	
	AddOwnExp(award_exp);
	if (nD >= 7 and nD <= 9) then
		SetTask(T_LIMIT_HUYHOANG,GetTask(T_LIMIT_HUYHOANG)+1);
		return 1
	else
		SetTask(T_LIMIT_HOANGKIM,GetTask(T_LIMIT_HOANGKIM)+1);
		return 1
	end;	
	
end;
