Include("\\script\\event\\noichao\\head.lua")
function main(nNpcIndex)
	TimeBox("�ang �n ch�o...",90,"noichao",tonumber(nNpcIndex));
end;

function noichao(nNpcIndex)
	if (FindAroundNpc(GetNpcID(2,nNpcIndex)) == 0) then
	return end

	nNumberChao = nNumberChao + 1;
	if (nNumberChao > nMaxNumberChao) then
		DelNpc(nNpcIndex);
		nNumberChao = 0;
	end;
	local nRanExp = random(100000,5000000);
	AddOwnExp(nRanExp)
	Msg2Player("��i hi�p <color=pink> "..GetName().." <color> v�a �n xong m�t b�t ch�o y�u th��ng l�nh h�i ���c <color=yellow>"..nRanExp.." kinh nghi�m <color>")
end
