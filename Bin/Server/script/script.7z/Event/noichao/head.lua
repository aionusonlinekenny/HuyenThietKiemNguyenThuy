nMaxNumberChao = 30;
nNumberChao = 0;
Include("\\script\\system_config.lua");
COMMON_INFOS = "<color=Yellow> N�i ch�o y�u th��ng <color> xu�t hi�n t�i %s t�a �� <color=green> %d/%d <color>, kinh nghi�m l�n ��n 5tr EXP, s� l��ng c� h�n."

CODINATE = { 
	{1275,51488,102784,53,"Ba l�ng huy�n"},
	{1275,51872,102144,53,"Ba l�ng huy�n"},
	{1275,50976,103104,53,"Ba l�ng huy�n"},
}
function releasenoichao()
	local nNpcIndex = 0;
	local nPos = 1;
	for i=1,getn(CODINATE) do
		local SubWorld = SubWorldID2Idx(CODINATE[i][4]);
		nNpcIndex = AddNpc(CODINATE[i][1], 95, SubWorld, CODINATE[i][2], CODINATE[i][3], 1, "N�i ch�o", 0, 3);
		SetNpcScript(nNpcIndex, "\\script\\event\\noichao\\noichao.lua");
		if(nNpcIndex > 0) then
			Msg2SubWorld(format(COMMON_INFOS,
			CODINATE[i][5],
			floor(CODINATE[i][2]/256),
			floor(CODINATE[i][3]/512)));
			AddLocalNews("N�i ch�o y�u th��ng xu�t hi�n!");
		end
	end
	for i = 1,SYS_MAX_PLAYER do
		PlayerIndex = i;
		SendNotification("","(Lo) <color=red>Th�ng b�o: <color> <color=green>N�i ch�o y�u th��ng :0<color> xu�t hi�n t�i Ba l�ng huy�n t�a �� <color=green> 201/200 <color> <pic="..random(1,140).."> <pic="..random(1,140).."> !");
	end;
end;