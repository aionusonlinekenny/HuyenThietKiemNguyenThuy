-- Author: Kinnox
-- Date: 12/04/2022
-- Chuc nang: Thuc thi
Include("\\script\\event\\hoadang\\head.lua")
Include("\\script\\lib\\tasklib.lua")
MAX_NUM = 90;
function main(NpcIndex)
	local nFactionID = GetFactionNo() + 1;
	if nFactionID <= 0 then
		Talk(1,"","��i hi�p ch�a v�o m�n ph�i kh�ng th� tham gia.")
	return end	
	
	if GetTask(T_REPCAUHOI) >= MAX_NUM then
		Talk(1,"", "Ng��i �� tr� l�i ho�n th�nh "..MAX_NUM.." c�u h�i.")
	return end	
	
	SetTask(T_REPCAUHOI,GetTask(T_REPCAUHOI)+1)
	cauhoi(NpcIndex)
	AddSkillState(764,1,0,18*10);
end

function cauhoi(NpcIndex)
	-- local nValue = GetNpcValue(NpcIndex);
	
	local i = random(1,getn(CAUHOI))
	local a = random(1,4)
	
	if a == 1 then
		Say(CAUHOI[i][1] , 4,
			"A. "..CAUHOI[i][2].."/correct",
			"B. "..CAUHOI[i][3].."/wrong",
			"C. "..CAUHOI[i][4].."/wrong",
			"D. "..CAUHOI[i][5].."/wrong")
	elseif a == 2 then
		Say(CAUHOI[i][1] , 4,
			"A. "..CAUHOI[i][5].."/wrong",
			"B. "..CAUHOI[i][2].."/correct",
			"C. "..CAUHOI[i][3].."/wrong",
			"D. "..CAUHOI[i][4].."/wrong")
	elseif a == 3 then
		Say(CAUHOI[i][1] , 4,
			"A. "..CAUHOI[i][4].."/wrong",
			"B. "..CAUHOI[i][5].."/wrong",
			"C. "..CAUHOI[i][2].."/correct",
			"D. "..CAUHOI[i][3].."/wrong")
	elseif a == 4 then
		Say(CAUHOI[i][1] , 4,
			"A. "..CAUHOI[i][3].."/wrong",
			"B. "..CAUHOI[i][4].."/wrong",
			"C. "..CAUHOI[i][5].."/wrong",
			"D. "..CAUHOI[i][2].."/correct")
	end
	
	-- if (nValue == 0) then
	
	-- return end
	DelNpc(NpcIndex);	
end

function correct()
	local nRand = random(1,2);
	if nRand == 1 then
	AddRepute(random(1,5));
	Msg2Player("Tr� l�i ch�nh x�c c�u  s� "..GetTask(T_REPCAUHOI)..".");		
	else
	AddFuyuan(random(1,5))
	Msg2Player("Tr� l�i ch�nh x�c c�u  s� "..GetTask(T_REPCAUHOI)..".");			
	end
	AddOwnExp(random(500000,2000000));
	local nRandom = random(1,3) 
	if (nRandom == 3) then
		AddTaskItem(RANDOMC(16,18));
		Msg2Player("<color=green>��i hi�p nh�n ���c 1 v�t ph�m qu� hi�m t� ho�t ��ng<color>");
	end;
	SetTask(T_RIGHTQUESTION,GetTask(T_RIGHTQUESTION)+1);
	Msg2Player("Tr� l�i ch�nh x�c t�ng c�ng <color=green>"..GetTask(T_RIGHTQUESTION).."/"..MAX_NUM.."<color>.");				
end


function wrong()
	Msg2Player("R�t ti�c b�n tr� l�i kh�ng ch�nh x�c <color=purple>c�u "..GetTask(T_REPCAUHOI).."<color>.");	
end
