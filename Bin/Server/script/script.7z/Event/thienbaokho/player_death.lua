function OnDeath(nLauncher,nAttacker)
	SetFightState(0);
	SetPunish(0);
	ForbidTownPortal(0);
end;