Include("\\script\\event\\thienbaokho\\head.lua");
function main(nIndex)

	if (GetNpcName(nIndex) == "B�o kh� 01") then
		Baokho(1,PlayerIndex);
	elseif (GetNpcName(nIndex) == "B�o kh� 02") then
		Baokho(2,PlayerIndex);
	elseif (GetNpcName(nIndex) == "B�o kh� 03") then
		Baokho(3,PlayerIndex);
	elseif (GetNpcName(nIndex) == "B�o kh� 04") then
		Baokho(4,PlayerIndex);
	elseif (GetNpcName(nIndex) == "B�o kh� 05") then
		Baokho(5,PlayerIndex);
	elseif (GetNpcName(nIndex) == "B�o kh� 06") then
		Baokho(6,PlayerIndex);
	elseif (GetNpcName(nIndex) == "B�o kh� 07") then
		Baokho(7,PlayerIndex);
	elseif (GetNpcName(nIndex) == "B�o kh� 08") then
		Baokho(8,PlayerIndex);
	elseif (GetNpcName(nIndex) == "B�o kh� 09") then
		Baokho(9,PlayerIndex);	
	end;
end;