Include("\\script\\lib\\tasklib.lua");
Include("\\script\\lib\\libevent.lua");
EXIT = "Ta ch� ��n th�m ng��i/no"
EXP = 20000000
function NpcTalk(nIndex,nNumber)
	--local nNumber = tonumber(nNumber);
	-- Msg2Player("DEBUG "..nNumber.." "..GetNpcID(nIndex).." "..GetNpcName(nIndex).."");
	local szHello = "<color=orange>Thi�n b�o kh� <color>: Ho�n th�nh nhi�m v� Thi�n B�o Kh� nh�n ���c <color=green>"..EXP.."<color> �i�m kinh nghi�m v� m�t ph�n qu� h�p d�n!"
	local EXI
	local tbSay = {};
	if (nNumber == 1) then
		tbSay = {
			"Ta ��n t�m hi�u ho�t ��ng/help",
			"Ta mu�n nh�n nhi�m v�/AcceptQuest",
			"Ta mu�n ti�p t�c nhi�m v�/ContinuteQuest",
			"Ta mu�n r�i kh�i ��y/MoveToBaLang",
			EXIT,
		}
	elseif (nNumber == 3) then
		tbSay = {
			"Ta ��n t�m hi�u ho�t ��ng/help",
			"Ta ��n b�n �� Thi�n B�o Kh�/moveMap",
			"Ta �� ho�n th�nh nhi�m v�/FinishQuest",
			EXIT,
		}
	else
		tbSay = {
			"Ta kh�ng r�i kh�i ��y/moveMap",
			EXIT,
		}
	end;
	Say(szHello,getn(tbSay),tbSay);
end;


function help()
	Talk(1,"","M�i n�y tham gia ���c 1 l�n, khi ho�n th�nh c� th� nh�n ���c "..EXP.." �i�m kinh nghi�m v� m�t ph�n qu� h�p d�n!");
end;

function moveMap()
	SetFightState(0);
	NewWorld(394,1415,3204);
	Msg2Player("Ng�i y�n! ta ��a ng��i ��n Thi�n b�o kh�.");
end;

function AcceptQuest()
	if (GetTask(T_TIN_SU) > 1) then
		Talk(1,"","M�i ng�y ch� ���c tham gia 1 l�n, n�u ng��i c� l�nh b�i Thi�n b�o kh� ta c� th� gi�p �� ng��i th�ng qua");
		return
	end;
	
	if (GetTask(T_TIN_SU) == 1) then
		Talk(1,"","Ng��i �� nh�n nhi�m v� r�i, nh� ng��i n�n ti�p t�c th�c hi�n!.");
		return
	end;
	SetFightState(1);
	SetPunish(1);
	SetRevPos(53,19);
	ForbidTownPortal(1);
	NewWorld(394,1414,3183);
	SetTask(T_TIN_SU,1);
	SetDeathScript("\\script\\event\\thienbaokho\\player_death.lua");
	local tbRan = {};
	tbRan = {
		{5,3,1,2,4},
		{5,4,2,1,3},
		{9,6,7,2,3},
		{6,9,2,1,3},
		{1,5,9,2,4},
		{4,9,3,1,2},
		{8,6,1,2,4},
		{7,6,3,2,4},
		{4,6,8,2,5},
		{3,6,1,8,4},
		{5,6,1,8,4},
		{3,7,1,9,4},
		{3,7,5,9,4},
		{3,7,2,9,4},
		{8,7,2,9,4},
		{1,2,3,4,5},
	}
	local nRan = random(1,getn(tbRan))
	SetTask(T_BK_KEY_1,tbRan[nRan][1])
	SetTask(T_BK_KEY_2,tbRan[nRan][2])
	SetTask(T_BK_KEY_3,tbRan[nRan][3])
	SetTask(T_BK_KEY_4,tbRan[nRan][4])
	SetTask(T_BK_KEY_5,tbRan[nRan][5])
	Msg2Player("Ch� d�n nhi�m v� c�a ng��i l� <color=yellow> "..tbRan[nRan][1].." - "..tbRan[nRan][2].." - "..tbRan[nRan][3].." - "..tbRan[nRan][4].." - "..tbRan[nRan][5].." <color> h�y mau ho�n th�nh!." );
	AddNote("Ch� d�n Thi�n b�o kh� :<color=yellow> "..tbRan[nRan][1].."-"..tbRan[nRan][2].."-"..tbRan[nRan][3].."-"..tbRan[nRan][4].."-"..tbRan[nRan][5].."<color>  ");
	-- Msg2Player("DEBUG<color=yellow> "..GetTask(T_BK_KEY_1).." - "..GetTask(T_BK_KEY_2).." - "..GetTask(T_BK_KEY_3).." - "..GetTask(T_BK_KEY_4).." - "..GetTask(T_BK_KEY_5).." <color> h�y mau ho�n th�nh!." );
end;

function ContinuteQuest()
	local szTask_1 = ""
	local szTask_2 = ""
	local szTask_3 = ""
	local szTask_4 = ""
	local szTask_5 = ""
	if (GetTask(T_TIN_SU) > 1) then
		Talk(1,"","M�i ng�y ch� ���c tham gia 1 l�n, n�u ng��i c� l�nh b�i Thi�n b�o kh� ta c� th� gi�p �� ng��i th�ng qua");
		return
	end;
	if (GetTask(T_TIN_SU) < 1) then
		Talk(1,"","Ng��i ch�a nh�n nhi�m v� l�m sao c� th� ti�p t�c?, hay mau nh�n nhi�m v� �i");
		return
	end;
	if (GetTask(T_BK_KEY_DONE_1) >= 1 and GetTask(T_BK_KEY_DONE_2) >= 1 and GetTask(T_BK_KEY_DONE_3) >= 1  and GetTask(T_BK_KEY_DONE_4) >= 1  and GetTask(T_BK_KEY_DONE_5) >= 1) then
		Talk(1,"","��i hi�p mau tr� v� Ba l�ng huy�n ph�ng m�nh t�n s� �� nh�n qu�!");
		return
	end;
	SetFightState(1);
	SetPunish(1);
	SetRevPos(53,19);
	ForbidTownPortal(1);
	NewWorld(394,1414,3183);
	SetDeathScript("\\script\\event\\thienbaokho\\player_death.lua");
	if (GetTask(T_BK_KEY_1) > 0) then
		szTask_1 = ""..GetTask(T_BK_KEY_1).."";
	end;
	if (GetTask(T_BK_KEY_2) > 0) then
		szTask_2 = ""..GetTask(T_BK_KEY_2).."";
	end;
	if (GetTask(T_BK_KEY_3) > 0) then
		szTask_3 = ""..GetTask(T_BK_KEY_3).."";
	end;
	if (GetTask(T_BK_KEY_4) > 0) then
		szTask_4 = ""..GetTask(T_BK_KEY_4).."";
	end;
	if (GetTask(T_BK_KEY_5) > 0) then
		szTask_5 = ""..GetTask(T_BK_KEY_5).."";
	end;
	Msg2Player("Ch� d�n nhi�m v� c�a ng��i c�n l�i l� <color=yellow> "..szTask_1.." - "..szTask_2.." - "..szTask_3.." - "..szTask_4.." - "..szTask_5.." <color> h�y mau ho�n th�nh!.");
	AddNote("Ch� d�n nhi�m v� c�a ng��i c�n l�i l� <color=yellow> "..szTask_1.." - "..szTask_2.." - "..szTask_3.." - "..szTask_4.." - "..szTask_5.." <color> h�y mau ho�n th�nh!.");
end;

function MoveToBaLang()
	NewWorld(53,1582, 3237);	
	SetFightState(0);
	Msg2Player("Ng�i y�n! Ch�ng ta �i Ba l�ng huy�n ");
end;

function CheckKey(nIndex,szNameNpc,nPlayerIndex)
	if (GetTask(T_TIN_SU) < 1) then
		return
	end;
	local Check = 0;
	if (szNameNpc == "B�o Kh� Th� H� Gi� 01") then
		PlayerIndex = nPlayerIndex;
		Check = CheckCondition(1,nPlayerIndex);
		if (Check == 0) then
		return end;
		SetTask(740+Check,1);
		-- Msg2Player(""..Check.."")
	elseif (szNameNpc == "B�o Kh� Th� H� Gi� 02") then
		PlayerIndex = nPlayerIndex;
		Check = CheckCondition(2,nPlayerIndex);
		if (Check == 0) then
		return end;
		SetTask(740+Check,1);
		-- Msg2Player(""..Check.."")
	elseif (szNameNpc == "B�o Kh� Th� H� Gi� 03") then
		PlayerIndex = nPlayerIndex;
		Check = CheckCondition(3,nPlayerIndex);
		if (Check == 0) then
		return end;
		SetTask(740+Check,1);
		-- Msg2Player(""..Check.."")
	elseif (szNameNpc == "B�o Kh� Th� H� Gi� 04") then
		PlayerIndex = nPlayerIndex;
		Check = CheckCondition(4,nPlayerIndex);
		if (Check == 0) then
		return end;
		SetTask(740+Check,1);
		-- Msg2Player(""..Check.."")
	elseif (szNameNpc == "B�o Kh� Th� H� Gi� 05") then
		PlayerIndex = nPlayerIndex;
		Check = CheckCondition(5,nPlayerIndex);
		if (Check == 0) then
		return end;
		SetTask(740+Check,1);
		-- Msg2Player(""..Check.."")
	elseif (szNameNpc == "B�o Kh� Th� H� Gi� 06") then
		PlayerIndex = nPlayerIndex;
		Check = CheckCondition(6,nPlayerIndex);
		if (Check == 0) then
		return end;
		SetTask(740+Check,1);
		-- Msg2Player(""..Check.."")	
	elseif (szNameNpc == "B�o Kh� Th� H� Gi� 07") then
		PlayerIndex = nPlayerIndex;
		Check = CheckCondition(7,nPlayerIndex);
		if (Check == 0) then
		return end;
		SetTask(740+Check,1);
		-- Msg2Player(""..Check.."")			
	elseif (szNameNpc == "B�o Kh� Th� H� Gi� 08") then
		PlayerIndex = nPlayerIndex;
		Check = CheckCondition(8,nPlayerIndex);
		if (Check == 0) then
		return end;
		SetTask(740+Check,1);
		-- Msg2Player(""..Check.."")		
	elseif (szNameNpc == "B�o Kh� Th� H� Gi� 09") then
		PlayerIndex = nPlayerIndex;
		Check = CheckCondition(9,nPlayerIndex);
		if (Check == 0) then
		return end;
		SetTask(740+Check,1);
		-- Msg2Player(""..Check.."")				
	end;

end;

function CheckCondition(nID,nPlayerIndex)
local nSTT = 0;
local nID = nID;
PlayerIndex = nPlayerIndex
	for i = 1,5 do
		-- Msg2Player(" "..i.." "..(735+i).." "..GetTask(735+i).." "..nID.."");
			nSTT = i;
		if (GetTask(735+i) == nID) then
			-- Msg2Player(""..(735+i).."")
			if (nSTT ~= 1) then
				nSTT = nSTT - 1;	
				for k=1,nSTT do
					if (GetTask(735+k) > 0) then
						Talk(1,"","Nh� ng��i �� �i sai l� tr�nh, vui l�ng ki�m tra l�i.");
						return 0;
					end;
				end;				
			end;
			-- Msg2Player("DEBUG nSTT: "..nSTT.." ");
			if (735+i ~= 736) then
				return nSTT + 1;
			end;
			return nSTT;
		end;
	end;
	return 1;
end;

function Baokho(nID,nPlayerIndex)
	local nSTT = 0;
	local nID = nID;
	PlayerIndex = nPlayerIndex
	for i = 1,5 do
		if (GetTask(735+i) == nID) then
			if (GetTask(740+i) == 1) then
				Msg2Player("C��p b�o kh� s� <color=yellow> "..GetTask(735+i).." <color> th�nh c�ng!");
				SetTask(735+i,0);	
				SetTask(740+i,2);
				return
			else
				Talk(1,"","Ng��i ch�a h� g�c ���c ng��i gi� b�o kh� m� mu�n c��p b�o kh� �?");
				return
			end;	
		end;
	end;
end;

function FinishQuest()
	if (GetTask(T_BK_KEY_DONE_1) >= 1 and GetTask(T_BK_KEY_DONE_2) >= 1 and GetTask(T_BK_KEY_DONE_3) >= 1  and GetTask(T_BK_KEY_DONE_4) >= 1  and GetTask(T_BK_KEY_DONE_5) >= 1) then
		Talk(1,"","Ch�c m�ng ��i hi�p <color=yellow>"..GetName().."<color> �� ho�n th�nh nhi�m v� Thi�n b�o kh�, ph�n th��ng ��i hi�p nh�n ���c <color=green>20.000.000 �i�m kinh nghi�m v� m�t v�t ph�m qu� hi�m <color>");	
		Msg2SubWorld("Ch�c m�ng ��i hi�p <color=yellow>"..GetName().."<color> �� ho�n th�nh nhi�m v� Thi�n b�o kh�, ph�n th��ng ��i hi�p nh�n ���c <color=green>20.000.000 �i�m kinh nghi�m<color> v� m�t v�t ph�m qu� hi�m <color>");	
		SetTask(T_BK_KEY_1,0)
		SetTask(T_BK_KEY_2,0)
		SetTask(T_BK_KEY_3,0)
		SetTask(T_BK_KEY_4,0)
		SetTask(T_BK_KEY_5,0)
		SetTask(T_BK_KEY_DONE_1,0)
		SetTask(T_BK_KEY_DONE_2,0)
		SetTask(T_BK_KEY_DONE_3,0)
		SetTask(T_BK_KEY_DONE_4,0)
		SetTask(T_BK_KEY_DONE_5,0)
		SetTask(T_TIN_SU,2);
		AddOwnExp(EXP)
		AddEventThienBaoKho();
	else
		Talk(1,"","Ng��i ch�a ho�n th�nh nhi�m v� ��n ��y g�p ta c� chuy�n g�?")
	end;

end;


function no()
end;