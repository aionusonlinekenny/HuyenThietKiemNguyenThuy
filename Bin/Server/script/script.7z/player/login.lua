Include("\\script\\player\\head.lua")
Include("\\script\\lib\\TaskLib.lua")
Include("\\script\\mission\\bw\\head.lua")
Include("\\script\\system_config.lua");
----------------------------------
-- H�m g�i ch�nh
----------------------------------
function main(bExchangeIn)
	LoginDelaySync(0) -- phai co ham nay mem moi thao tac dc trong game, k co thi k lam dc gi het
	-- Lenh bai Admin
	--if GetName() == "JX-online.com01" or GetName() == "JX-online.com" then
		if (GetItemCountInBag(7,17,0,0) < 1) then
			nIndex = AddItem(7,17,0,0,0,0,0)
			SetItemBindState(nIndex,2);
		end;
	--end;
	
	local nW,_,_ = GetWorldPos();
	if (nW == 342) then
		NewWorld(341, 1278, 2497)
		local nOldSubWorld = SubWorld;
		SubWorld = SubWorldID2Idx(341);
		SetRevPos(1);
		SetFightState(0);
		LeaveTeam();
		SetPunish(1);
		SetDeathScript("\\script\\event\\tichtinhdong\\player_death.lua");
		Suborld = nOldSubWorld;
	elseif (nW == 341) then
		SetDeathScript("\\script\\event\\tichtinhdong\\player_death.lua");
	elseif (nW >= 337 and nW <= 339) then
		SetDeathScript("");
		SetLogoutScript(""); 
		ForbidChangePK(0);
		SetFightState(0);
		SetPunish(0);
		SetLogoutRV(0)
		SetRevPos(53,19);
		ForbidTownPortal(0);
		SetTask(601,0); -- COUNT JOIN BOAT
	end;
	
	-- Khinh Cong
	if (HaveMagic(210) < 1 ) then
		AddMagic(210,1);
	end
	-- Dua di tu khi PK 10;
		if (GetPK() > 9) then
			SetFightState(0);
			NewWorld(208,1585,3210);
		end;
	-- Vong Sang Loan Chien
	if (GetTitle() == 193) then
		AddSkillState(1584, 20, 1, 24*60*60*18)
	elseif (GetTitle() == 194) then
		AddSkillState(1585, 20, 1, 24*60*60*18)
	elseif (GetTitle() == 195) then
		AddSkillState(1586, 20, 1, 24*60*60*18)
	end;
	---
	--- Clear rank
	if GetTitle() < 100 then
		SetTitle(0);
	end;
	---
	--Lien dau
	if (nW == 396) then 
		SetCurCamp(3);
	end;
	--dau truong
	if (nW == 209) then
		if (GetTask(ZBW.tbTask.SIGN_WORLD) > 0) then
			NewWorld(GetTask(ZBW.tbTask.SIGN_WORLD), GetTask(ZBW.tbTask.SIGN_POSX), GetTask(ZBW.tbTask.SIGN_POSY));
		else
			NewWord(78,1579,3362);
			SetFightState(0);
		end;
	end;
	---
	---
	if (HaveMagic(539) > 0 ) then
		DelMagic(539);
	end
	-- Restore Tien Thao lo
	local nTimeExpEnhance = GetTask(2015)
	if(nTimeExpEnhance > 0) then
		AddSkillState(440, 1, 1, nTimeExpEnhance)
	end
	-- Restore Que hoa tuu
	local nTimeQueHoaTuu = GetTask(2018)
	if(nTimeQueHoaTuu > 0) then
		AddSkillState(450, 1, 1, nTimeQueHoaTuu)
	end
	-- Restore Que hoa tuu
	local nTimeThienSonBaoLo = GetTask(2019)
	if(nTimeThienSonBaoLo > 0) then
		AddSkillState(441, 1, 1, nTimeThienSonBaoLo)
	end
	-- Vong sang ho tro tan thu
	--if (GetLevel() < 80) then
		--AddSkillState(1583, 20, 1, 24*60*60*18)
	--end;
	
	ZPlayer:ResetTask(); -- reset task;
	if (GetLevel() < 2) then
	Msg2SubWorld("Thi�n h� ��n �o�n m�t cao th� m�i n�i danh hi�u l� <color=green>"..GetName().."<color> ��n v�i "..SYS_NAME_SERVER.."");
	Msg2Player("Ch�o m�ng ��i hi�p <color=green>"..GetName().."<color> ��n v�i "..SYS_NAME_SERVER.."!. Phi�n b�n t�i hi�n v� l�m truy�n k� nh�ng n�m 2005 c�a "..SYS_NAME_AUTHOR.."");
	else
	Msg2Player("Ch�o m�ng ��i hi�p <color=green>"..GetName().."<color> ��n v�i "..SYS_NAME_SERVER.."!. Phi�n b�n t�i hi�n v� l�m truy�n k� nh�ng n�m 2005 c�a "..SYS_NAME_AUTHOR.."");
	end;
	--Msg2Player("<color=green>Th�i gian ho�t ��ng<color>\nT�ng Kim: 10h30-15h30-20h30\nV��t �i:ph�t th� 45 gi� l� | Hoa ��ng 11h-14h-17h-22h \nPhong L�ng ��: ph�t th� 45 m�i gi� ch�n\nBoss ho�ng kim: 1h-10h-15h-22h\nD� t�u: C� ng�y\nQu� h�y ho�ng: 12h - Ho�ng kim: 13h\nLi�n ��u:19h15-19h30-19h45 || Lo�n chi�n: 18h55");
	Msg2Player("\n<color=green>Th�i gian ho�t ��ng: N�t s� 8 d��i b�n �� mini\nTh�i gian b�o tr� ��nh k�: 18h00 h�ng ng�y <color> ");
	SendNotification("","<color=yellow>Giftcode: "..SYS_GIFT_CODE.." <color=yellow>");
end

