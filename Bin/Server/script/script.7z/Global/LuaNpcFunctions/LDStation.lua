--Author: Kinnox;
--Date: 14/09/2021;
--Name: Xa Phu Lien Dau;
LDStation = {};
function main()
-- dofile("script/global/luanpcfunctions/ldstation.lua");
	local szHello = "<color=orange>Xa phu li�n ��u<color>: ��i hi�p mu�n �i ��u ta ��a �i!";
	local tbSay = {
		"Ba L�ng Huy�n/MoveToBaLangHuyen",
		"Ta ch� gh� ngang qua ��y/no",
	};
	Say(szHello,getn(tbSay),tbSay);
end;

function LDStation:LDNpcTalk()
	
end;

function MoveToBaLangHuyen()
	local nPrice = 500;
	NewWorld(53,1582, 3237);	
	if (GetFightState() > 0) then
		SetFightState(0);
	end;
	SetCreateTeam(1);
	SetRevPos(53,19);
	Pay(nPrice);
	Msg2Player("Ng�i y�n! Ch�ng ta �i Ba L�ng Huy�n.");
end;

function no()
end;