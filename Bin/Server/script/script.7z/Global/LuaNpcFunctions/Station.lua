-- Author:	Kinnox;
-- Date:	15-04-2021
-- Functions: Xa phu;
-- Include("\\script\\missions\\liendau\\single\\medium\\head.lua")
Include("\\script\\system_config.lua")
Station = {};	
TAB_CITY = {
--	stt		ID		Name
	{1,		11,		"Th�nh �� Ph�"},		--Thanh Do
	{2,		176,	"L�m An Ph�"},			--Lam An
	{3,		162,	"��i L� Ph�"},			--Dai Ly
	{4,		80,		"D��ng Ch�u Ph�"},		--Duong Chau
	{5,		37,		"Bi�n Kinh Ph�"},		--Bien Kinh
	{6,		1,		"Ph��ng T��ng Ph�"},	--Phuong Tuong
	{7,		78,		"T��ng D��ng Ph�"},		--Tuong Duong
	{8,		53,		"Ba L�ng Huy�n "},		--Ba lang Huyen;
	{9,		100,	"Chu Ti�n Tr�n"},		--Chu Tien Tran;
	{10,	101,	"��o H��ng Th�n"},		--Dao Huong Thon;
	{11,	99,		"V�nh L�c Tr�n"}, 		--Vinh Lac Tran;
	{12,	121,	"Long M�n Tr�n"}, 		--Long Mon Tran;
	{13,	153,	"Th�ch Th�ch C� Tr�n"}, --Thch Co Tran;
	{14,	174,	"Long Tuy�n Th�n"}, 	--Long Tuyen Thon;
	{15,	20,		"Giang T�n Th�n"}, 		--Giang Tan Thon;
	{16,	54,		"Nam Nh�c Tr�n"}, 		--Nam Nhac Tran;
	};
	
TAB_PRICE = {
	{200,300,300,400,300,100,500},
	{500,500,500,500,500,300,200,200},
	{500,300,500,400,500,500,200,100},
	{400,400,500,300,200,200,100},
	{300,300,500,200,300,500,100},
	{200,500,300,300,400,500,200,100},
	{300,300,400,500,200,200,300,200,100},
	{200,200,100},
	{100},
	{100,100},
	{100},
	{100},
	{100},
	{200},
	{100,200,200},
	{100},
};

	
function main(nNpcIdx)
-- dofile("script/global/luanpcfunctions/Station.lua");
if (ActionOpen() <= 0) then
	Talk(1,"","V�ng ��t n�y hi�n t�i ch�a khai th�ng, c�c h� vui l�ng ��i m�y ch� <color=orange>V� L�m Huy�n Thi�t Ki�m<color> <color=red>Open Beta<color>");
	return
end;
Station:Station(10356);
end;

function Station:Station(nMsgId)
	local tbSay = {
		"Nh�ng n�i �� �i qua /RememberPlace",
		"Nh�ng th�nh th� �� �i qua /ChooseCityMaps",
		"Tr� l�i �i�m c� /TownPortalFun",
		"��a ta ��n Hoa s�n c�nh k� tr��ng /MoveToHoaSon",
		"��a ta ��n ��o T�y T�y /GotoClearSkillMap",
		"��a ta ��n b�n �� luy�n c�ng /SelectTrainning",
		--"��a ta ��n b�n �� T�ch t�nh ��ng/MoveTichTinhDong",
		"Ta ch� gh� ngang qua./OnCancel",
	}
		Say(nMsgId,getn(tbSay),tbSay);
end;

function ChooseCityMaps()
	local w,x,y = GetWorldPos();
	local WAYPOINT={};
	local nIndex = 0;
	if (w == 11) then
		tinsert (WAYPOINT,TAB_CITY[6][3].."["..TAB_PRICE[1][1].." l��ng]".."/MoveToPhuongTuong");	
		tinsert (WAYPOINT,TAB_CITY[3][3].."["..TAB_PRICE[1][2].." l��ng]".."/MoveToDaiLy");	
		tinsert (WAYPOINT,TAB_CITY[5][3].."["..TAB_PRICE[1][3].." l��ng]".."/MoveToBienKinh");	
		tinsert (WAYPOINT,TAB_CITY[7][3].."["..TAB_PRICE[1][4].." l��ng]".."/MoveToTuongDuong");	
		tinsert (WAYPOINT,TAB_CITY[4][3].."["..TAB_PRICE[1][5].." l��ng]".."/MoveToDuongChau");	
		tinsert (WAYPOINT,TAB_CITY[2][3].."["..TAB_PRICE[1][6].." l��ng]".."/MoveToLamAn");	
		tinsert (WAYPOINT,TAB_CITY[15][3].."["..TAB_PRICE[1][7].." l��ng]".."/MoveToGiangTanThon");		
		tinsert (WAYPOINT,"Ta ch� gh� ngang qua./OnCancel");	
		Say(10356,getn(WAYPOINT),WAYPOINT);
	elseif (w == 176) then
		tinsert (WAYPOINT,TAB_CITY[6][3].."["..TAB_PRICE[2][1].." l��ng]".."/MoveToPhuongTuong");	
		tinsert (WAYPOINT,TAB_CITY[1][3].."["..TAB_PRICE[2][2].." l��ng]".."/MoveToThanhDo");	
		tinsert (WAYPOINT,TAB_CITY[3][3].."["..TAB_PRICE[2][3].." l��ng]".."/MoveToDaiLy");	
		tinsert (WAYPOINT,TAB_CITY[5][3].."["..TAB_PRICE[2][4].." l��ng]".."/MoveToBienKinh");	
		tinsert (WAYPOINT,TAB_CITY[7][3].."["..TAB_PRICE[2][5].." l��ng]".."/MoveToTuongDuong");	
		tinsert (WAYPOINT,TAB_CITY[4][3].."["..TAB_PRICE[2][6].." l��ng]".."/MoveToDuongChau");	
		tinsert (WAYPOINT,TAB_CITY[14][3].."["..TAB_PRICE[2][7].." l��ng]".."/MoveToLongTuyenThon");		
		tinsert (WAYPOINT,"Ta ch� gh� ngang qua./OnCancel");	
		Say(10356,getn(WAYPOINT),WAYPOINT);
	elseif (w == 162) then
		tinsert (WAYPOINT,TAB_CITY[6][3].."["..TAB_PRICE[3][1].." l��ng]".."/MoveToPhuongTuong");	
		tinsert (WAYPOINT,TAB_CITY[1][3].."["..TAB_PRICE[3][2].." l��ng]".."/MoveToThanhDo");	
		tinsert (WAYPOINT,TAB_CITY[5][3].."["..TAB_PRICE[3][3].." l��ng]".."/MoveToBienKinh");	
		tinsert (WAYPOINT,TAB_CITY[7][3].."["..TAB_PRICE[3][4].." l��ng]".."/MoveToTuongDuong");	
		tinsert (WAYPOINT,TAB_CITY[4][3].."["..TAB_PRICE[3][5].." l��ng]".."/MoveToDuongChau");	
		tinsert (WAYPOINT,TAB_CITY[2][3].."["..TAB_PRICE[3][6].." l��ng]".."/MoveToLamAn");	
		tinsert (WAYPOINT,TAB_CITY[15][3].."["..TAB_PRICE[3][7].." l��ng]".."/MoveToGiangTanThon");		
		tinsert (WAYPOINT,TAB_CITY[13][3].."["..TAB_PRICE[3][8].." l��ng]".."/MoveToThachCoTran");		
		tinsert (WAYPOINT,"Ta ch� gh� ngang qua./OnCancel");	
		Say(10356,getn(WAYPOINT),WAYPOINT);
	elseif (w == 80) then
		tinsert (WAYPOINT,TAB_CITY[6][3].."["..TAB_PRICE[4][1].." l��ng]".."/MoveToPhuongTuong");	
		tinsert (WAYPOINT,TAB_CITY[1][3].."["..TAB_PRICE[4][2].." l��ng]".."/MoveToThanhDo");	
		tinsert (WAYPOINT,TAB_CITY[3][3].."["..TAB_PRICE[4][3].." l��ng]".."/MoveToDaiLy");	
		tinsert (WAYPOINT,TAB_CITY[5][3].."["..TAB_PRICE[4][4].." l��ng]".."/MoveToBienKinh");	
		tinsert (WAYPOINT,TAB_CITY[7][3].."["..TAB_PRICE[4][5].." l��ng]".."/MoveToTuongDuong");	
		tinsert (WAYPOINT,TAB_CITY[2][3].."["..TAB_PRICE[4][6].." l��ng]".."/MoveToLamAn");	
		tinsert (WAYPOINT,TAB_CITY[10][3].."["..TAB_PRICE[4][7].." l��ng]".."/MoveToDaoHuongThon");			
		tinsert (WAYPOINT,"Ta ch� gh� ngang qua./OnCancel");	
		Say(10356,getn(WAYPOINT),WAYPOINT);
	elseif (w == 37) then
		tinsert (WAYPOINT,TAB_CITY[6][3].."["..TAB_PRICE[5][1].." l��ng]".."/MoveToPhuongTuong");	
		tinsert (WAYPOINT,TAB_CITY[1][3].."["..TAB_PRICE[5][2].." l��ng]".."/MoveToThanhDo");	
		tinsert (WAYPOINT,TAB_CITY[3][3].."["..TAB_PRICE[5][3].." l��ng]".."/MoveToDaiLy");	
		tinsert (WAYPOINT,TAB_CITY[7][3].."["..TAB_PRICE[5][4].." l��ng]".."/MoveToTuongDuong");	
		tinsert (WAYPOINT,TAB_CITY[4][3].."["..TAB_PRICE[5][5].." l��ng]".."/MoveToDuongChau");	
		tinsert (WAYPOINT,TAB_CITY[2][3].."["..TAB_PRICE[5][6].." l��ng]".."/MoveToLamAn");	
		tinsert (WAYPOINT,TAB_CITY[9][3].."["..TAB_PRICE[5][7].." l��ng]".."/MoveToChuTienTran");			
		tinsert (WAYPOINT,"Ta ch� gh� ngang qua./OnCancel");	
		Say(10356,getn(WAYPOINT),WAYPOINT);	
	elseif (w == 1) then
		tinsert (WAYPOINT,TAB_CITY[1][3].."["..TAB_PRICE[6][1].." l��ng]".."/MoveToThanhDo");	
		tinsert (WAYPOINT,TAB_CITY[3][3].."["..TAB_PRICE[6][2].." l��ng]".."/MoveToDaiLy");	
		tinsert (WAYPOINT,TAB_CITY[5][3].."["..TAB_PRICE[6][3].." l��ng]".."/MoveToBienKinh");	
		tinsert (WAYPOINT,TAB_CITY[7][3].."["..TAB_PRICE[6][4].." l��ng]".."/MoveToTuongDuong");	
		tinsert (WAYPOINT,TAB_CITY[4][3].."["..TAB_PRICE[6][5].." l��ng]".."/MoveToDuongChau");	
		tinsert (WAYPOINT,TAB_CITY[2][3].."["..TAB_PRICE[6][6].." l��ng]".."/MoveToLamAn");	
		tinsert (WAYPOINT,TAB_CITY[12][3].."["..TAB_PRICE[6][7].." l��ng]".."/MoveToLongMonTran");			
		tinsert (WAYPOINT,TAB_CITY[11][3].."["..TAB_PRICE[6][8].." l��ng]".."/MoveToVinhLacTran");		
		tinsert (WAYPOINT,"Ta ch� gh� ngang qua./OnCancel");	
	elseif (w == 78) then
		tinsert (WAYPOINT,TAB_CITY[6][3].."["..TAB_PRICE[7][1].." l��ng]".."/MoveToPhuongTuong");	
		tinsert (WAYPOINT,TAB_CITY[1][3].."["..TAB_PRICE[7][2].." l��ng]".."/MoveToThanhDo");	
		tinsert (WAYPOINT,TAB_CITY[3][3].."["..TAB_PRICE[7][3].." l��ng]".."/MoveToDaiLy");	
		tinsert (WAYPOINT,TAB_CITY[5][3].."["..TAB_PRICE[7][4].." l��ng]".."/MoveToBienKinh");
		tinsert (WAYPOINT,TAB_CITY[4][3].."["..TAB_PRICE[7][6].." l��ng]".."/MoveToDuongChau");	
		tinsert (WAYPOINT,TAB_CITY[2][3].."["..TAB_PRICE[7][7].." l��ng]".."/MoveToLamAn");	
		tinsert (WAYPOINT,TAB_CITY[8][3].."["..TAB_PRICE[7][8].." l��ng]".."/MoveToBaLangHuyen");			
		tinsert (WAYPOINT,TAB_CITY[10][3].."["..TAB_PRICE[7][9].." l��ng]".."/MoveToDaoHuongThon");		
		tinsert (WAYPOINT,"Ta ch� gh� ngang qua./OnCancel");	
	elseif (w == 53) then
		tinsert (WAYPOINT,TAB_CITY[7][3].."["..TAB_PRICE[8][1].." l��ng]".."/MoveToTuongDuong");	
		tinsert (WAYPOINT,TAB_CITY[15][3].."["..TAB_PRICE[8][2].." l��ng]".."/MoveToGiangTanThon");	
		tinsert (WAYPOINT,TAB_CITY[16][3].."["..TAB_PRICE[8][3].." l��ng]".."/MoveToNamNhacTran");				
		tinsert (WAYPOINT,"Ta ch� gh� ngang qua./OnCancel");	
	elseif (w == 100) then
		tinsert (WAYPOINT,TAB_CITY[5][3].."["..TAB_PRICE[9][1].." l��ng]".."/MoveToBienKinh");					
		tinsert (WAYPOINT,"Ta ch� gh� ngang qua./OnCancel");		
	elseif (w == 101) then
		tinsert (WAYPOINT,TAB_CITY[7][3].."["..TAB_PRICE[10][1].." l��ng]".."/MoveToTuongDuong");	
		tinsert (WAYPOINT,TAB_CITY[4][3].."["..TAB_PRICE[10][2].." l��ng]".."/MoveToDuongChau");	
		tinsert (WAYPOINT,"Ta ch� gh� ngang qua./OnCancel");	
	elseif (w == 99) then
		tinsert (WAYPOINT,TAB_CITY[6][3].."["..TAB_PRICE[11][1].." l��ng]".."/MoveToPhuongTuong");
		tinsert (WAYPOINT,"Ta ch� gh� ngang qua./OnCancel");	
	elseif (w == 121) then
		tinsert (WAYPOINT,TAB_CITY[6][3].."["..TAB_PRICE[12][1].." l��ng]".."/MoveToPhuongTuong");
		tinsert (WAYPOINT,"Ta ch� gh� ngang qua./OnCancel");	
	elseif (w == 153) then
		tinsert (WAYPOINT,TAB_CITY[3][3].."["..TAB_PRICE[13][1].." l��ng]".."/MoveToDaiLy");	
		tinsert (WAYPOINT,"Ta ch� gh� ngang qua./OnCancel");	
	elseif (w == 174) then
		tinsert (WAYPOINT,TAB_CITY[2][3].."["..TAB_PRICE[14][1].." l��ng]".."/MoveToLamAn");	
		tinsert (WAYPOINT,"Ta ch� gh� ngang qua./OnCancel");	
	elseif (w == 20) then
		tinsert (WAYPOINT,TAB_CITY[1][3].."["..TAB_PRICE[15][1].." l��ng]".."/MoveToThanhDo");	
		tinsert (WAYPOINT,TAB_CITY[3][3].."["..TAB_PRICE[15][2].." l��ng]".."/MoveToDaiLy");	
		tinsert (WAYPOINT,TAB_CITY[8][3].."["..TAB_PRICE[15][3].." l��ng]".."/MoveToBaLangHuyen");
		tinsert (WAYPOINT,"Ta ch� gh� ngang qua./OnCancel");	
	elseif (w == 54) then
		tinsert (WAYPOINT,TAB_CITY[8][3].."["..TAB_PRICE[15][3].." l��ng]".."/MoveToBaLangHuyen");
		tinsert (WAYPOINT,"Ta ch� gh� ngang qua./OnCancel");	
	else
		tinsert (WAYPOINT,TAB_CITY[8][3].."["..TAB_PRICE[15][3].." l��ng]".."/MoveToBaLangHuyen");
		tinsert (WAYPOINT,"Ta ch� gh� ngang qua./OnCancel");	
	end
	Say(10356,getn(WAYPOINT),WAYPOINT);	
end;
--/////////////////////////MOVE TO CITY
function MoveToThanhDo()
	local nPrice = 0;
	local nSubWorldId = SubWorldID2Idx(1);
	local w,x,y = GetWorldPos();
	if nSubWorldId < 0 then	--chua mo map, ngung ham`
	return end
	if (w == 176) then
		nPrice = TAB_PRICE[2][2];
	elseif (w == 162) then
		nPrice = TAB_PRICE[3][2];
	elseif (w == 80) then
		nPrice = TAB_PRICE[4][2];
	elseif (w == 37) then
		nPrice = TAB_PRICE[5][2];
	elseif (w == 1) then
		nPrice = TAB_PRICE[6][1] ;
	elseif (w == 78) then
		nPrice = TAB_PRICE[7][2] ;
	elseif (w == 20) then
		nPrice = TAB_PRICE[15][1];
	end
	TAB_POS = {
		{3193, 5192},
		{3266, 5004},
		{3011, 5101},
		{3031, 4969},
	};
	if (GetCash() < nPrice) then
	Talk(1,"",10336);
	return
	end
	nPos = random(1,getn(TAB_POS));
	NewWorld(11,TAB_POS[nPos][1],TAB_POS[nPos][2]);
	Pay(nPrice);
	Msg2Player("Ng�i y�n! Ch�ng ta �i "..TAB_CITY[1][3].." ");
end

function MoveToPhuongTuong()
	local nPrice = 0;
	local nSubWorldId = SubWorldID2Idx(1);
	local w,x,y = GetWorldPos();
	if nSubWorldId < 0 then	--chua mo map, ngung ham`
	return end
	if (w == 11 ) then
		nPrice = TAB_PRICE[1][1];
	elseif (w == 176) then
		nPrice = TAB_PRICE[2][1];
	elseif (w == 162) then
		nPrice = TAB_PRICE[3][1];
	elseif (w == 80) then
		nPrice = TAB_PRICE[4][1];
	elseif (w == 37) then
		nPrice = TAB_PRICE[5][1];
	elseif (w == 78) then
		nPrice = TAB_PRICE[7][1] ;
	elseif (w == 99) then
		nPrice = TAB_PRICE[11][1];
	elseif (w == 121) then
		nPrice = TAB_PRICE[12][1];
	end
	TAB_POS = {
		{1557, 3112},
		{1537, 3237},
		{1649, 3287},
		{1656, 3167},
	};
	if (GetCash() < nPrice) then
	Talk(1,"",10336);
	return
	end
	nPos = random(1,getn(TAB_POS));
	NewWorld(1,TAB_POS[nPos][1],TAB_POS[nPos][2]);
	Pay(nPrice);
	Msg2Player("Ng�i y�n! Ch�ng ta �i "..TAB_CITY[6][3].." ");
end

function MoveToLamAn()
	local nPrice = 0;
	local nSubWorldId = SubWorldID2Idx(176);
	local w,x,y = GetWorldPos();
	if nSubWorldId < 0 then	--chua mo map, ngung ham`
	return end
	if (w == 11 ) then
		nPrice = TAB_PRICE[1][6];
	elseif (w == 162) then
		nPrice = TAB_PRICE[1][6];
	elseif (w == 80) then
		nPrice = TAB_PRICE[4][6];
	elseif (w == 37) then
		nPrice = TAB_PRICE[5][6];
	elseif (w == 1) then
		nPrice = TAB_PRICE[6][6];
	elseif (w == 78) then
		nPrice = TAB_PRICE[7][7];
	elseif (w == 174) then
		nPrice = TAB_PRICE[14][1];
	end
	TAB_POS = {
		{1603, 2917},
		{1692, 3296},
		{1375, 3337},
		{1356, 3017},
	};
	if (GetCash() < nPrice) then
	Talk(1,"",10336);
	return
	end
	nPos = random(1,getn(TAB_POS));
	NewWorld(176,TAB_POS[nPos][1],TAB_POS[nPos][2]);
	Msg2Player("Ng�i y�n! Ch�ng ta �i "..TAB_CITY[2][3].." ");
end

function MoveToDaiLy()
	local nPrice = 0;
	local nSubWorldId = SubWorldID2Idx(162);
	local w,x,y = GetWorldPos();
	if nSubWorldId < 0 then	--chua mo map, ngung ham`
	return end
	if (w == 11 ) then
		nPrice = TAB_PRICE[1][2];
	elseif (w == 176) then
		nPrice = TAB_PRICE[2][3];
	elseif (w == 80) then
		nPrice = TAB_PRICE[4][3];
	elseif (w == 37) then
		nPrice = TAB_PRICE[5][3];
	elseif (w == 1) then
		nPrice = TAB_PRICE[6][2];
	elseif (w == 78) then
		nPrice = TAB_PRICE[7][3];
	elseif (w == 153) then
		nPrice = TAB_PRICE[13][1];
	elseif (w == 20) then
		nPrice = TAB_PRICE[15][2];
	end
	TAB_POS = {
		{1669, 3129},
		{1696, 3280},
		{1472, 3273},
	};
	if (GetCash() < nPrice) then
	Talk(1,"",10336);
	return
	end
	nPos = random(1,getn(TAB_POS));
	NewWorld(162,TAB_POS[nPos][1],TAB_POS[nPos][2]);	
	Pay(nPrice);
	Msg2Player("Ng�i y�n! Ch�ng ta �i "..TAB_CITY[3][3].." ");
end

function MoveToDuongChau()
	local nPrice = 0;
	local nSubWorldId = SubWorldID2Idx(80);
	local w,x,y = GetWorldPos();
	if nSubWorldId < 0 then	--chua mo map, ngung ham`
	return end
	if (w == 11 ) then
		nPrice = TAB_PRICE[1][5];
	elseif (w == 176) then
		nPrice = TAB_PRICE[2][6];
	elseif (w == 162) then
		nPrice = TAB_PRICE[3][5];
	elseif (w == 37) then
		nPrice = TAB_PRICE[5][5];
	elseif (w == 1) then
		nPrice = TAB_PRICE[6][5];
	elseif (w == 78) then
		nPrice = TAB_PRICE[7][6];
	elseif (w == 101) then
		nPrice = TAB_PRICE[10][2];
	end
	TAB_POS = {
		{1670, 2996},
		{1598, 3201},
		{1722, 3210},
		{1834, 3063},
	};
	if (GetCash() < nPrice) then
	Talk(1,"",10336);
	return
	end
	nPos = random(1,getn(TAB_POS));
	NewWorld(80,TAB_POS[nPos][1],TAB_POS[nPos][2]);	
	Pay(nPrice);
	Msg2Player("Ng�i y�n! Ch�ng ta �i "..TAB_CITY[4][3].." ");
end

function MoveToBienKinh()
	local nPrice = 0;
	local nSubWorldId = SubWorldID2Idx(37);
	local w,x,y = GetWorldPos();
	if nSubWorldId < 0 then	--chua mo map, ngung ham`
	return end
	if (w == 11 ) then
		nPrice = TAB_PRICE[1][3];
	elseif (w == 176) then
		nPrice = TAB_PRICE[2][4];
	elseif (w == 162) then
		nPrice = TAB_PRICE[3][3];
	elseif (w == 80) then
		nPrice = TAB_PRICE[4][4];
	elseif (w == 37) then
		nPrice = TAB_PRICE[5][5];
	elseif (w == 1) then
		nPrice = TAB_PRICE[6][3];
	elseif (w == 78) then
		nPrice = TAB_PRICE[7][4];
	elseif (w == 100) then
		nPrice = TAB_PRICE[9][1];
	end
	TAB_POS = {
		{1598, 3000},
		{1866, 2930},
		{1701, 3224},
		{1636, 3191},
	};
	if (GetCash() < nPrice) then
	Talk(1,"",10336);
	return
	end
	nPos = random(1,getn(TAB_POS));
	NewWorld(37,TAB_POS[nPos][1],TAB_POS[nPos][2]);	
	Pay(nPrice);
	Msg2Player("Ng�i y�n! Ch�ng ta �i "..TAB_CITY[5][3].." ");
end

function MoveToTuongDuong()
	local nPrice = 0;
	local nSubWorldId = SubWorldID2Idx(78);
	local w,x,y = GetWorldPos();
	if nSubWorldId < 0 then	--chua mo map, ngung ham`
	return end
	if (w == 11 ) then
		nPrice = TAB_PRICE[1][4];
	elseif (w == 176) then
		nPrice = TAB_PRICE[2][5];
	elseif (w == 162) then
		nPrice = TAB_PRICE[3][4];
	elseif (w == 80) then
		nPrice = TAB_PRICE[4][5];
	elseif (w == 37) then
		nPrice = TAB_PRICE[5][4];
	elseif (w == 1) then
		nPrice = TAB_PRICE[6][4];
	elseif (w == 78) then
		nPrice = TAB_PRICE[7][5];
	elseif (w == 53) then
		nPrice = TAB_PRICE[8][1];
	elseif (w == 101) then
		nPrice = TAB_PRICE[10][1];
	end
	TAB_POS = {
		{1592, 3377},
		{1704, 3225},
		{1508, 3147},
		{1440, 3219},
	};
	if (GetCash() < nPrice) then
	Talk(1,"",10336);
	return
	end
	nPos = random(1,getn(TAB_POS));
	NewWorld(78,TAB_POS[nPos][1],TAB_POS[nPos][2]);	
	Pay(nPrice);
	Msg2Player("Ng�i y�n! Ch�ng ta �i "..TAB_CITY[7][3].." ");
end
--/////////////////////////MOVE TO COUNTRY
function MoveToBaLangHuyen()
	local nPrice = 0;
	local nSubWorldId = SubWorldID2Idx(53);
	local w,x,y = GetWorldPos();
	if nSubWorldId < 0 then	--chua mo map, ngung ham`
	return end
	if (w == 78 ) then
		nPrice = TAB_PRICE[7][8];
	elseif (w == 20) then
		nPrice = TAB_PRICE[15][6];
	elseif (w == 54) then
		nPrice = TAB_PRICE[8][3];
	end
	if (GetCash() < nPrice) then
	Talk(1,"",10336);
	return
	end
	NewWorld(53,1582, 3237);	
	Pay(nPrice);
	Msg2Player("Ng�i y�n! Ch�ng ta �i "..TAB_CITY[8][3].." ");
end

function MoveToChuTienTran()
	local nPrice = 0;
	local nSubWorldId = SubWorldID2Idx(100);
	local w,x,y = GetWorldPos();
	if nSubWorldId < 0 then	--chua mo map, ngung ham`
	return end
	if (w == 37 ) then
		nPrice = TAB_PRICE[5][7];
	end
	if (GetCash() < nPrice) then
	Talk(1,"",10336);
	return
	end
	NewWorld(100,1615, 3100);	
	Pay(nPrice);
	Msg2Player("Ng�i y�n! Ch�ng ta �i "..TAB_CITY[9][3].." ");
end

function MoveToDaoHuongThon()
	local nPrice = 0;
	local nSubWorldId = SubWorldID2Idx(101);
	local w,x,y = GetWorldPos();
	if nSubWorldId < 0 then	--chua mo map, ngung ham`
	return end
	if (w == 80 ) then
		nPrice = TAB_PRICE[10][3];
	elseif (w == 78 ) then
		nPrice = TAB_PRICE[7][9];
	end
	if (GetCash() < nPrice) then
	Talk(1,"",10336);
	return
	end
	NewWorld(101,1621, 3104);	
	Pay(nPrice);
	Msg2Player("Ng�i y�n! Ch�ng ta �i "..TAB_CITY[10][3].." ");
end

function MoveToVinhLacTran()
	local nPrice = 0;
	local nSubWorldId = SubWorldID2Idx(99);
	local w,x,y = GetWorldPos();
	if nSubWorldId < 0 then	--chua mo map, ngung ham`
	return end
	if (w == 1 ) then
		nPrice = TAB_PRICE[6][8];
	end
	if (GetCash() < nPrice) then
	Talk(1,"",10336);
	return
	end
	NewWorld(99,1606, 3165);	
	Pay(nPrice);
	Msg2Player("Ng�i y�n! Ch�ng ta �i "..TAB_CITY[11][3].." ");
end

function MoveToLongMonTran()
	local nPrice = 0;
	local nSubWorldId = SubWorldID2Idx(121);
	local w,x,y = GetWorldPos();
	if nSubWorldId < 0 then	--chua mo map, ngung ham`
	return end
	if (w == 1 ) then
		nPrice = TAB_PRICE[6][7];
	end
	if (GetCash() < nPrice) then
	Talk(1,"",10336);
	return
	end
	NewWorld(121,1924, 4435);	
	Pay(nPrice);
	Msg2Player("Ng�i y�n! Ch�ng ta �i "..TAB_CITY[12][3].." ");
end

function MoveToThachCoTran()
	local nPrice = 0;
	local nSubWorldId = SubWorldID2Idx(153);
	local w,x,y = GetWorldPos();
	if nSubWorldId < 0 then	--chua mo map, ngung ham`
	return end
	if (w == 162 ) then
		nPrice = TAB_PRICE[3][8];
	end
	if (GetCash() < nPrice) then
	Talk(1,"",10336);
	return
	end
	NewWorld(153,1632, 3182);
	Pay(nPrice);
	Msg2Player("Ng�i y�n! Ch�ng ta �i "..TAB_CITY[13][3].." ");
end

function MoveToLongTuyenThon()
	local nPrice = 0;
	local nSubWorldId = SubWorldID2Idx(174);
	local w,x,y = GetWorldPos();
	if nSubWorldId < 0 then	--chua mo map, ngung ham`
	return end
	if (w == 176 ) then
		nPrice = TAB_PRICE[2][7];
	end
	if (GetCash() < nPrice) then
	Talk(1,"",10336);
	return
	end
	NewWorld(174,1632, 3199);
	Pay(nPrice);
	Msg2Player("Ng�i y�n! Ch�ng ta �i "..TAB_CITY[14][3].." ");
end

function MoveToGiangTanThon()
	local nPrice = 0;
	local nSubWorldId = SubWorldID2Idx(20);
	local w,x,y = GetWorldPos();
	if nSubWorldId < 0 then	--chua mo map, ngung ham`
	return end
	if (w == 11 ) then
		nPrice = TAB_PRICE[1][7];
	elseif (w == 162 ) then
		nPrice = TAB_PRICE[3][7];
	elseif (w == 53 ) then
		nPrice = TAB_PRICE[8][2];
	end
	if (GetCash() < nPrice) then
	Talk(1,"",10336);
	return
	end
	NewWorld(20,3450, 6106);
	Pay(nPrice);
	Msg2Player("Ng�i y�n! Ch�ng ta �i "..TAB_CITY[15][3].." ");
end

function MoveToNamNhacTran()
	local nPrice = 0;
	local nSubWorldId = SubWorldID2Idx(54);
	local w,x,y = GetWorldPos();
	if nSubWorldId < 0 then	--chua mo map, ngung ham`
	return end
	if (w == 53 ) then
		nPrice = TAB_PRICE[8][3];
	end
	if (GetCash() < nPrice) then
	Talk(1,"",10336);
	return
	end
	NewWorld(54,1588, 3098);
	Pay(nPrice);
	Msg2Player("Ng�i y�n! Ch�ng ta �i "..TAB_CITY[16][3].." ");
end

----------------------------
--Ban do luyen cong
----------------------------
tbTrainArea = {
	--20
	[20] = {
	-- {"Hoa S�n.","MoveToHoaSon", 2, 2605, 3592},
	{"Ki�m C�c T�y B�c.","MoveToKiemCacTayBac", 3, 1159, 3715},
	{"V� L�ng s�n.","MoveToVuLangSon", 70, 1608, 3230},
	},
	--30
	[30] = {
	{"Kim Quang ��ng.","MoveToKimQuangDong", 4, 1596, 3282},
	{"Mi�u L�nh.","MoveToMieuLinh", 74, 2040, 3259},
	{"Ph�c Ng�u S�n ��ng.","MoveToPhucNguuSonDong", 90, 1649, 3567},
	},
	--40
	[40] = {	
	{"T�a V�n ��ng.","MoveToToaVanDong", 6, 1660, 3314},
	{"Ph�c Ng�u S�n T�y.","MoveToPhucNguuSonTay", 41, 2056, 2816},
	{"M� cung K� Qu�n ��ng.","MoveToMeCungKeQuanDong", 91, 1469, 2870},
	},
	--50
	[50] = {
	{"Thi�t th�p t�ng 1.","MoveToThietThap1", 38, 1603, 3204},
	{"Thi�t th�p t�ng 2.","MoveToThietThap2", 39, 1681, 3129},
	{"Thi�n T�m ��ng.","MoveToThienTamDong", 42, 1584, 3221},
	},
	--60
	[60] = {	
	{"M�t ��o Nha m�n T��ng D��ng.","MoveToMatDaoNhaMon", 79, 1594, 3211},
	{"M� cung c�m ��a.","MoveToCamDia", 158, 1583, 3192},
	{"Thi�n T�m th�p t�ng 3.","MoveToThienTamThap3", 166, 1667, 3244},
	},
	--70
	[70] = {
	{"��i T� ��ng.","MoveToDaiTuDong", 72, 1583, 3042},
	{"D��c V��ng ��ng t�ng 2-1.","MoveToDuocVuongDong21", 142, 1467, 3284},
	{"D��c V��ng ��ng t�ng 2-2.","MoveToDuocVuongDong22", 142, 1515, 3340},
	{"L�m Du Quan.","MoveToLamDuQuang", 319, 1612, 3612},
	},
	--80
	[80] = {
	{"Kho� Lang ��ng.","MoveToKhoaLangDong", 75, 1872, 3071},
	-- {"Ph� Dung ��ng.","MoveToPhuDungDong", 202, 1786, 2823},
	{"Sa m�c ��a bi�u.","MoveToSaMacDiaBieu", 224, 1619, 3213},
	{"Ch�n n�i Tr��ng B�ch.","MoveToChanNuiTruongBach", 320, 1137, 3151},
	},
	--90
	[90] = {
	{"Sa M�c s�n ��ng 1.","MoveToSaMac1", 225, 1579, 3188},
	{"Sa M�c s�n ��ng 2.","MoveToSaMac2", 226, 1692, 3247},
	{"Sa M�c s�n ��ng 3.","MoveToSaMac3", 227, 1583, 3241},
	{"Tr��ng B�ch s�n Nam.","MoveToTruongBachNam", 321, 966, 2296},
	{"Tr��ng B�ch s�n B�c.","MoveToTruongBachBac", 322, 2048,4120},
	{"Phong L�ng ��.","MoveToPhongLangDo", 336, 1112, 3189},
	{"M�c Cao Qu�t.","MoveToMacCaoQuat", 340, 1853, 3446},
	},
}

function SelectTrainning()
	local tbSay = {
			"Khu v�c c�p 20 - 30./TrainningLevel",
			"Khu v�c c�p 30 - 40./TrainningLevel",
			"Khu v�c c�p 40 - 50./TrainningLevel",
			"Khu v�c c�p 50 - 60./TrainningLevel",
			"Khu v�c c�p 60 - 70./TrainningLevel",
			"Khu v�c c�p 70 - 80./TrainningLevel",
			"Khu v�c c�p 80 - 90./TrainningLevel",
			"Khu v�c c�p 90 tr� l�n./TrainningLevel",
			"Ta ch� gh� ngang qua./OnCancel"	
		}
	if(GetSex() == 0) then
		Say(10372,getn(tbSay),tbSay)
	else
		Say(10373,getn(tbSay),tbSay)
	end
end

function TrainningLevel(nSel)
	if(type(nSel) ~= "number") then
		nSel = tonumber(nSel)
	end
	nSel = (nSel + 2) * 10
	if(not tbTrainArea[nSel]) then
		return
	end
	
	if(GetLevel() < nSel) then
		Talk(1,"","Th� l�i ta kh�ng th� ��a ng��i ��n ��y.V�ng ��t n�y r�t nguy hi�m, �c t�c ho�nh h�nh, b�n l�nh nh� ng��i ch�a �� �� �i ��n ��y.C�n ��t ��ng c�p <color=yellow>"..nSel.."<color> . ")
		return
	end
	
	local tbSay = {}
	for i = 1, getn(tbTrainArea[nSel]) do
		tinsert(tbSay, tbTrainArea[nSel][i][1].."/"..tbTrainArea[nSel][i][2].."")
	end
	tinsert(tbSay, "Ta ch� gh� ngang qua./OnCancel"	)
	if(GetSex() == 0) then
		Say(10372,getn(tbSay),tbSay)
	else
		Say(10373,getn(tbSay),tbSay)
	end
end

function MoveToHoaSon()
	if (Condition() < 1) then
		return end;
	if (NewWorld(2, 2605, 3592) == 0)then
		Msg2Player("���ng ph�a tr��c kh�ng th�ng");
		return
	end
	SetFightState(1);
	AddSkillState(963, 1, 0, 18*3)
	Msg2Player("Ng�i y�n! Ch�ng ta �i Hoa S�n C�nh K� Tr��ng.");
end

function MoveToKiemCacTayBac()
	if (Condition() < 1) then
		return end;
	if (NewWorld(3, 1159, 3715) == 0)then
		Msg2Player("���ng ph�a tr��c kh�ng th�ng");
		return
	end
	SetFightState(1);
	AddSkillState(963, 1, 0, 18*3)
	Msg2Player("Ng�i y�n! Ch�ng ta �i Ki�m C�c T�y B�c.");
end

function MoveToVuLangSon()
	if (Condition() < 1) then
		return end;
	if (NewWorld(70, 1608, 3230) == 0)then
		Msg2Player("���ng ph�a tr��c kh�ng th�ng");
		return
	end
	SetFightState(1);
	AddSkillState(963, 1, 0, 18*3)
	Msg2Player("Ng�i y�n! Ch�ng ta �i V� L�ng s�n.");
end

function MoveToKimQuangDong()
	if (Condition() < 1) then
		return end;
	if (NewWorld(4, 1596, 3282) == 0)then
		Msg2Player("���ng ph�a tr��c kh�ng th�ng");
		return
	end
	SetFightState(1);
	AddSkillState(963, 1, 0, 18*3)
	Msg2Player("Ng�i y�n! Ch�ng ta �i Kim Quang ��ng.");
end

function MoveToMieuLinh()
	if (Condition() < 1) then
		return end;
	if (NewWorld(74, 2040, 3259) == 0)then
		Msg2Player("���ng ph�a tr��c kh�ng th�ng");
		return
	end
	SetFightState(1);
	AddSkillState(963, 1, 0, 18*3)
	Msg2Player("Ng�i y�n! Ch�ng ta �i Mi�u L�nh.");
end

function MoveToPhucNguuSonDong()
	if (Condition() < 1) then
		return end;
	if (NewWorld(90, 1649, 3567) == 0)then
		Msg2Player("���ng ph�a tr��c kh�ng th�ng");
		return
	end
	SetFightState(1);
	AddSkillState(963, 1, 0, 18*3)
	Msg2Player("Ng�i y�n! Ch�ng ta �i Ph�c Ng�u S�n ��ng.");
end

function MoveToToaVanDong()
	if (Condition() < 1) then
		return end;
	if (NewWorld(6, 1660, 3314) == 0)then
		Msg2Player("���ng ph�a tr��c kh�ng th�ng");
		return
	end
	SetFightState(1);
	AddSkillState(963, 1, 0, 18*3)
	Msg2Player("Ng�i y�n! Ch�ng ta �i T�a V�n ��ng.");
end

function MoveToPhucNguuSonTay()
	if (Condition() < 1) then
		return end;
	if (NewWorld(41, 2056, 2816) == 0)then
		Msg2Player("���ng ph�a tr��c kh�ng th�ng");
		return
	end
	SetFightState(1);
	AddSkillState(963, 1, 0, 18*3)
	Msg2Player("Ng�i y�n! Ch�ng ta �i Ph�c Ng�u S�n T�y.");
end

function MoveToMeCungKeQuanDong()
	if (Condition() < 1) then
		return end;
	if (NewWorld(91, 1469, 2870) == 0)then
		Msg2Player("���ng ph�a tr��c kh�ng th�ng");
		return
	end
	SetFightState(1);
	AddSkillState(963, 1, 0, 18*3)
	Msg2Player("Ng�i y�n! Ch�ng ta �i M� cung K� Qu�n ��ng.");
end

function MoveToThietThap1()
	if (Condition() < 1) then
		return end;
	if (NewWorld(38, 1603, 3204) == 0)then
		Msg2Player("���ng ph�a tr��c kh�ng th�ng");
		return
	end
	SetFightState(1);
	AddSkillState(963, 1, 0, 18*3)
	Msg2Player("Ng�i y�n! Ch�ng ta �i M� cung Thi�t th�p t�ng 1.");
end

function MoveToThietThap2()
	if (Condition() < 1) then
		return end;
	if (NewWorld(39, 1681, 3129) == 0)then
		Msg2Player("���ng ph�a tr��c kh�ng th�ng");
		return
	end
	SetFightState(1);
	AddSkillState(963, 1, 0, 18*3)
	Msg2Player("Ng�i y�n! Ch�ng ta �i M� cung Thi�t th�p t�ng 2.");
end

function MoveToThienTamDong()
	if (Condition() < 1) then
		return end;
	if (NewWorld(42, 1584, 3221) == 0)then
		Msg2Player("���ng ph�a tr��c kh�ng th�ng");
		return
	end
	SetFightState(1);
	AddSkillState(963, 1, 0, 18*3)
	Msg2Player("Ng�i y�n! Ch�ng ta �i M� cung Thi�n T�m ��ng.");
end

function MoveToMatDaoNhaMon()
	if (Condition() < 1) then
		return end;
	if (NewWorld(79, 1594, 3211) == 0)then
		Msg2Player("���ng ph�a tr��c kh�ng th�ng");
		return
	end
	SetFightState(1);
	AddSkillState(963, 1, 0, 18*3)
	Msg2Player("Ng�i y�n! Ch�ng ta �i M�t ��o Nha m�n T��ng D��ng.");
end

function MoveToCamDia()
	if (Condition() < 1) then
		return end;
	if (NewWorld(158, 1583, 3192) == 0)then
		Msg2Player("���ng ph�a tr��c kh�ng th�ng");
		return
	end
	SetFightState(1);
	AddSkillState(963, 1, 0, 18*3)
	Msg2Player("Ng�i y�n! Ch�ng ta �i M� cung c�m ��a.");
end

function MoveToThienTamThap3()
	if (Condition() < 1) then
		return end;
	if (NewWorld(166, 1667, 3244) == 0)then
		Msg2Player("���ng ph�a tr��c kh�ng th�ng");
		return
	end
	SetFightState(1);
	AddSkillState(963, 1, 0, 18*3)
	Msg2Player("Ng�i y�n! Ch�ng ta �i Thi�n T�m th�p t�ng 3.");
end

function MoveToDaiTuDong()
	if (Condition() < 1) then
		return end;
	if (NewWorld(72, 1583, 3042) == 0)then
		Msg2Player("���ng ph�a tr��c kh�ng th�ng");
		return
	end
	SetFightState(1);
	AddSkillState(963, 1, 0, 18*3)
	Msg2Player("Ng�i y�n! Ch�ng ta �i Thi�n ��i T� ��ng.");
end

function MoveToDuocVuongDong21()
	if (Condition() < 1) then
		return end;
	if (NewWorld(142, 1467, 3284) == 0)then
		Msg2Player("���ng ph�a tr��c kh�ng th�ng");
		return
	end
	SetFightState(1);
	AddSkillState(963, 1, 0, 18*3)
	Msg2Player("Ng�i y�n! Ch�ng ta �i D��c V��ng ��ng t�ng 2-1.");
end

function MoveToDuocVuongDong22()
	if (Condition() < 1) then
		return end;
	if (NewWorld(142, 1515, 3340) == 0)then
		Msg2Player("���ng ph�a tr��c kh�ng th�ng");
		return
	end
	SetFightState(1);
	AddSkillState(963, 1, 0, 18*3)
	Msg2Player("Ng�i y�n! Ch�ng ta �i D��c V��ng ��ng t�ng 2-2.");
end

function MoveToLamDuQuang()
	if (Condition() < 1) then
		return end;
	if (NewWorld(319, 1612, 3612) == 0)then
		Msg2Player("���ng ph�a tr��c kh�ng th�ng");
		return
	end
	SetFightState(1);
	AddSkillState(963, 1, 0, 18*3)
	Msg2Player("Ng�i y�n! Ch�ng ta �i L�m Du Quan.");
end

function MoveToKhoaLangDong()
	if (Condition() < 1) then
		return end;
	if (NewWorld(75, 1872, 3071) == 0)then
		Msg2Player("���ng ph�a tr��c kh�ng th�ng");
		return
	end
	SetFightState(1);
	AddSkillState(963, 1, 0, 18*3)
	Msg2Player("Ng�i y�n! Ch�ng ta �i Kho� Lang ��ng.");
end

function MoveToPhuDungDong()
	if (Condition() < 1) then
		return end;
	if (NewWorld(202, 1786, 2823) == 0)then
		Msg2Player("���ng ph�a tr��c kh�ng th�ng");
		return
	end
	SetFightState(1);
	AddSkillState(963, 1, 0, 18*3)
	Msg2Player("Ng�i y�n! Ch�ng ta �i Ph� Dung ��ng.");
end

function MoveToSaMacDiaBieu()
	if (Condition() < 1) then
		return end;
	if (NewWorld(224, 1619, 3213) == 0)then
		Msg2Player("���ng ph�a tr��c kh�ng th�ng");
		return
	end
	SetFightState(1);
	AddSkillState(963, 1, 0, 18*3)
	Msg2Player("Ng�i y�n! Ch�ng ta �i Sa m�c ��a bi�u.");
end

function MoveToChanNuiTruongBach()
	if (Condition() < 1) then
		return end;
	if (NewWorld(320, 1137, 3151) == 0)then
		Msg2Player("���ng ph�a tr��c kh�ng th�ng");
		return
	end
	SetFightState(1);
	AddSkillState(963, 1, 0, 18*3)
	Msg2Player("Ng�i y�n! Ch�ng ta �i Ch�n n�i Tr��ng B�ch.");
end

function MoveToSaMac1()
	if (Condition() < 1) then
		return end;
	if (NewWorld(225, 1579, 3188) == 0)then
		Msg2Player("���ng ph�a tr��c kh�ng th�ng");
		return
	end
	SetFightState(1);
	AddSkillState(963, 1, 0, 18*3)
	AddTermini(195);
	Msg2Player("Ng�i y�n! Ch�ng ta �i Sa M�c S�n ��ng 1.");
end

function MoveToSaMac2()
	if (Condition() < 1) then
		return end;
	if (NewWorld(226, 1692, 3247) == 0)then
		Msg2Player("���ng ph�a tr��c kh�ng th�ng");
		return
	end
	SetFightState(1);
	AddSkillState(963, 1, 0, 18*3)
	Msg2Player("Ng�i y�n! Ch�ng ta �i Sa M�c s�n ��ng 2.");
end

function MoveToSaMac3()
	if (Condition() < 1) then
		return end;
	if (NewWorld(227, 1583, 3241) == 0)then
		Msg2Player("���ng ph�a tr��c kh�ng th�ng");
		return
	end
	SetFightState(1);
	AddSkillState(963, 1, 0, 18*3)
	Msg2Player("Ng�i y�n! Ch�ng ta �i Sa M�c s�n ��ng 3.");
end

function MoveToTruongBachNam()
	if (Condition() < 1) then
		return end;
	if (NewWorld(321, 966, 2296) == 0)then
		Msg2Player("���ng ph�a tr��c kh�ng th�ng");
		return
	end
	SetFightState(1);
	AddSkillState(963, 1, 0, 18*3)
	Msg2Player("Ng�i y�n! Ch�ng ta �i Tr��ng B�ch s�n Nam.");
end

function MoveToTruongBachBac()
	if (Condition() < 1) then
		return end;
	if (NewWorld(322, 2048,4120) == 0)then
		Msg2Player("���ng ph�a tr��c kh�ng th�ng");
		return
	end
	SetFightState(1);
	AddSkillState(963, 1, 0, 18*3)
	Msg2Player("Ng�i y�n! Ch�ng ta �i Tr��ng B�ch s�n B�c.");
end

function MoveToPhongLangDo()
	if (Condition() < 1) then
		return end;
	if (NewWorld(336, 1112, 3189) == 0)then
		Msg2Player("���ng ph�a tr��c kh�ng th�ng");
		return
	end
	SetFightState(1);
	AddSkillState(963, 1, 0, 18*3)
	Msg2Player("Ng�i y�n! Ch�ng ta �i Phong L�ng ��.");
end

function MoveToMacCaoQuat()
	if (Condition() < 1) then
		return end;
	if (NewWorld(340, 1853, 3446) == 0)then
		Msg2Player("���ng ph�a tr��c kh�ng th�ng");
		return
	end
	SetFightState(1);
	AddSkillState(963, 1, 0, 18*3)
	Msg2Player("Ng�i y�n! Ch�ng ta �i M�c Cao Qu�t.");
end

function Condition()
	if (GetLevel() <= 30) then
		nPrice = 200;
	elseif (GetLevel() > 30) and (GetLevel() <= 60) then
		nPrice = 300;
	elseif (GetLevel() > 60) and  (GetLevel() <= 80) then
		nPrice = 400;
	elseif (GetLevel() > 80) and  (GetLevel() <= 120) then
		nPrice = 500;
	else
		nPrice = 1000;
	end
	
	if (GetCash() < nPrice) then
		Talk(1,"","��i gia c�n c� "..nPrice.." l��ng l� ph� �i ���ng v� b�o ti�u h�nh l� c� nh�n cho ��i hi�p!");
		return 0;
	end
	Pay(nPrice);
	return 1;
end	

----------------------------
--Quay lai diem cu
----------------------------
function TownPortalFun()
	 ReturnFromPortal();
end
----------------------------
--
----------------------------
function RememberPlace()
	p1 = GetWayPoint(1);
	p2 = GetWayPoint(2);
	p3 = GetWayPoint(3);
	WAYPOINT={};
	local i = 1;
	if (p1 ~= 0)  then
	name = GetWayPointName(p1);
	name = name .."/SelWayPoint";
	WAYPOINT[i]= name;
	i = i + 1;
	end;
	
	if (p2 ~= 0)  then
	name = GetWayPointName(p2);
	name = name .."/SelWayPoint";
	WAYPOINT[i]= name;
	i = i + 1;
	end;
	
	if (p3 ~= 0)  then
	name = GetWayPointName(p3);
	name = name .."/SelWayPoint";
	WAYPOINT[i]= name;
	i = i + 1;
	end;
	
	WAYPOINT[i] = "Kh�ng �i ��u c� /OnCancel";
	if (i == 1) then 
	Talk(1,"","Ng��i ch�a �i ��u c�, kh�ng c� ��a �i�m n�o �� �i qua!");
	else
	Say("H�y l�a ch�n:", i, WAYPOINT);
	end;	
end

function SelWayPoint(nSel)
	Msg2Player("nSel "..nSel.."");
	local nWayPoint = GetWayPoint(nSel + 1);
	if (nWayPoint ~= 0) then
	local nW, nX, nY = GetWayPointPos(nWayPoint)
	nFightState = GetTerminiFState(nWayPoint)
	nResult = NewWorld(nW, nX, nY);
	if (nResult == 1) then
	SetFightState(nFightState)
	end
	end
end;
----------------------------
--
----------------------------
function MoveToHoaSon()
NewWorld(2, 2605, 3592);
SetFightState(1);
SetLogoutRV(0);
end;
----------------------------
--
----------------------------
function MoveTichTinhDong()
	local szHello = "<color=orange>Xa phu<color>: N�i n�y khi �i ���c s� d�ng t�i m�u, nh�ng kh�ng th� th� ��a ph�. M�t khi t� tr�n s� m�t l�nh b�i!";
	local szSay = {
		"Ta c� l�nh b�i, ��a ta �i/ExMoveTichTinhDong",
		"Ta ch� ��n �� t�m hi�u/OnCancel",
	};
	Say(szHello,getn(szSay),szSay);
end;

function ExMoveTichTinhDong()
	if (GetTaskItemCount(26) == 0 ) then
		Talk(1,"","Cao th� th� n�i nhi�u � ��y th� tr�n c�ng th�ng, m�t khi ng��i t� tr�n kh�ng th� quay l�i ���c. Ta c�n l�nh b�i T�ch t�nh ��ng.");
		return
	end;
	
	if (GetLevel() < 80) then
		Talk(1,"","��t ��ng c�p 80 h�y quay l�i t�m ta, n�i n�y kh�ng d�nh cho nh�ng cao th� b�n l�nh tr�n giang h�!");
		return
	end;
	-- NewWorld(342, 1162, 2392);
	NewWorld(341, 1278, 2497)
	local nOldSubWorld = SubWorld;
	SubWorld = SubWorldID2Idx(341);
	SetRevPos(1);
	SetFightState(0);
	LeaveTeam();
	SetPunish(1);
	-- ForbidTownPortal(1);
	DelTaskItem(26);
	SetDeathScript("\\script\\event\\tichtinhdong\\player_death.lua");
	SubWorld = nOldSubWorld;
end;
----------------------------
--TAY TUY
----------------------------
szClearSkill = {
	"Ch� t�y ti�m n�ng[6 Tinh h�ng b�o th�ch]./GotoClearSkillMap_2",
	"Ch� t�y k� n�ng[1 b� th�y tinh]./GotoClearSkillMap_2",
	"T�y ti�m n�ng v� k� n�ng[6 Tinh h�ng b�o th�ch + 1 b� th�y tinh]./GotoClearSkillMap_2",
	"�� ta suy ngh� l�i./OnCancel"
}

----------------------------
--
----------------------------
function GotoClearSkillMap()
	local nLevel = GetLevel()
	if(GetLevel() < 50) then
		Talk(1,"", "��ng c�p ch�a ��t <color=red>50<color>, kh�ng th� l�n �� t�y t�y.")
		return
	end
	if(GetCamp() == 0) then
		Talk(1,"", "Ng��i ch�a gia nh�p m�n ph�i, kh�ng th� l�n ��o t�y t�y.")
		return
	end

	 local n = GetTask(0)
	 if(GetByte(n,4) == 0) then
		 Say("<color=gold>Xa Phu<color>: Ch� c� <color=red>c� h�i 1 l�n<color> l�n ��o t�y t�y mi�n ph�. Ng��i �� suy ngh� k� ch�a?",2, "L�n ��o t�y t�y./GotoClearFree", "�� ta suy ngh� l�i./OnCancel")
		 return
	 end
	 Say("<color=gold>Xa Phu<color>: S� l�n t�y t�y mi�n ph� �� h�t, ng��i c� th� s� d�ng <color=green>Th�y Tinh<color> ho�c <color=green>Tinh H�ng B�o Th�ch<color> �� l�n ��o?",getn(szClearSkill),szClearSkill)
end

----------------------------
--
----------------------------
function GotoClearSkillMap_2(nSel)
	nSel = tonumber(nSel) + 1
	if(nSel == 1) then
		GotoClearProp(0)
	elseif(nSel == 2) then
		GotoClearSkill(0)
	elseif(nSel == 3) then
		GotoClearAll()
	end
end

----------------------------
--
----------------------------
function GotoClearFree()
	SetTask(0,SetByte(n,4,4))
	GotoClearFreeCore()
end

----------------------------
--
----------------------------
function GotoClearFreeCore()
	--ForbidTownPortal(1)
	SetFightState(0)
	SetPunish(0)
	SetLogoutRV(1)
	SetRevPos(242,1)
	NewWorld(242,1613,3197)	
	Talk(1,"","�� ��n ��o t�y t�y! H�y t�n d�ng c� h�i �� th�ng kinh m�ch c�n th�n nh�.")
end

----------------------------
--
----------------------------
function GotoClearProp(bCheck)
	local nCount = GetItemCountInBag(6,15,1,-1,1)
	if(nCount < 6) then
		Talk(1,"","Ng��i kh�ng mang �� <color=red>6 vi�n<color> <color=green>Tinh H�ng B�o Th�ch<color>. Kh�ng n�n n�ng l�ng, t�m �� r�i h�y tr� l�i.")
		return 0
	end
	
	if(bCheck == 2) then
		return 1
	end
	
	local i
	for i = 1, 6 do
		DelTaskItem(15,1)
	end
	
	if(bCheck == 3) then
		return 2
	end
	local n = GetTask(0)
	SetTask(0,SetByte(n,4,3))
	GotoClearFreeCore()
end

----------------------------
--
----------------------------
function GotoClearSkill(bCheck)
	x = GetItemCountInBag(6,16,1,-1,1)
	y = GetItemCountInBag(6,17,1,-1,1)
	z = GetItemCountInBag(6,18,1,-1,1)
	
	if( (x == 0) or (y == 0) or (z == 0) ) then
		Talk(1,"","Ng��i kh�ng mang �� <color=red>3 vi�n<color> <color=green>Th�y Tinh<color>. ��ng n�ng l�ng, t�m �� h�y quay l�i.")
		return 0
	end
	
	if(bCheck == 2) then
		return 1
	end
	
	DelTaskItem(16,1)
	DelTaskItem(17,1)
	DelTaskItem(18,1)
	
	if(bCheck == 3) then
		return 2
	end
	
	local n = GetTask(0)
	SetTask(0,SetByte(n,4,2))
	GotoClearFreeCore()
end

----------------------------
--
----------------------------
function GotoClearAll()
	local nCount = GetItemCountInBag(6,15,1,-1,1)
	x = GetItemCountInBag(6,16,1,-1,1)
	y = GetItemCountInBag(6,17,1,-1,1)
	z = GetItemCountInBag(6,18,1,-1,1)

	if((nCount < 6) or (x == 0) or (y == 0) or (z == 0)) then
		Talk(1,"","C�n 6 tinh h�ng b�o th�ch v� 1 b� th�y tinh.")
		return 0
	end
	if(GotoClearProp(2) == 0) or (GotoClearSkill(2) == 0) then
		return
	end
	if(GotoClearProp(3) == 0) or (GotoClearSkill(3) == 0) then
		return
	end
	local n = GetTask(0)
	SetTask(0,SetByte(n,4,1))
	GotoClearFree()
end

----------------------------
--
----------------------------
function OnCancel()
Talk(1,"","Kh�ch quan �i thong th�, n�u c�n ta gi�p �� th� h�y tr� l�i ��y! ");
end;