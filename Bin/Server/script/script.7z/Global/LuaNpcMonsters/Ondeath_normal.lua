-- Author:	Kinnox;
-- Date:	25-08-2021
-- Functions: Script Ondeath _ Droprate  Normal / Blue Boss / Gold Boss;
Include("\\script\\lib\\tasklib.lua");
Include("\\script\\lib\\libevent.lua")
 function OnDeath(nNpcIndex,nLastdamage)
--function OnDeath(nNpcIndex)
	local nPlayerIndex = NpcIdx2PIdx(nLastdamage);
	PlayerIndex = nPlayerIndex;
	
	local nX,nY,nW = GetNpcPos(nNpcIndex);
	local nSeries			= GetNpcSeries(nNpcIndex);
	local nLevel  			= GetNpcLevel(nNpcIndex);
	local nGoldNpc 			= GetNpcGold(nNpcIndex);
	local nPriceNormal 		= 0;
	local nDropItem			= "";
	local nPriceBossBlue 	= 0;
	local nPriceBossGold 	= 0;
	local nXMoney 			= 1; -- x2 drop tien
	local nExp				= 1;
	local EXPBoss			= 3; -- x3 nhan kinh nghiem boss xanh;
	local nIndexItem = 0;
	if (nLevel <= 0) then
	return end;
	if (nSeries < 0 or nSeries > 4) then 
	return end;
	if (nLevel < 10) then
		nLevel = 1;
	elseif (nLevel > 100) then 
		nLevel = random(9,10);
	else
		nLevel = floor(nLevel/10);
	end;
	-----///DROPPRICE

	if (nLevel == 1) then
		nPriceNormal = random(30,32);
		nPriceBossBlue = random(100,132);
		nDropItem = "\\settings\\droprate\\npcdroprate10.ini"	
		nExp = 90*EXPBoss;
	elseif (nLevel == 2) then
		nPriceNormal = random(50,52);
		nPriceBossBlue = random(100,232);
		nDropItem = "\\settings\\droprate\\npcdroprate20.ini"
		nExp = 1300*EXPBoss;
	elseif (nLevel == 3) then
		nPriceNormal = random(60,82);
		nPriceBossBlue = random(200,332);
		nDropItem = "\\settings\\droprate\\npcdroprate30.ini"
		nExp = 1400*EXPBoss;
	elseif (nLevel == 4) then
		nPriceNormal = random(80,102);
		nPriceBossBlue = random(200,432);
		nDropItem = "\\settings\\droprate\\npcdroprate40.ini"
		nExp = 1500*EXPBoss;
	elseif (nLevel == 5) then
		nPriceNormal = random(90,202);
		nPriceBossBlue = random(300,532);
		nDropItem = "\\settings\\droprate\\npcdroprate50.ini"
		nExp = 2000*EXPBoss;
	elseif (nLevel == 6) then
		nPriceNormal = random(100,252);
		nPriceBossBlue = random(300,432);
		nDropItem = "\\settings\\droprate\\npcdroprate60.ini"
		nExp = 2000*EXPBoss;
	elseif (nLevel == 7) then
		nPriceNormal = random(110,272);
		nPriceBossBlue = random(300,532);
		nDropItem = "\\settings\\droprate\\npcdroprate70.ini"
		nExp = 2000*EXPBoss;
	elseif (nLevel == 8) then
		nPriceNormal = random(210,282);
		nPriceBossBlue = random(300,632);	
		nDropItem = "\\settings\\droprate\\npcdroprate80.ini"
		nExp = 2000*EXPBoss;
	elseif (nLevel >= 9) then
		local nRanDrop = random(1,2);
		if (nRanDrop > 2) then
		nPriceNormal = random(301,302);
		nPriceBossBlue = random(301,332);
		nDropItem = "\\settings\\droprate\\npcdroprate90.ini"
		nExp = 3000*EXPBoss;
		else
		nPriceNormal = random(411,502);
		nPriceBossBlue = random(411,532);		
		nDropItem = "\\settings\\droprate\\npcdroprate110.ini"
		nExp = 5000*EXPBoss;
		end
	end; 
	
	---///DROPITEM
	if (nGoldNpc >= 13 and nGoldNpc <= 15) then
		nRanMatChi = random(1,5);
		if (nRanMatChi == 3) then
			nIndexItem = DropItem(nW,nX,nY,PlayerIndex,7,26,1,1,-1,0,0);
			SetObjPickExecute(nIndexItem,1);
		end;
		DropRateItem(nNpcIndex,random(3,5),nDropItem,1,nLevel,nSeries)
		AddOwnExp(nExp);
		for i = 1,random(2,3) do
			DropMoney(nPriceBossBlue*nXMoney,nX,nY);
		end;
		if (nLevel >=1 and nLevel <=7) then
		--content--
		else
			if (random(1,200) == 151) then
				DropItem(nW,nX,nY,PlayerIndex,6,random(16,18),1,1,-1,0,0);
			end;
		end;
		if (nW == 336) then
			if (random(1,10) == 8) then
			 nIndexItem = DropItem(nW,nX,nY,PlayerIndex,6,12,1,1,-1,0,0); -- lenh bai phong lang do
			end;
		end;
	elseif (nGoldNpc == 2) then
		----///BOSS HOANG KIM
		EventBossHoangKim(nNpcIndex,nW,nX,nY,PlayerIndex,nSeries);
		local nOldPlayerIndex = PlayerIndex;
		local nIDTong = GetTongID();
		if (nIDTong > 0) then
			for i = 1, 300 do
				PlayerIndex = i;
				if (PlayerIndex ~= nOldPlayerIndex) then 
					if (GetTongID() == nIDTong) then
						AddOwnExp(5000000);
						Msg2Player("��i hi�p nh�n ���c <color=pink>5.000.000 �i�m kinh nghi�m<color> t� ��ng ��i!");
					end;
				end;
			end
			PlayerIndex = nOldPlayerIndex;
			Msg2SubWorld("��i hi�p <color=blue> "..GetName().." <color> thu�c bang h�i <color=yellow>"..GetTongName().." <color> ��nh ch�t Boss Ho�ng Kim, to�n b� bang h�i nh�n ���c <color=pink>5.000.000 �i�m kinh nghi�m<color>");
		end;
		
	else
		nRanMoney 	= random(1,15);
		if (nRanMoney == 10) then
			DropMoney(nPriceNormal*nXMoney,nX,nY);
		end;
		nRanDoChi = random(1,100);
		if (nRanDoChi == 56) then
			nIndexItem = DropItem(nW,nX,nY,PlayerIndex,7,25,1,1,-1,0,0);
			SetObjPickExecute(nIndexItem,1);
		end;
		nRanItem 	= random(1,135);
		if (nRanItem == 122) then
			DropRateItem(nNpcIndex,1,nDropItem,1,nLevel,nSeries)
		end;
		if (random(1,35) == 20 and nW == 336) then
			DropItem(nW,nX,nY,PlayerIndex,6,12,1,1,-1,0,0); -- lenh bai phong lang do
		end;
	end;
	---/// Da tau
		--event
	--if (nLevel > 7) then
	--	if (random(1,35) == 20) then
	--		DropItem(nW,nX,nY,PlayerIndex,7,135,1,1,-1,0,0);
	--	end;
	--end;
	
	SetTask(T_DROPTIENDONG,GetTask(T_DROPTIENDONG) + 1);
	--Drop tien dong
	if (nLevel > 7) then
		if (GetTask(T_DROPTIENDONG) >= 1000) then
			if (random(1,3) == 3) then
				DropItem(nW,nX,nY,PlayerIndex,6,19,1,1,-1,0,0);
				DropItem(nW,nX,nY,PlayerIndex,6,19,1,1,-1,0,0);
			else
				DropItem(nW,nX,nY,PlayerIndex,6,19,1,1,-1,0,0);
			end
			SetTask(T_DROPTIENDONG,0);
		end;
	end;

	local nW,nX,nY = GetWorldPos()
	if(GetTask(TASK_KIND) == 3 and GetTask(TASK_SAVEQUEST_1) == nW) then
		if (GetTask(TASK_DT_DANHQUAI) > 0 ) then
			SetTask(TASK_DT_DANHQUAI,GetTask(TASK_DT_DANHQUAI) - 1)
			Msg2Player("Nhi�m v� d� t�u","<color=gold>Nhi�m v� ti�u di�t qu�i, ti�n �� <color=yellow>"..GetTask(TASK_DT_DANHQUAI).."")
		end;
	end;
end;

function OnRevive(nNpcIndex)
	local nRandom = random(1,100);
	if (nRandom == 40) then
		IsBoss(nNpcIndex,random(13,15));
	end;
	SetNpcScript(nNpcIndex, "\\script\\global\\luanpcmonsters\\ondeath_normal.lua");
end;

