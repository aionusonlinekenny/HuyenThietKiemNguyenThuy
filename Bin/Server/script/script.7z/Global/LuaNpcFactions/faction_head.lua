----------------------------------
--	Copyright: JX Online by Kinnox
--	Author: Kinnox
--	Date: 16/08/2014
--	Desc: Th� vi�n m�n ph�i
----------------------------------
Include("\\script\\lib\\TaskLib.lua")
Faction = {}
Faction.SexName = {"S� ��", "S� mu�i"}
Faction.BASE_SKILL_LEVEL = 0
--
Faction.LEAVE_LEVEL	 = 60
Faction.LEAVE_COST	 = 10000
Faction.RETURN_COST	 = 10000
--
Faction.TFACTION_INFO = {
	[1] = {
		sIDName = "shaolin",
		sFactionName = "Thi�u L�m ph�i",
		tbSkillBase = {10,14,4,6,8,15,16,20,271,11,19,273,21},
		tbSkill90 = {
			{"��t Ma �� Giang", 318, 20},
			{"Ho�nh T�o Thi�n Qu�n", 319, 20},
			{"V� T��ng Tr�m", 321, 20}
		},
		tbSkill120 = {"��i Th�a Nh� Lai Ch� ",709, 20},
		nCamp = 1,
		nRankID = 72,
	},
	[2] = {
		sIDName = "tianwang",
		sFactionName = "Thi�n V��ng Bang",
		tbSkillBase = {34,30,29,23,24,26,33,37,35,31,40,42,36,32,41,324},
		tbSkill90 = {
			{"Ph� Thi�n Tr�m", 322,20},
			{"Truy Tinh Tr�c Nguy�t", 323,20},
			{"Truy Phong Quy�t", 325,20}
		},
		tbSkill120 = {"��o H� Thi�n",708, 20},
		nCamp = 3,
		nRankID = 79,
	},
	[3] = {
		sIDName = "tangmen",
		sFactionName = "���ng M�n",
		tbSkillBase = {45,43,347,303,50,54,47,343,345,349,249,58,341,48},
		tbSkill90 = {
			{"C�u Cung Phi Tinh", 342,20},
			{"Nhi�p H�n Nguy�t �nh", 339,20},
			{"B�o V� L� Hoa", 302,20},
			{"Lo�n Ho�n K�ch", 351,0},
		},
		tbSkill120 = {"M� �nh Tung",710, 20},
		tbSkill150 = {
			{"��i L�c Kim Cang Ch��ng", 1069, 20},
			{"Vi �� Hi�n X�", 1070, 20},
			{"Tam Gi�i Quy Thi�n", 1071, 20}
		},
		nCamp = 3,
		nRankID = 76,
	},
	[4] = {
		sIDName = "wudu",
		sFactionName = "Ng� ��c Gi�o",
		tbSkillBase = {63,65,62,60,67,70,66,68,384,64,69,356,73,72,75,71,74},
		tbSkill90 = {
			{"�m Phong Th�c C�t", 353, 20},
			{"Huy�n �m Tr�m", 355, 20},
			{"�o�n C�n H� C�t", 390, 0}
		},
		tbSkill120 = {"H�p Tinh Y�m",711, 20},
		nCamp = 2,
		nRankID = 80,
	},
	[5] = {
		sIDName = "emei",
		sFactionName = "Nga My ph�i",
		tbSkillBase = {85,80,77,79,93,385,82,89,86,92,252,88,91,282},
		tbSkill90 = {
			{"Tam Nga T� Tuy�t", 328, 20},
			{"Phong S��ng To�i �nh", 380, 20},
			{"Ph� �� Ch�ng Sinh", 332, 20}
		},
		tbSkill120 = {"B� Nguy�t Ph�t Tr�n",712, 20},
		nCamp = 1,
		nRankID = 74,
	},
	[6] = {
		sIDName = "cuiyan",
		sFactionName = "Th�y Y�n M�n",
		tbSkillBase = {99,102,95,97,269,105,113,100,109,114,108,111},
		tbSkill90 = {
			{"B�ng Tung V� �nh", 336, 20},
			{"B�ng T�m Ti�n T� ", 337, 20},
		},
		tbSkill120 = {"Ng� Tuy�t �n",713, 20},
		nCamp = 3,
		nRankID = 77,
	},
	[7] = {
		sIDName = "gaibang",
		sFactionName = "C�i Bang",
		tbSkillBase = {122,119,116,115,129,274,124,277,128,125,130,360},
		tbSkill90 = {
			{"Phi Long T�i Thi�n", 357,20},
			{"Thi�n H� V� C�u", 359,20},
		},
		tbSkill120 = {"H�n Thi�n Kh� C�ng",714, 20},
		tbSkill150 = {
			{"��i L�c Kim Cang Ch��ng", 1073, 20},
			{"Vi �� Hi�n X�", 1074, 20},
		},
		nCamp = 1,
		nRankID = 78,
	},
	[8] = {
		sIDName = "tianren",
		sFactionName = "Thi�n Nh�n Gi�o",
		tbSkillBase = {135,145,132,131,136,137,141,138,140,364,143,150,142,148},
		tbSkill90 = {
			{"V�n Long K�ch", 361,20},
			{"Thi�n Ngo�i L�u Tinh", 362,20},
			{"Nhi�p H�n Lo�n T�m", 391,0}
		},
		tbSkill120 = {"Ma �m Ph� Ph�ch",715, 20},
		tbSkill150 = {
			{"��i L�c Kim Cang Ch��ng", 1075, 20},
			{"Vi �� Hi�n X�", 1076, 20},
		},
		nCamp = 2,
		nRankID = 81,
	},
	[9] = {
		sIDName = "wudang",
		sFactionName = "V� �ang ph�i",
		tbSkillBase = {153,155,152,151,159,164,158,160,157,166,165,267},
		tbSkill90 = {
			{"Thi�n ��a V� C�c", 365, 20},
			{"Nh�n Ki�m H�p Nh�t", 368, 20},
		},
		tbSkill120 = {"Xu�t � B�t Nhi�m",716, 20},
		nCamp = 1,
		nRankID = 73,
	},
	[10] = {
		sIDName = "kunlun",
		sFactionName = "C�n L�n ph�i",
		tbSkillBase = {169,179,167,168,174,171,392,178,172,393,173,175,181,176,182,90,275,630},
		tbSkill90 = {
			{"Ng�o Tuy�t Ti�u Phong", 372, 20},
			{"L�i ��ng C�u Thi�n", 375, 20},
			{"T�y Ti�n T� C�t", 394, 0}
		},
		tbSkill120 = {"L��ng Nghi Ch�n Kh�",717,20},
		nCamp = 3,
		nRankID = 75,
	},
	[11] = {
		sIDName = "huashan",
		sFactionName = "Hoa S�n ph�i",
		tbSkillBase = {1347,1372,1349,1374,1350,1375,1351,1376,1354,1378,1355,1379,1358,1360,1380},
		tbSkill90 = {
			{"Th�i Nh�c Tam Thanh Phong", 1363, 20},
			{"Ph�ch Th�ch Ph� Ng�c", 1382, 20},
		},
		tbSkill120 = {"T� H� Ki�m Kh�",1365, 20},
		nCamp = 3,
		nRankID = 75,
	},	
}
--
Faction.TRANSLIFE = {
	[1] = {0,50,100,150,200,250},
	[2] = {0,10,20,30,40,50},	
}

----------------------------------
-- Gia nh�p m�n ph�i
----------------------------------
function Faction:JoinFaction(nNo)
	if(type(nNo) ~= "number") then
		return 0
	end
	if(nNo < 1 or nNo > getn(self.TFACTION_INFO)) then
		return 0
	end
	SetFaction(self.TFACTION_INFO[nNo].sIDName)
	for i = 1, getn(self.TFACTION_INFO[nNo].tbSkillBase) do
		AddMagic(self.TFACTION_INFO[nNo].tbSkillBase[i],self.BASE_SKILL_LEVEL)
	end
--	SetRank(self.TFACTION_INFO[nNo].nRankID)
	Msg2Player("Tin Ph�i","B�n �� gia nh�p "..self.TFACTION_INFO[nNo].sFactionName..".")
	return 1
end

----------------------------------
-- Xu�t s� kh�i ph�i
----------------------------------
function Faction:LeaveFaction(nNo)
	if(GetLevel() < self.LEAVE_LEVEL) then
		Talk(1,"", 10020)
		return 0
	end
	local nCash = GetCash()
	if (nCash < self.LEAVE_COST) then
		Talk(1,"", 10021)
		return 0
	end
	Pay(self.LEAVE_COST)
	if(GetCash() == nCash - self.LEAVE_COST) then
		local n = GetTask(0)
		SetTask(0, SetByte(n,1,nNo))
		SetCamp(4)
		SetCurCamp(4)
		Msg2Player("Tin Ph�i","B�n �� r�i kh�i "..self.TFACTION_INFO[nNo].sFactionName..".")
		return 1
	else
		Talk(1, "", 10002)
	end
	return 0
end

----------------------------------
-- Quay v� m�n ph�i
----------------------------------
function Faction:ReturnFaction(Sel,nNo)
	local nCash = GetCash()
	if (nCash < self.RETURN_COST) then
		Talk(1,"", 10023)
		return 0
	end
	Pay(self.RETURN_COST)
	if(GetCash() == nCash - self.RETURN_COST) then
		local n = GetTask(0)
		SetTask(0, SetByte(n,1,0))
		SetCurCamp(self.TFACTION_INFO[nNo].nCamp)
		SetCamp(self.TFACTION_INFO[nNo].nCamp) 
--		SetRank(self.TFACTION_INFO[nNo].nRankID)
		Msg2Player("Tin Ph�i","B�n �� quay l�i "..self.TFACTION_INFO[nNo].sFactionName..".")
		return 1
	else
		Talk(1, "", 10002)
		return 0
	end
end
--*--
function OnClearProp()
	Say("Ng��i c� ch�c r�ng mu�n t�y ti�m n�ng? ",2, 
		"T�y ti�m n�ng./OnClearPropCore", 
		"Kh�ng t�y./OnCanCel")
end


function OnClearPropCore()
	Faction:ResetAttr()
	Talk(1,"","Kinh m�ch �� ���c �� th�ng, h�y suy x�t th�t k�.")
end


function OnClearMagic()
	Say("Ng��i c� ch�c r�ng mu�n t�y k� n�ng? ",2, 
	"T�y k� n�ng./OnClearMagicCore", 
	"Kh�ng t�y./OnCanCel")
end


function OnClearMagicCore()
	Faction:ResetMagic(0)
	Talk(1,"","Kinh m�ch �� ���c �� th�ng, h�y suy x�t th�t k�.")
end


function OnClearAll()
	Say("Ng��i c� ch�c r�ng mu�n t�y t�t c�? ",2, "T�y t�t c�./OnClearAllCore", "Kh�ng t�y./OnCanCel")
end


function OnClearAllCore()
	Faction:ResetAttr()
	Faction:ResetMagic(0)
	Talk(1,"","Kinh m�ch �� ���c �� th�ng, h�y suy x�t th�t k�.")
end
--*--
function Faction:ResetAttr()
	local nSeries = GetSeries() -- Thu�c t�nh ng� h�nh c�a nh�n v�t
	local nCurTL = GetTransLife() + 1 -- S� l�n tr�ng sinh
	local nPoint = GetTask(T_TTK) + self.TRANSLIFE[1][nCurTL] -- �i�m ti�m n�ng
	ResetBaseAttribute(nSeries)
	AddProp(nPoint)
end

--*--
function Faction:ResetMagic(bIsTransLife)
	local i = HaveMagic(210)		-- Tr� v� c�p k� n�ng khinh c�ng
	local n = RollbackSkill()		-- T�y h�t k� n�ng v� tr� v� s� �i�m k� n�ng
	local x = 0
	if(i ~= -1) then x = x + i end		--Ch�nh l�ch �i�m k� n�ng khi c� c�c k� n�ng ngo�i
	n = n - x		-- Tr� v� �i�m k� n�ng ��ng �p
	if( (n + GetMagicPoint() ) < 0) then
		n = -1 + GetMagicPoint()
	end
	local nExPoint = GetTask(T_VLMT)		-- �i�m v� l�m m�t t�ch
	local nMaxPoint = GetLevel() - 1		--> �i�m k� n�ng theo level
	if(n > nMaxPoint) then
		n = nMaxPoint
	end
	n = n + nExPoint
	AddMagicPoint(n)
	if(i ~= -1) then AddMagic(210,i) end		-- Tr� l�i k� n�ng khinh c�ng
end


----------------------------------
--	Tho�t kh�i ��i tho�i
----------------------------------
function OnCancel()
end