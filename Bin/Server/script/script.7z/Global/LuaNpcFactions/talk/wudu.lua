----------------------------------
--	Copyright: JX Online by Kinnox
--	Author: Kinnox
--	Date: 16/08/2014
--	Desc: Ng� ��c T�n Nh�n
----------------------------------
Include("\\script\\Global\\LuaNpcFactions\\talk\\master_main.lua")

----------------------------------
--
----------------------------------
function main(nNpcIdx)
	local sPlayer_Faction = GetFaction()
	if(sPlayer_Faction == "") then
		Talk(1, "Enroll_Select", 10077)
	elseif(sPlayer_Faction == "wudu") then
		local sNpcName = format("<color=wood>%s<color>:", GetNpcName(nNpcIdx))
		local sImage = "44/44/35"
		local n = GetTask(0)
		if(GetByte(n,1) == 0) then
			SayImage(""..sNpcName.." ��c d��c r�t nguy hi�m, ng��i m�i nh� ng��i sao kh�ng lo luy�n t�p? T�m ta c� vi�c g�?",sImage,4, "Ta mu�n xu�t s�./Leave", "T�m hi�u khu v�c luy�n c�ng./map_help","T�m hi�u v� ngh� b�n m�n./SkillHelp", "Nh�n ti�n gh� qua./OnCancel")
		else
			if(GetTongID() ~= 0) then
				if(GetTongFigure() < 3) then
					SayImage(""..sNpcName.." Bang h�i <color=green>"..GetTongName().."<color> s� h�ng th�nh nh� s� g�p m�t c�a "..Faction.SexName[GetSex() + 1].." ��! C� g�ng l�n! Haha!",sImage,1, "�a t� s� huynh./OnCancel")
				else
					SayImage(""..sNpcName.." Th�nh l�p <color=green>"..GetTongName().."<color> r�i �? Th�t kh�ng h� danh l� �� t� Ng� ��c gi�o! Thanh danh gi�o ph�i r�i ��y s� vang xa h�n c�i b�n t� nh�n l� danh m�n ch�nh ph�i th�i! Haha",sImage,1, "�a t� s� huynh./OnCancel")
				end
			else
				SayImage(""..sNpcName.." ��c m�n r�n luy�n kh�ng bao gi� l� ��, "..Faction.SexName[GetSex() + 1].." c� mu�n quay v� �� r�n luy�n th�m kh�ng?",sImage,2, "Quay v� Ng� ��c gi�o./Return", "Nh�n ti�n gh� qua./OnCancel")
			end
		end
	elseif(sPlayer_Faction == "emei") then
		Talk(1, "", 10078)
	elseif(sPlayer_Faction == "cuiyan") then
		Talk(1, "", 10079)
	elseif(sPlayer_Faction == "tangmen") then
		Talk(1, "", 10080)
	elseif(sPlayer_Faction == "tianwang") then
		Talk(1, "", 10081)
	elseif(sPlayer_Faction == "shaolin") then
		Talk(1, "", 10082)
	elseif(sPlayer_Faction == "wudang") then
		Talk(1, "", 10083)
	elseif(sPlayer_Faction == "kunlun") then
		Talk(1, "", 10084)
	elseif(sPlayer_Faction == "tianren") then
		Talk(1, "", 10085)
	elseif(sPlayer_Faction == "gaibang") then
		Talk(1, "", 10086)
	end
end

----------------------------------
--
----------------------------------
function Enroll_Select()
	if(GetSeries() ~= 1) then
		return
	end
	if(GetLevel() < 10) then
		Talk(1,"",10005)
		return
	end
	if(GetCamp() ~= 0) then
		Talk(1,"", 10006)
		return
	end
	Say(10087, 2, "Gia nh�p Ng� ��c gi�o./Go", "�� ta suy ngh� k� l�i xem./OnCancel")
end

----------------------------------
--
----------------------------------
function Go()
	if(join_main(4) ~= 0) then
		Talk(1,"",10088)
	end
end

----------------------------------
--
----------------------------------
function Leave()
	Say(10089, 2, "Xu�ng n�i trinh s�t./OnLeave", "�� ta xem l�i ��./OnCancel")
end

----------------------------------
--
----------------------------------
function OnLeave()
	if(leave_main(4) ~= 0) then
		Talk(1,"",10090)
	end
end

----------------------------------
--
----------------------------------
function Return()
	Say(10091, 2, "T�t nhi�n l� c�./OnReturn", "�� ta xem l�i ��./OnCancel")
end

----------------------------------
--
----------------------------------
function OnReturn()
	if(return_main(4) ~= 0) then
		Talk(1,"",10092)
	end
end

----------------------------------
--
---------------------------------
function SkillHelp()
	skill_help(4)
end