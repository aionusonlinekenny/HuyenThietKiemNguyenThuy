----------------------------------
--	Copyright: JX Online by Kinnox
--	Author: Kinnox
--	Date: 16/08/2014
--	Desc: V� �ang ��o Nh�n
----------------------------------
Include("\\script\\Global\\LuaNpcFactions\\talk\\master_main.lua")

----------------------------------
--
----------------------------------
function main(nNpcIdx)
	local sPlayer_Faction = GetFaction()
	if(sPlayer_Faction == "") then
		Talk(3, "Enroll_Select", 10184,10185,10186)
	elseif(sPlayer_Faction == "wudang") then
		local sNpcName = format("<color=earth>%s<color>:", GetNpcName(nNpcIdx))
		local sImage = "-85/-85/40"
		local n = GetTask(0)
		if(GetByte(n,1) == 0) then
			SayImage(""..sNpcName.." "..Faction.SexName[GetSex() + 1].." v� sao kh�ng lo t�p luy�n l�i �i ��n n�i n�y?",sImage,4, "Ta mu�n xu�t s�./Leave", "T�m hi�u khu v�c luy�n c�ng./map_help","T�m hi�u v� ngh� b�n m�n./SkillHelp", "Nh�n ti�n gh� qua./OnCancel")
		else
			if(GetTongID() ~= 0) then
				if(GetTongFigure() < 3) then
					SayImage(""..sNpcName.." "..Faction.SexName[GetSex() + 1].." xu�t s� kh�ng l�u m� �� gia nh�p bang h�i <color=green>"..GetTongName().."<color> r�i sao? C� g�y ti�ng x�u g� cho V� �ang ta kh�ng?",sImage,0)
				else
					SayImage(""..sNpcName.." "..Faction.SexName[GetSex() + 1].." th�ng l�nh bang h�i <color=green>"..GetTongName().."<color> th�t l� b�n l�nh h�n ng��i! L�m s� huynh nh� ta th�t l�y l�m h� th�n!",sImage,0)
				end
			else
				SayImage(""..sNpcName.." "..Faction.SexName[GetSex() + 1].." c� mu�n quay v� n�i V� �ang th�m s� ph� hay kh�ng?",sImage,2, "Quay v� V� �ang./Return", "Nh�n ti�n gh� qua./OnCancel")
			end
		end
	elseif(sPlayer_Faction == "emei") then
		Talk(1, "", 10189)
	elseif(sPlayer_Faction == "cuiyan") then
		Talk(1, "", 10190)
	elseif(sPlayer_Faction == "tangmen") then
		Talk(1, "", 10191)
	elseif(sPlayer_Faction == "wudu") then
		Talk(1, "", 10192)
	elseif(sPlayer_Faction == "tianwang") then
		Talk(1, "", 10193)
	elseif(sPlayer_Faction == "shaolin") then
		Talk(1, "", 10194)
	elseif(sPlayer_Faction == "kunlun") then
		Talk(1, "", 10195)
	elseif(sPlayer_Faction == "gaibang") then
		Talk(1, "", 10196)
	elseif(sPlayer_Faction == "tianren") then
		Talk(1, "", 10197)
	end
end

----------------------------------
--
----------------------------------
function Enroll_Select()
	if(GetSeries() ~= 4) then
		return
	end
	if(GetLevel() < 10) then
		Talk(1,"",10005)
		return
	end
	if(GetCamp() ~= 0) then
		Talk(1,"", 10006)
		return
	end
	Say(10187, 2, "Ta mu�n gia nh�p./Go", "�� ta suy ngh� k� l�i xem./OnCancel")
end

----------------------------------
--
----------------------------------
function Go()
	if(join_main(9) ~= 0) then
		Talk(1,"",10188)
	end
end

----------------------------------
--
----------------------------------
function Leave()
	Say(10198, 2, "R�i kh�i n�i V� �ang./OnLeave", "�� ta xem l�i ��./OnCancel")
end

----------------------------------
--
----------------------------------
function OnLeave()
	if(leave_main(9) ~= 0) then
		Talk(1,"",10199)
	end
end

----------------------------------
--
----------------------------------
function Return()
	Say(10200, 2, "Xu�t ph�t th�i./OnReturn", "Qu�n mang theo r�i./OnCancel")
end

----------------------------------
--
----------------------------------
function OnReturn()
	if(return_main(9) ~= 0) then
		Talk(1,"",10201)
	end
end

----------------------------------
--
---------------------------------
function SkillHelp()
	skill_help(9)
end