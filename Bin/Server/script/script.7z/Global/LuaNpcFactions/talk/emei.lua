----------------------------------
--	Copyright: JX Online by Kinnox
--	Author: Kinnox
--	Date: 16/08/2014
--	Desc: Nga My C�m Y Ni
----------------------------------
Include("\\script\\Global\\LuaNpcFactions\\talk\\master_main.lua")

----------------------------------
--
----------------------------------
function main(nNpcIdx)
	local sPlayer_Faction = GetFaction()
	if(sPlayer_Faction == "") then
		Talk(1, "Enroll_Select", 10098)
	elseif(sPlayer_Faction == "emei") then
		local sNpcName = format("<color=water>%s<color>:", GetNpcName(nNpcIdx))
		local sImage = "-85/-85/36"
		local n = GetTask(0)
		if(GetByte(n,1) == 0) then
			SayImage(""..sNpcName.." Ti�u s� mu�i l�i lang thang ng�m c�nh �? C� c�n ta gi�p g� kh�ng?",sImage,4, "Ta mu�n xu�t s�./Leave", "T�m hi�u khu v�c luy�n c�ng./map_help","T�m hi�u v� ngh� b�n m�n./SkillHelp", "Nh�n ti�n gh� qua./OnCancel")
		else
			if(GetTongID() ~= 0) then
				if(GetTongFigure() < 3) then
					SayImage(""..sNpcName.." �� l�u kh�ng g�p! Ti�u mu�i gia nh�p bang h�i <color=green>"..GetTongName().."<color> r�i �? Hy v�ng v�i k� n�ng c�a m�nh mu�i c� th� gi�p h� v��t qua c�n nguy k�ch!",sImage,1, "�a t� s� t�./OnCancel")
				else
					SayImage(""..sNpcName.." N� nh�n l�nh ��o bang h�i <color=green>"..GetTongName().."<color> sao? R�t t�t! Ai n�i ch�n giang h� ch� gi�nh cho nam nh�n ch�! Haha!",sImage,1, "�a t� s� t�./OnCancel")
				end
			else
				SayImage(""..sNpcName.." Th� gi�i b�n ngo�i c� nh� mu�i t��ng t��ng kh�ng? N�u c�m th�y m�t m�i c� th� quay v� n�i Nga My!",sImage,2, "Quay v� Nga My ph�i./Return", "Nh�n ti�n gh� qua./OnCancel")
			end
		end
	elseif(sPlayer_Faction == "cuiyan") then
		Talk(1, "", 10099)
	elseif(sPlayer_Faction == "tangmen") then
		Talk(1, "", 10100)
	elseif(sPlayer_Faction == "wudu") then
		Talk(1, "", 10101)
	elseif(sPlayer_Faction == "tianwang") then
		Talk(1, "", 10102)
	elseif(sPlayer_Faction == "shaolin") then
		Talk(1, "", 10103)
	elseif(sPlayer_Faction == "wudang") then
		Talk(1, "", 10104)
	elseif(sPlayer_Faction == "kunlun") then
		Talk(1, "", 10105)
	elseif(sPlayer_Faction == "tianren") then
		Talk(1, "", 10106)
	elseif(sPlayer_Faction == "gaibang") then
		Talk(1, "", 10107)
	end
end

----------------------------------
--
----------------------------------
function Enroll_Select()
	if(GetSeries() ~= 2) then
		return
	end
	if(GetLevel() < 10) then
		Talk(1,"",10005)
		return
	end
	if(GetCamp() ~= 0) then
		Talk(1,"", 10006)
		return
	end
	if(GetSex() ~= 1) then
		Talk(1,"", 10109)
		return
	end
	Say(10108, 2, "Ta mu�n gia nh�p./Go", "�� ta suy ngh� k� l�i xem./OnCancel")
end

----------------------------------
--
----------------------------------
function Go()
	if(join_main(5) ~= 0) then
		Talk(1,"",10110)
	end
end

----------------------------------
--
----------------------------------
function Leave()
	Say(10111, 2, "Xu�t s� xu�ng n�i./OnLeave", "�� ta xem l�i ��./OnCancel")
end

----------------------------------
--
----------------------------------
function OnLeave()
	if(leave_main(5) ~= 0) then
		Talk(1,"",10112)
	end
end

----------------------------------
--
----------------------------------
function Return()
	Say(10113, 2, "�� chu�n b� xong./OnReturn", "�� ta xem l�i ��./OnCancel")
end

----------------------------------
--
----------------------------------
function OnReturn()
	if(return_main(5) ~= 0) then
		Talk(1,"",10114)
	end
end

----------------------------------
--
---------------------------------
function SkillHelp()
	skill_help(5)
end