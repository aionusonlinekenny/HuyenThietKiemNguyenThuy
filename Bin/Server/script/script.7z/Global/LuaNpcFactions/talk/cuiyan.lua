----------------------------------
--	Copyright: JX Online by Kinnox
--	Author: Kinnox
--	Date: 16/08/2014
--	Desc: Th�y Y�n Hoa S�
----------------------------------
Include("\\script\\Global\\LuaNpcFactions\\talk\\master_main.lua")
Include("\\script\\lib\\TaskLib.lua")

----------------------------------
-- H�m g�i ch�nh
----------------------------------
function main(nNpcIdx)
	local sPlayer_Faction = GetFaction()
	if(sPlayer_Faction == "") then
		Talk(1, "Enroll_Select", 10120)
	elseif(sPlayer_Faction == "cuiyan") then
		local sNpcName = format("<color=water>%s<color>:", GetNpcName(nNpcIdx))
		local sImage = "44/44/37"
		local n = GetTask(0)
		if(GetByte(n,1) == 0) then
			SayImage(""..sNpcName.." Phong c�nh th�y y�n th�t tuy�t ph�i kh�ng? S� mu�i c�n ta gi�p g� n�o?",sImage,4, "Ta mu�n xu�t s�./Leave", "T�m hi�u khu v�c luy�n c�ng./map_help","T�m hi�u v� ngh� b�n m�n./SkillHelp", "Nh�n ti�n gh� qua./OnCancel")
		else
			if(GetTongID() ~= 0) then
				if(GetTongFigure() < 3) then
					SayImage(""..sNpcName.." Bang h�i <color=green>"..GetTongName().."<color> c� s� gia nh�p c�a �� t� Th�y Y�n m�n nh� h� th�m c�nh! Ta n�i kh�ng sai ch�!",sImage,1, "�a t� s� t�./OnCancel")
				else
					SayImage(""..sNpcName.." Bang h�i <color=green>"..GetTongName().."<color> ���c l�nh ��o b�i k� nh�n Th�y Y�n th� c�n g� b�ng! Th�t l� vang danh thi�n h�! H�y cho b�n nam nh�n h�o s�c bi�t m�i!",sImage,1, "�a t� s� t�./OnCancel")
				end
			else
				SayImage(""..sNpcName.." Ti�u mu�i c� mu�n tr� v� n�i kh�ng! Ta th�t c� nhi�u chuy�n mu�n t�m s� c�ng mu�i!",sImage,2, "Quay v� Nga My ph�i./Return", "Nh�n ti�n gh� qua./OnCancel")
			end
		end
	elseif(sPlayer_Faction == "emei") then
		Talk(1, "", 10122)
	elseif(sPlayer_Faction == "tangmen") then
		Talk(1, "", 10123)
	elseif(sPlayer_Faction == "wudu") then
		Talk(1, "", 10124)
	elseif(sPlayer_Faction == "tianwang") then
		Talk(1, "", 10125)
	elseif(sPlayer_Faction == "shaolin") then
		Talk(1, "", 10126)
	elseif(sPlayer_Faction == "wudang") then
		Talk(1, "", 10127)
	elseif(sPlayer_Faction == "kunlun") then
		Talk(1, "", 10128)
	elseif(sPlayer_Faction == "tianren") then
		Talk(1, "", 10129)
	elseif(sPlayer_Faction == "gaibang") then
		if(GetSex() == 0) then
			Talk(2, "", 10130, 10132)
		else
			Talk(2, "", 10131, 10132)
		end
	end
end

----------------------------------
--
----------------------------------
function Enroll_Select()
	if(GetSeries() ~= 2) then
		return
	end
	if(GetLevel() < 10) then
		Talk(1,"",10005)
		return
	end
	if(GetCamp() ~= 0) then
		Talk(1,"", 10006)
		return
	end
	if(GetSex() ~= 1) then
		Talk(1,"", 10133)
		return
	end
	Say(10121, 2, "Ta mu�n gia nh�p./Go", "�� ta suy ngh� k� l�i xem./OnCancel")
end

----------------------------------
--
----------------------------------
function Go()
	if(join_main(6) ~= 0) then
		Talk(1,"",10134)
	end
end

----------------------------------
--
----------------------------------
function Leave()
	Say(10135, 2, "Xu�t s� xu�ng n�i./OnLeave", "�� ta xem l�i ��./OnCancel")
end

----------------------------------
--
----------------------------------
function OnLeave()
	if(leave_main(6) ~= 0) then
		Talk(1,"",10136)
	end
end

----------------------------------
--
----------------------------------
function Return()
	Say(10137, 2, "T�t nhi�n l� c�./OnReturn", "Qu�n mang theo r�i./OnCancel")
end

----------------------------------
--
----------------------------------
function OnReturn()
	if(return_main(6) ~= 0) then
		Talk(1,"",10138)
	end
end

----------------------------------
--
---------------------------------
function SkillHelp()
	skill_help(6)
end