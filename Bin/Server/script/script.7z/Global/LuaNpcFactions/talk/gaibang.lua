----------------------------------
--	Copyright: JX Online by Kinnox
--	Author: Kinnox
--	Date: 16/08/2014
--	Desc: �� T� C�i Bang
----------------------------------
Include("\\script\\Global\\LuaNpcFactions\\talk\\master_main.lua")

----------------------------------
--
----------------------------------
function main(nNpcIdx)
	local sPlayer_Faction = GetFaction()
	if(sPlayer_Faction == "") then
		Talk(1, "Enroll_Select", 10143)
	elseif(sPlayer_Faction == "gaibang") then
		local sNpcName = format("<color=fire>%s<color>:", GetNpcName(nNpcIdx))
		local sImage = "-85/-85/38"
		local n = GetTask(0)
		if(GetByte(n,1) == 0) then
			SayImage(""..sNpcName.." Huynh �� lang thang n�i ��y l�m g�? C� r��u ngon kh�ng ch�ng ta c�ng u�ng! Ha!Ha!",sImage,4, "Ta mu�n xu�t s�./Leave", "T�m hi�u khu v�c luy�n c�ng./map_help","T�m hi�u v� ngh� b�n m�n./SkillHelp", "Nh�n ti�n gh� qua./OnCancel")
		else
			if(GetTongID() ~= 0) then
				if(GetTongFigure() < 3) then
					SayImage(""..sNpcName.." Ng��i c�a b�n bang kh�p n�i! C� bang h�i <color=green>"..GetTongName().."<color> c�ng c�! R�t t�t! Haha",sImage,0)
				else
					SayImage(""..sNpcName.." Ng��i l�nh ��o bang h�i <color=green>"..GetTongName().."<color> th� c�ng ���c xem l� ph�n nh�nh c�a C�i Bang! Kh�ng ph�i ch�! Haha!",sImage,0)
				end
			else
				SayImage(""..sNpcName.." "..Faction.SexName[GetSex() + 1].." c� mu�n quay v� t�ng �� C�i Bang kh�ng? Ch�ng ta c�ng u�ng r��u lu�n tr�ng sao! Haha!",sImage,2, "Quay v� C�i Bang./Return", "Nh�n ti�n gh� qua./OnCancel")
			end
		end
	elseif(sPlayer_Faction == "emei") then
		Talk(1, "", 10147)
	elseif(sPlayer_Faction == "cuiyan") then
		Talk(1, "", 10146)
	elseif(sPlayer_Faction == "tangmen") then
		Talk(1, "", 10148)
	elseif(sPlayer_Faction == "wudu") then
		Talk(1, "", 10149)
	elseif(sPlayer_Faction == "tianwang") then
		Talk(1, "", 10150)
	elseif(sPlayer_Faction == "shaolin") then
		Talk(1, "", 10151)
	elseif(sPlayer_Faction == "wudang") then
		Talk(1, "", 10152)
	elseif(sPlayer_Faction == "kunlun") then
		Talk(1, "", 10153)
	elseif(sPlayer_Faction == "tianren") then
		Talk(1, "", 10154)
	end
end

----------------------------------
--
----------------------------------
function Enroll_Select()
	if(GetSeries() ~= 3) then
		return
	end
	if(GetLevel() < 10) then
		Talk(1,"",10005)
		return
	end
	if(GetCamp() ~= 0) then
		Talk(1,"", 10006)
		return
	end
	Say(10144, 2, "Ta mu�n gia nh�p./Go", "�� ta suy ngh� k� l�i xem./OnCancel")
end

----------------------------------
--
----------------------------------
function Go()
	if(join_main(7) ~= 0) then
		Talk(1,"",10145)
	end
end

----------------------------------
--
----------------------------------
function Leave()
	Say(10155, 2, "R�i kh�i t�ng ��./OnLeave", "�� ta xem l�i ��./OnCancel")
end

----------------------------------
--
----------------------------------
function OnLeave()
	if(leave_main(7) ~= 0) then
		Talk(1,"",10156)
	end
end

----------------------------------
--
----------------------------------
function Return()
	Say(10157, 2, "T�t nhi�n l� c�./OnReturn", "Qu�n mang theo r�i./OnCancel")
end

----------------------------------
--
----------------------------------
function OnReturn()
	if(return_main(7) ~= 0) then
		Talk(1,"",10158)
	end
end

----------------------------------
--
---------------------------------
function SkillHelp()
	skill_help(7)
end