----------------------------------
--	Copyright: JX Online by Kinnox
--	Author: Kinnox
--	Date: 16/08/2014
--	Desc: Thi�u L�m La H�n
----------------------------------
Include("\\script\\Global\\LuaNpcFactions\\talk\\master_main.lua")

----------------------------------
--
----------------------------------
function main(nNpcIdx)
	local sPlayer_Faction = GetFaction()
	if(sPlayer_Faction == "") then
		Talk(1, "Enroll_Select", 10004)
	elseif(sPlayer_Faction == "shaolin") then
		local sNpcName = format("<color=metal>%s<color>:", GetNpcName(nNpcIdx))
		local sImage = "44/44/32"
		local n = GetTask(0)
		if(GetByte(n,1) == 0) then
			SayImage(""..sNpcName.." S� ��! S� ph� l�i ph�i �� xu�ng n�i �?",sImage,4, "Xu�t s� xu�ng n�i./Leave", "T�m hi�u khu v�c luy�n c�ng./map_help","T�m hi�u v� ngh� b�n m�n./SkillHelp", "Xin thay ta v�n an s� ph�./OnCancel")
		else
			if(GetTongID() ~= 0) then
				if(GetTongFigure() < 3) then
					SayImage(""..sNpcName.." Ng��i �� gia nh�p bang h�i <color=green>"..GetTongName().."<color>! N�n nh� h�y th� hi�n cho t�t! ��ng l�m m�t m�t Thi�u L�m ch�ng ta!",sImage,1, "�a t� s� huynh./OnCancel")
				else
					SayImage(""..sNpcName.." Huynh �� �� th�nh l�p bang h�i <color=green>"..GetTongName().."<color> r�i �? Haha! Th�t kh�ng h� danh l� �� t� t�c gia c�a Thi�u L�m ch�ng ta!",sImage,1, "�a t� s� huynh./OnCancel")
				end
			else
				SayImage(""..sNpcName.." Huynh �� c� mu�n v� l�i m�n ph�i kh�ng?",sImage,2, "V� l�i Thi�u L�m ph�i./Return", "Xin thay ta v�n an s� ph�./OnCancel")
			end
		end
	elseif(sPlayer_Faction == "cuiyan") then
		Talk(1, "", 10010)
	elseif(sPlayer_Faction == "emei") then
		Talk(1, "", 10011)
	elseif(sPlayer_Faction == "tangmen") then
		Talk(1, "", 10012)
	elseif(sPlayer_Faction == "wudu") then
		Talk(1, "", 10013)
	elseif(sPlayer_Faction == "tianwang") then
		Talk(1, "", 10014)
	elseif(sPlayer_Faction == "wudang") then
		Talk(1, "", 10015)
	elseif(sPlayer_Faction == "kunlun") then
		Talk(1, "", 10016)
	elseif(sPlayer_Faction == "tianren") then
		Talk(1, "", 10017)
	elseif(sPlayer_Faction == "gaibang") then
		Talk(1, "", 10018)
	end
end

----------------------------------
--
----------------------------------
function Enroll_Select()
	if(GetSeries() ~= 0) then
		return
	end
	if(GetLevel() < 10) then
		Talk(1,"",10005)
		return
	end
	if(GetCamp() ~= 0) then
		Talk(1,"", 10006)
		return
	end
	if(GetSex() ~= 0) then
		Talk(1,"", 10008)
		return
	end
	Say(10009, 2, "Gia nh�p Thi�u L�m ph�i./Go", "�� ta suy ngh� k� l�i xem./OnCancel")
end

----------------------------------
--
----------------------------------
function Go()
	if(join_main(1) ~= 0) then
		Talk(1,"",10024)
	end
end

----------------------------------
--
----------------------------------
function Leave()
	Say(10019, 2, "Ta �� b�n l�nh./OnLeave", "�� ta xem l�i ��./OnCancel")
end

----------------------------------
--
----------------------------------
function OnLeave()
	if(leave_main(1) ~= 0) then
		Talk(1,"",10025)
	end
end

----------------------------------
--
----------------------------------
function Return()
	Say(10022, 2, "Ta mu�n quay v�./OnReturn", "�� ta xem l�i ��./OnCancel")
end

----------------------------------
--
----------------------------------
function OnReturn()
	if(return_main(1) ~= 0) then
		Talk(1,"",10026)
	end
end

----------------------------------
--
---------------------------------
function SkillHelp()
	skill_help(1)
end