----------------------------------
--	Copyright: JX Online by Kinnox
--	Author: Kinnox
--	Date: 16/08/2014
--	Desc: ���ng m�n th� v�
----------------------------------
Include("\\script\\Global\\LuaNpcFactions\\talk\\master_main.lua")

----------------------------------
--
----------------------------------
function main(nNpcIdx)
	local sPlayer_Faction = GetFaction()
	if(sPlayer_Faction == "") then
		Talk(2, "Enroll_Select", 10055, 10056)
	elseif(sPlayer_Faction == "tangmen") then
		local sNpcName = format("<color=wood>%s<color>:", GetNpcName(nNpcIdx))
		local sImage = "-85/-85/34"
		local n = GetTask(0)
		if(GetByte(n,1) == 0) then
			SayImage(""..sNpcName.." R�n luy�n k� n�ng �m s�t kh�ng ph�i m�t s�m m�t chi�u l� ���c! T�i sao ng��i kh�ng t�p luy�n m� l�i lang thang � ��y?",sImage,4, "Ta mu�n xu�t s�./Leave", "T�m hi�u khu v�c luy�n c�ng./map_help","T�m hi�u v� ngh� b�n m�n./SkillHelp", "Nh�n ti�n gh� qua./OnCancel")
		else
			if(GetTongID() ~= 0) then
				if(GetTongFigure() < 3) then
					SayImage(""..sNpcName.." Hy v�ng ng��i s� tr� th�nh m�t trong nh�ng s�t th� gi�i trong bang h�i <color=green>"..GetTongName().."<color>. L�m r�ng danh ���ng M�n ch�ng ta!",sImage,1, "�a t� s� huynh./OnCancel")
				else
					SayImage(""..sNpcName.." �� t� ���ng M�n l�nh ��o bang h�i <color=green>"..GetTongName().."<color> r�i ��y danh v�ng ���ng M�n l�i t�ng cao! Haha!",sImage,1, "�a t� s� huynh./OnCancel")
				end
			else
				SayImage(""..sNpcName.." K� n�ng c�a ng��i c� v� ch�a ho�n thi�n! C� mu�n quay v� r�n luy�n th�m kh�ng?",sImage,2, "Quay v� ���ng M�n./Return", "Nh�n ti�n gh� qua./OnCancel")
			end
		end
	elseif(sPlayer_Faction == "emei") then
		Talk(1, "", 10058)
	elseif(sPlayer_Faction == "cuiyan") then
		Talk(1, "", 10059)
	elseif(sPlayer_Faction == "tianwang") then
		Talk(1, "", 10061)
	elseif(sPlayer_Faction == "wudu") then
		Talk(1, "", 10060)
	elseif(sPlayer_Faction == "shaolin") then
		Talk(1, "", 10062)
	elseif(sPlayer_Faction == "wudang") then
		Talk(1, "", 10062)
	elseif(sPlayer_Faction == "kunlun") then
		Talk(1, "", 10063)
	elseif(sPlayer_Faction == "tianren") then
		Talk(1, "", 10064)
	elseif(sPlayer_Faction == "gaibang") then
		Talk(1, "", 10065)
	end
end

----------------------------------
--
----------------------------------
function Enroll_Select()
	if(GetSeries() ~= 1) then
		return
	end
	if(GetLevel() < 10) then
		Talk(1,"",10005)
		return
	end
	if(GetCamp() ~= 0) then
		Talk(1,"", 10006)
		return
	end
	Say(10057, 2, "Gia nh�p ���ng M�n./Go", "�� ta suy ngh� k� l�i xem./OnCancel")
end

----------------------------------
--
----------------------------------
function Go()
	if(join_main(3) ~= 0) then
		Talk(1,"",10066)
	end
end

----------------------------------
--
----------------------------------
function Leave()
	Say(10067, 2, "R�i kh�i m�n ph�i./OnLeave", "�� ta xem l�i ��./OnCancel")
end

----------------------------------
--
----------------------------------
function OnLeave()
	if(leave_main(3) ~= 0) then
		Talk(1,"",10068)
	end
end

----------------------------------
--
----------------------------------
function Return()
	Say(10069, 2, "Quay v� m�n ph�i./OnReturn", "�� ta xem l�i ��./OnCancel")
end

----------------------------------
--
----------------------------------
function OnReturn()
	if(return_main(3) ~= 0) then
		Talk(1,"",10070)
	end
end

----------------------------------
--
---------------------------------
function SkillHelp()
	skill_help(3)
end