----------------------------------
--	Copyright: JX Online by Kinnox
--	Author: Kinnox
--	Date: 16/08/2014
--	Desc: Thi�n V��ng T��ng L�nh
----------------------------------
Include("\\script\\Global\\LuaNpcFactions\\talk\\master_main.lua")

TianWangNpc = {}
----------------------------------
-- Ki�m tra nhi�m v� t�n th� th�n
----------------------------------
function TianWangNpc:OnCheckCountryTask(nWorldID)
	-- Nh�n v�t �ang ��ng � Ba L�ng Huy�n
	if(nW == 53) then
		-- Ki�m tra nhi�m v� mua T� B� Ho�n
		local n = GetTask(4)
		if( (GetByte(n,1) == 2) and (HaveEventItem(180) == 0) ) then
			Talk(1,"",10275)
			AddEventItem(180)
			local sStr = "B�n nh�n ���c m�t vi�n <color=green>T� B� Ho�n<color>."
			Msg2Player("Nhi�m V�",sStr) 
			AddNote(sStr) 
			return 1
		end
	end
	return 0
end

----------------------------------
-- H�m g�i ch�nh
----------------------------------
function main(nNpcIdx)
	local nW,_,_ = GetWorldPos()
	if(TianWangNpc:OnCheckCountryTask(nW) == 1) then
		return
	end
	local sPlayer_Faction = GetFaction()
	if(sPlayer_Faction == "") then
		Talk(3, "Enroll_Select", 10032, 10033, 10034)
	elseif(sPlayer_Faction == "tianwang") then
		local sNpcName = format("<color=metal>%s<color>:", GetNpcName(nNpcIdx))
		local sImage = "44/44/33"
		local n = GetTask(0)
		if(GetByte(n,1) == 0) then
			SayImage(""..sNpcName.." Ng��i kh�ng lo luy�n c�ng ti�n c�p m� t�m ta c� vi�c g�?",sImage,4, "Xu�t s� r�i kh�i ��o./Leave", "T�m hi�u khu v�c luy�n c�ng./map_help","T�m hi�u v� ngh� b�n bang./SkillHelp", "Nh�n ti�n gh� qua./OnCancel")
		else
			if(GetTongID() ~= 0) then
				if(GetTongFigure() < 3) then
					SayImage(""..sNpcName.." Gia nh�p bang h�i <color=green>"..GetTongName().."<color> nh�ng c�ng ��ng qu�n trau d�i v� c�ng b�n bang! Kim Qu�c �ang l�m le b� c�i Trung Nguy�n cho n�n sau n�y s� c� vi�c nh� ng��i gi�p s�c.",sImage,1, "�a t� s� huynh./OnCancel")
				else
					SayImage(""..sNpcName.." L�nh ��o bang h�i <color=green>"..GetTongName().."<color> th�t kh�ng ph�i l� chuy�n d�! Haha! Danh v�ng Thi�n V��ng bang r�i ��y s� t�ng m�nh!",sImage,1, "�a t� s� huynh./OnCancel")
				end
			else
				SayImage(""..sNpcName.." Ng��i c� mu�n quay v� ��o �� trau d�i v� h�c kh�ng?",sImage,2, "Quay v� Thi�n V��ng Bang./Return", "Nh�n ti�n gh� qua./OnCancel")
			end
		end
	elseif(sPlayer_Faction == "emei") then
		Talk(1, "", 10035)
	elseif(sPlayer_Faction == "cuiyan") then
		Talk(1, "", 10036)
	elseif(sPlayer_Faction == "tangmen") then
		Talk(1, "", 10037)
	elseif(sPlayer_Faction == "wudu") then
		Talk(1, "", 10038)
	elseif(sPlayer_Faction == "shaolin") then
		Talk(1, "", 10039)
	elseif(sPlayer_Faction == "wudang") then
		Talk(1, "", 10040)
	elseif(sPlayer_Faction == "kunlun") then
		Talk(1, "", 10041)
	elseif(sPlayer_Faction == "tianren") then
		Talk(1, "", 10042)
	elseif(sPlayer_Faction == "gaibang") then
		Talk(1, "", 10043)
	end
end

----------------------------------
-- Ki�m tra gia nh�p ph�i
----------------------------------
function Enroll_Select()
	if(GetSeries() ~= 0) then
		return
	end
	if(GetLevel() < 10) then
		Talk(1,"",10005)
		return
	end
	if(GetCamp() ~= 0) then
		Talk(1,"", 10006)
		return
	end
	Say(10049, 2, "Gia nh�p Thi�n V��ng Bang./Go", "�� ta suy ngh� k� l�i xem./OnCancel")
end

----------------------------------
--
----------------------------------
function Go()
	if(join_main(2) ~= 0) then
		Talk(1,"",10048)
	end
end

----------------------------------
--
----------------------------------
function Leave()
	Say(10044, 2, "Ta mu�n r�i kh�i ��o./OnLeave", "�� ta xem l�i ��./OnCancel")
end

----------------------------------
--
----------------------------------
function OnLeave()
	if(leave_main(2) ~= 0) then
		Talk(1,"",10045)
	end
end

----------------------------------
--
----------------------------------
function Return()
	Say(10046, 2, "��a ta tr� l�i ��o./OnReturn", "�� ta xem l�i ��./OnCancel")
end

----------------------------------
--
----------------------------------
function OnReturn()
	if(return_main(2) ~= 0) then
		Talk(1,"",10047)
	end
end

----------------------------------
--
---------------------------------
function SkillHelp()
	skill_help(2)
end