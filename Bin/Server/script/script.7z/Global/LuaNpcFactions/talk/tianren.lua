----------------------------------
--	Copyright: JX Online by Kinnox
--	Author: Kinnox
--	Date: 16/08/2014
--	Desc: Thi�n Nh�n T� S�
----------------------------------
Include("\\script\\Global\\LuaNpcFactions\\talk\\master_main.lua")

----------------------------------
--
----------------------------------
function main(nNpcIdx)
	local sPlayer_Faction = GetFaction()
	if(sPlayer_Faction == "") then
		Talk(1, "Enroll_Select", 10163)
	elseif(sPlayer_Faction == "tianren") then
		local sNpcName = format("<color=fire>%s<color>:", GetNpcName(nNpcIdx))
		local sImage = "44/44/39"
		local n = GetTask(0)
		if(GetByte(n,1) == 0) then
			SayImage(""..sNpcName.." Ng��i kh�ng lo luy�n t�p n�ng cao k� n�ng m� lang thang n�i n�y l�m g�?",sImage,4, "Ta mu�n xu�t s�./Leave", "T�m hi�u khu v�c luy�n c�ng./map_help","T�m hi�u v� ngh� b�n m�n./SkillHelp", "Nh�n ti�n gh� qua./OnCancel")
		else
			if(GetTongID() ~= 0) then
				if(GetTongFigure() < 3) then
					SayImage(""..sNpcName.." Haha! Gia nh�p bang h�i <color=green>"..GetTongName().."<color> r�i sao! R�t t�t, v� l�m Trung Nguy�n s�m mu�n g� c�ng r�i v�o tay ch�ng ta! Ha!Ha!Ha",sImage,0)
				else
					SayImage(""..sNpcName.." Th�nh l�p bang h�i <color=green>"..GetTongName().."<color> nh�ng h�y nh� l� t��ng v� s� nghi�p t��ng lai c�a Thi�n Nh�n gi�o ch�ng ta! Ha!Ha!Ha",sImage,0)
				end
			else
				SayImage(""..sNpcName.." Nghe n�i ng��i sau khi xu�t s� �� l�p n�n nhi�u c�ng danh! Qu� kh�ng h� danh l� �� t� c�a b�n gi�o!",sImage,2, "Quay v� Thi�n Nh�n gi�o./Return", "Nh�n ti�n gh� qua./OnCancel")
			end
		end
	elseif(sPlayer_Faction == "emei") then
		Talk(1, "", 10166)
	elseif(sPlayer_Faction == "cuiyan") then
		Talk(1, "", 10167)
	elseif(sPlayer_Faction == "tangmen") then
		Talk(1, "", 10168)
	elseif(sPlayer_Faction == "wudu") then
		Talk(1, "", 10169)
	elseif(sPlayer_Faction == "tianwang") then
		Talk(1, "", 10170)
	elseif(sPlayer_Faction == "shaolin") then
		Talk(1, "", 10171)
	elseif(sPlayer_Faction == "wudang") then
		Talk(1, "", 10172)
	elseif(sPlayer_Faction == "kunlun") then
		Talk(1, "", 10173)
	elseif(sPlayer_Faction == "gaibang") then
		Talk(1, "", 10174)
	end
end

----------------------------------
--
----------------------------------
function Enroll_Select()
	if(GetSeries() ~= 3) then
		return
	end
	if(GetLevel() < 10) then
		Talk(1,"",10005)
		return
	end
	if(GetCamp() ~= 0) then
		Talk(1,"", 10006)
		return
	end
	Say(10164, 2, "Ta mu�n gia nh�p./Go", "�� ta suy ngh� k� l�i xem./OnCancel")
end

----------------------------------
--
----------------------------------
function Go()
	if(join_main(8) ~= 0) then
		Talk(1,"",10165)
	end
end

----------------------------------
--
----------------------------------
function Leave()
	Say(10175, 2, "Ta ��ng �./OnLeave", "�� ta xem l�i ��./OnCancel")
end

----------------------------------
--
----------------------------------
function OnLeave()
	if(leave_main(8) ~= 0) then
		Talk(1,"",10176)
	end
end

----------------------------------
--
----------------------------------
function Return()
	Say(10177, 2, "T�t nhi�n l� c�./OnReturn", "Qu�n mang theo r�i./OnCancel")
end

----------------------------------
--
----------------------------------
function OnReturn()
	if(return_main(8) ~= 0) then
		Talk(1,"",10178)
	end
end

----------------------------------
--
---------------------------------
function SkillHelp()
	skill_help(8)
end