----------------------------------
--	Copyright: JX Online by Kinnox
--	Author: Kinnox
--	Date: 16/08/2014
--	Desc: M�n ph�i 
----------------------------------
Include("\\script\\Global\\LuaNpcFactions\\faction_head.lua")
Include("\\script\\Global\\LuaNpcFactions\\faction_help.lua")

----------------------------------
-- Gia nh�p m�n ph�i
----------------------------------
function join_main(nFactionId)
	return Faction:JoinFaction(nFactionId)
end

----------------------------------
-- Xu�t s� kh�i ph�i
----------------------------------
function leave_main(nFactionId)
	return Faction:LeaveFaction(nFactionId)
end

----------------------------------
-- Quay v� m�n ph�i
----------------------------------
function return_main(nFactionId)
	return Faction:ReturnFaction(nFactionId)
end

----------------------------------
-- T�m hi�u khu v�c luy�n c�ng
----------------------------------
function map_help()
	FHelp:Map()
end

----------------------------------
-- T�m hi�u v� c�ng
----------------------------------
function skill_help(nFactionId)
	FHelp:Skill(nFactionId)
end
