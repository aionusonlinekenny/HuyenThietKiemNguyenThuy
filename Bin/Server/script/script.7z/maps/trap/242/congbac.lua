-- Author:	SkyGold
-- Date:	15-04-2016
-- C�ng B�c Bi�n Kinh


function main()
	if(GetFightState() == 0) then
		SetPos(1653, 3169)
		SetFightState(1)
	else	
		SetPos(1645, 3181)	
		SetFightState(0)
	end;
	-- AddStation(10)
	-- SetProtectTime(18*3)
	AddSkillState(963, 1, 0, 18*3)
end