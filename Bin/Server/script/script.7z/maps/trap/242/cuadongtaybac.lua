-- Author:	SkyGold
-- Date:	15-04-2016
-- C�ng B�c Bi�n Kinh


function main()
	Say("Trap 1", 0)
end