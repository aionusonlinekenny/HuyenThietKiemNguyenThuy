--Author: Kinnox;
--Date: 17/04/2022;
Include("\\script\\mission\\loanchien\\head.lua");
function OnTimer()
	LC:TIMER_LANGDING(); -- 20 seccon call function;
end