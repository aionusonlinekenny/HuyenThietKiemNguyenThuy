--Author: Kinnox;
--Date: 16/05/2022;
--function: loan chien;
Include("\\script\\mission\\loanchien\\head.lua");
function main(nNpcIndex)
	LC:NpcTalk(PlayerIndex);
end;