--Author: Kinnox;
--Date: 16/05/2022;
--function: death_player;
Include("\\script\\mission\\loanchien\\head.lua");
function OnLogout(nLauncher,nAttacker)
	--mutil ben thuyen;
	local OldSubWorld = SubWorld;
	local OldPlayerIndex = PlayerIndex;
		PlayerIndex = nLauncher;
	Msg2MSAll(LC.MAIN.MISSION_LC, " "..GetName().." ��i hi�p kh�ng �� b�n l�nh b� n�n �� b� ch�y.");
	LC:LeaveGame(PlayerIndex,1);
	PlayerIndex = OldPlayerIndex;
	SubWorld = OldSubWorld;
end