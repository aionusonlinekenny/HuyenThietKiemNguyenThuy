--Author: Kinnox;
--Date: 17/04/2022;
Include("\\script\\mission\\phonglangdo\\head.lua");
function OnLogout(nLauncher,nAttacker)
	--mutil ben thuyen;
	local OldSubWorld = SubWorld;
	local OldPlayerIndex = PlayerIndex;
		PlayerIndex = nLauncher;
	Msg2MSAll(PLD.MAIN.MISSION_PLD, " "..GetName().." ��i hi�p kh�ng �� b�n l�nh quy�t ��nh r�i thuy�n.");
	PLD:LeaveGame(PlayerIndex,1);
	PlayerIndex = OldPlayerIndex;
	SubWorld = OldSubWorld;
end