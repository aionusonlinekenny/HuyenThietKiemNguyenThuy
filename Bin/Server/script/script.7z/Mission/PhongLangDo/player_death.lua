--Author: Kinnox;
--Date: 17/04/2022;
Include("\\script\\mission\\phonglangdo\\head.lua");
function OnDeath(nLauncher,nAttacker)
	--mutil ben thuyen;
	local OldSubWorld = SubWorld;
	local OldPlayerIndex = PlayerIndex;
		PlayerIndex = nLauncher;
	Msg2MSAll(PLD.MAIN.MISSION_PLD, " "..GetName().." ��i hi�p kh�ng may t� vong khi �ang �i thuy�n.");
	PLD:LeaveGame(PlayerIndex,2);
	PlayerIndex = OldPlayerIndex;
	SubWorld = OldSubWorld;
end