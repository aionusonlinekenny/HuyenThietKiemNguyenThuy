--Author: Kinnox;
--Date: 17/04/2022;
Include("\\script\\mission\\phonglangdo\\head.lua");
function OnTimer()
	PLD:TIMER_LANGDING(); -- 20 seccon call function;
end