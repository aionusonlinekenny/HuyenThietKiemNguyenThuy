----------------------------------
--	Copyright: JX Online by Kinnox
--	Author: Kinnox;
--	Date: 11/11/2021
--	Desc: C�a doanh tr�i v�o h�u ph��ng T�ng Kim (phe T�ng)
----------------------------------
Include("\\script\\mission\\battles\\head.lua")

----------------------------------
--
----------------------------------
function main()
	if(GetCurCamp() == 1) then
		SetPos(GetMissionV(ZBattle.tbMission.HOMEIN_X1), GetMissionV(ZBattle.tbMission.HOMEIN_Y1))
		SetFightState(0)
		SetTaskTemp(ZBattle.tbTaskTmp.LAST_DEATH, GetGameTime())
	elseif (GetCurCamp() == 2) then
		Msg2Player("<color=orangered><color=yellow>Kim binh<color> sao c� th� l�t v�o doanh tr�i <color=lightsalmon>T�ng<color>.")
		SetFightState(1)
	end
end