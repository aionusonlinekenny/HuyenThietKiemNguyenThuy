----------------------------------
--	Copyright: JX Online by Kinnox
--	Author: Kinnox;
--	Date: 11/11/2021
--	Desc: Hi�u �y T�ng Kim ch�t
----------------------------------
nRank = 2
Include("\\script\\mission\\battles\\npcdeath.lua")