----------------------------------
--	Copyright: JX Online by Kinnox
--	Author: Kinnox;
--	Date: 11/11/2021
--	Desc: Kim M� Binh
----------------------------------
Include("\\script\\mission\\battles\\functions.lua")
Include("\\script\\system_config.lua")
----------------------------------
--
----------------------------------
function main()
	if (SYS_SWITCH_BATTLES == 0) then
		Talk(1,"","T�nh n�ng n�y hi�n ch�a khai m�!");
		return
	end;
	local nOldSubWorld = SubWorld
	SubWorld = SubWorldID2Idx(ZBattle.FIGHT_MAP)
	if(GetMissionV(ZBattle.tbMission.STATE) == 0) then
		Talk(1,"MoreInfo","Qu�n ��i hi�n nay ch�a t�p trung v�o chi�n tr��ng, trong l�c ch� ��i ng��i h�y �i luy�n t�p th�m.")
		SubWorld = nOldSubWorld	
		return
	end
	
	if(GetLevel() < 80 ) then
		Say("Ta r�t ti�c, chi�n tr��ng T�ng Kim ��i h�i c�p �� ph�i ��t <color=red> 80 tr� l�n<color>. ��ng c�p hi�n t�i c�a ng��i qu� th�p, h�y �i luy�n t�p th�m!",2, "Ta bi�t r�i./OnCancel", "Ta mu�n bi�t th�m th�ng tin./MoreInfo");
		SubWorld = nOldSubWorld	
		return
	end

	local nSongCount = GetMSPlayerCount(ZBattle.tbMission.MAIN, 1)
	local nJinCount = GetMSPlayerCount(ZBattle.tbMission.MAIN, 2)
	Say("Chi�n tr��ng �� b�t ��u! Hi�n t�i b�n <color=plum>Kim: "..nJinCount.."<color> ng��i, b�n <color=sbrown>T�ng: "..nSongCount.."<color> ng��i, ng��i c� mu�n gia nh�p qu�n ��i �� ph�c v� ��t n��c kh�ng?", 3,
			"Gia nh�p qu�n ��i./CheckCondition",
			"T�m hi�u th�ng tin./MoreInfo",
			"�� ta xem x�t lai./OnCancel")
	SubWorld = nOldSubWorld	
end

----------------------------------
-- 
----------------------------------
function CheckCondition()
	local nOldSubWorld = SubWorld;
	local bFlag = 0;
	SubWorld = SubWorldID2Idx(ZBattle.FIGHT_MAP)
	if(GetMissionV(ZBattle.tbMission.STATE) >= 2) then
		bFlag = 1;
	end;
	SubWorld = nOldSubWorld;
	-- Ki�m tra phe �� v�o
	nCamp = 2;
	if(bFlag == 1) then
		local nResult = ZBattle:CheckLastGroup(nCamp)
		if((nResult ~= 0) and (nResult ~= nCamp) ) then
			if (nCamp == 1) then
				Talk(1,"","B�n ng��i l� ng��i Kim x�m ph�m giang s�n ta. Ta th� c�ng ng��i ��ng quy � t�n!")
			else
				Talk(1,"","Kim qu�c ai c�ng thi�n chi�n. B�n ng��i sao c� th� ch�ng l�i ch�ng ta!")
			end
			return
		end
	end;
	-- TimeBox("�ang ki�m tra",random(10,15),"ExeAnti",0);
	-- AntiSongJin(0,2); -- 0/1 : WriteData/ClearData; || 2 : Group Jin
	JoinJin()
end;
function ExeAnti()
	AntiSongJin(0,1); -- 0/1 : WriteData/ClearData; || 1 : Group Song
end;
----------------------------------
-- 
----------------------------------
function JoinJin()
	local nOldSubWorld = SubWorld
	SubWorld = SubWorldID2Idx(ZBattle.FIGHT_MAP)
	JoinMission(ZBattle.tbMission.MAIN,2)
end

----------------------------------
-- 
----------------------------------
function MoreInfo()
	ZBattle:Info()
end

----------------------------------
-- 
----------------------------------
function OnCancel()
end