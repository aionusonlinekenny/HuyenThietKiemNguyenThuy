----------------------------------
--	Copyright: JX Online by Kinnox
--	Author: Kinnox
--	Date: 12/03/2023
--	Desc: Timer T�ng Kim 1
----------------------------------
Include("\\script\\mission\\battles\\head.lua")
----------------------------
-- H�m ch�nh
----------------------------
function OnTimer()
	-- L�y th�i gian
	local nT = GetMissionV(ZBattle.tbMission.TIMER) + 1
	SetMissionV(ZBattle.tbMission.TIMER, nT);
	-- ��n gi� khai chi�n
	if(nT == ZBattle.RUNGAME_TIME) then
		RunMission(ZBattle.tbMission.MAIN)
		AddGlobalCountNews("Chi�n tr��ng t�ng kim h�nh th�c "..ZBattle.tbRuleName[GetMissionV(ZBattle.tbMission.MAIN)].." �� b�t ��u. H�y mau t�i chi�n tr��ng b�o danh!", 2)
		Msg2SubWorld("T�ng kim �� ch�nh th�c khai chi�n!")
	end
	-- �ang trong th�i gian b�o danh
	if( (nT < ZBattle.RUNGAME_TIME) and (mod(nT, 18) == 0) ) then
		local nRestTime = (ZBattle.RUNGAME_TIME - nT) * ZBattle.TIMER_1 / ZBattle.FRAME2TIME
		local nRestMin,_ = ZBattle:GetMinAndSec(nRestTime)
		AddGlobalCountNews("Chi�n tr��ng t�ng kim h�nh th�c "..ZBattle.tbRuleName[GetMissionV(ZBattle.tbMission.MAIN)].." �� b�t ��u chi�u m�. Th�i gian b�o danh c�n l�i l�: <color=green>"..nRestMin.." ph�t<color>.", 2);
		Msg2SubWorld("Th�i gian b�o danh c�n l�i l�: <color=green>"..nRestMin.." ph�t<color>.")
	end
	-- �ang chi�n ��u
	if(nT >= ZBattle.RUNGAME_TIME) then
		if(nT == ZBattle.RUNGAME_TIME) then
			-- G�i l�nh T�ng Kim
			if(GetMissionV(ZBattle.tbMission.MAIN) >= 2) then
				ZBattle:BuildFightNpcData()
			end
		else
			-- T�nh th�i gian g�i nguy�n so�i
			if(GetMissionV(ZBattle.tbMission.MAIN) == 2) then
				-- T�i gi� g�i nguy�n so�i
				if(nT == ZBattle.MARSHALL_TIME) then
					if(GetMissionV(ZBattle.tbMission.SONGPOINT) < GetMissionV(ZBattle.tbMission.JINPOINT)) then
						ZBattle:CallMarshal(1)
						SetMissionV(ZBattle.tbMission.MARSHAL, 1)
					elseif(GetMissionV(ZBattle.tbMission.SONGPOINT) > GetMissionV(ZBattle.tbMission.JINPOINT)) then
						ZBattle:CallMarshal(2)
						SetMissionV(ZBattle.tbMission.MARSHAL, 2)
					elseif(GetMissionV(ZBattle.tbMission.SONGPOINT) == GetMissionV(ZBattle.tbMission.JINPOINT)) then
						ZBattle:CallMarshal(2)
						ZBattle:CallMarshal(1)
						SetMissionV(ZBattle.tbMission.MARSHAL, 3)
					end
				end
				-- G�i nguy�n so�i c�a b�n c�n l�i
				if (nT == ZBattle.VANISHGAME_TIME) then
					local nMar = GetMissionV(ZBattle.tbMission.MARSHAL)
					if(nMar == 1) then
						ZBattle:CallMarshal(2)
					elseif(nMar == 2) then
						ZBattle:CallMarshal(1)
					end
				end
			end
			-- Check AFK
			ZBattle:Pop2SignMap()
			-- C�p nh�t b�ng x�p h�ng v� th�ng b�o �i�m
			if(mod(nT, 3) == 0 ) then
				if(GetMissionV(ZBattle.tbMission.MAIN) >= 2) then
					ZBattle:CallFightNpc(nT - ZBattle.RUNGAME_TIME, ZBattle.VANISHGAME_TIME - ZBattle.RUNGAME_TIME)
					local nCountTime = GetMissionV(ZBattle.tbMission.TIMERCOUNT) + 1;
					SetMissionV(ZBattle.tbMission.TIMERCOUNT,nCountTime);
					SetGlbMissionV(ZBattle.tbMission.TIMERSHOW,(45 - GetMissionV(ZBattle.tbMission.TIMERCOUNT)));
				end
				local nCount = GetMissionV(ZBattle.tbMission.MEMBER_COUNT)
				Msg2MSAll(ZBattle.tbMission.MAIN,"Th�ng b�o: �i�m t�ch l�y gi�a 2 phe l� <color=sbrown>T�ng: "..GetMissionV(ZBattle.tbMission.SONGPOINT).."<color>:<color=plum>Kim "..GetMissionV(ZBattle.tbMission.JINPOINT).."<color>.")
			end
		end
	end
end

----------------------------------
--
----------------------------------
function ZBattle:BuildFightNpcData()
	local mapfile = GetMapInfoFile(self.FIGHT_MAP)	
	local s_area = GetMissionV(self.tbMission.AREASONG)
	local j_area = GetMissionV(self.tbMission.AREAJIN)
	local area_section1 = "Area_"..s_area
	local area_section2 = "Area_"..j_area
	local npcfile = ""
	npcfile = self:GetIniFileData(mapfile, area_section1, self.tbSecNpcPos[2])
	self:Add_Rand_FightNpc(npcfile, self.NpcSoliderId[1][1], 90, 1, self.tbNpcSoliderCount[1], self.tbFileNpcDeath[1],0,"",0,0)
	
	npcfile = self:GetIniFileData(mapfile, area_section2, self.tbSecNpcPos[2])
	self:Add_Rand_FightNpc(npcfile, self.NpcSoliderId[2][1], 90, 2, self.tbNpcSoliderCount[1], self.tbFileNpcDeath[1],0,"",0,0)
end

----------------------------------
--
----------------------------------
function ZBattle:CallFightNpc(nUseTime, nTotalTime)
	if (nUseTime > nTotalTime) then
		return
	end
	
	local mapfile = GetMapInfoFile(self.FIGHT_MAP)	
	local s_area = GetMissionV(self.tbMission.AREASONG)
	local j_area = GetMissionV(self.tbMission.AREAJIN)
	local area_section1 = "Area_"..s_area
	local area_section2 = "Area_"..j_area
	
	local i, nPreNpcCount, nNpcCount, nNowAdd, npcfile = 0,0,0,0,"";
	for i = 2, 5 do 
		nPreNpcCount = floor((nUseTime - 1) / nTotalTime * self.tbNpcSoliderCount[i])
		nNpcCount = floor(nUseTime / nTotalTime * self.tbNpcSoliderCount[i])
		nNowAdd = nNpcCount - nPreNpcCount
		if(nNowAdd > 0) then
			-- print("call song npc count= "..nNowAdd.." rank="..i)
			npcfile = self:GetIniFileData(mapfile, area_section1, self.tbSecNpcPos[random(2)])
			self:Add_Rand_FightNpc(npcfile, self.NpcSoliderId[1][i], 90, 1, nNowAdd, self.tbFileNpcDeath[i], 1,"",0,0)
		end
	end
	
	for i = 2, 5 do 
		nPreNpcCount = floor((nUseTime - 1) / nTotalTime * self.tbNpcSoliderCount[i])
		nNpcCount = floor(nUseTime / nTotalTime * self.tbNpcSoliderCount[i])
		nNowAdd = nNpcCount - nPreNpcCount
		if(nNowAdd > 0) then
			-- print("call jin npc count= "..nNowAdd.." rank="..i)
			npcfile = self:GetIniFileData(mapfile, area_section2, self.tbSecNpcPos[random(2)]);
			self:Add_Rand_FightNpc(npcfile, self.NpcSoliderId[2][i], 90, 2, nNowAdd, self.tbFileNpcDeath[i],1,"",0,0)
		end
	end
end

----------------------------------
--
----------------------------------
function ZBattle:CallMarshal(nCamp)
	local mapfile = GetMapInfoFile(self.FIGHT_MAP)	
	local s_area = GetMissionV(self.tbMission.AREASONG)
	local j_area = GetMissionV(self.tbMission.AREAJIN)
	local area_section1 = "Area_"..s_area
	local area_section2 = "Area_"..j_area
	if(nCamp == 1) then
		local enterpos = self:GetIniFileData(mapfile, area_section1, "generalpos");
		local x,y = self:Str2XYData(enterpos)	
		local npcidx_s = AddNpc(self.NpcSoliderId[1][6], 90, SubWorld, x*32, y*32, 1, "T�ng Nguy�n So�i", 0,0)
		SetNpcCurCamp(npcidx_s, 1)
		SetNpcScript(npcidx_s, self.tbFileNpcDeath[6])
		Msg2MSAll(self.tbMission.MAIN, "Chi�n tr��ng th�ng b�o: <color=sbrown>Nguy�n so�i phe t�ng �� xu�t hi�n<color>.")
	else
		local enterpos = self:GetIniFileData(mapfile, area_section2, "generalpos");
		local x,y = self:Str2XYData(enterpos)	
		local npcidx_j = AddNpc(self.NpcSoliderId[2][6], 90, SubWorld, x*32, y*32, 1, "Kim Nguy�n So�i", 0,0)
		SetNpcCurCamp(npcidx_j, 2)
		SetNpcScript(npcidx_j, self.tbFileNpcDeath[6])
		Msg2MSAll(self.tbMission.MAIN, "Chi�n tr��ng th�ng b�o: <color=plum>Nguy�n so�i phe kim �� xu�t hi�n<color>.")
	end		
end