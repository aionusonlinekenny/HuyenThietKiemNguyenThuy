----------------------------------
--	Copyright: JX Online by Kinnox
--	Author: Kinnox;
--	Date: 11/11/2021
--	Desc: Th�ng L�nh T�ng Kim ch�t
----------------------------------
nRank = 3
Include("\\script\\mission\\battles\\npcdeath.lua")