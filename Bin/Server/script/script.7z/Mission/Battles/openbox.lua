----------------------------------
--	Copyright: JX Online by Kinnox
--	Author: Kinnox;
--	Date: 11/11/2021
--	Desc: R��ng ch�a �� T�ng Kim
----------------------------------

----------------------------------
-- H�m g�i ch�nh
----------------------------------
function main(nNpcIdx)
	OpenBox()
end