----------------------------------
--	Copyright: JX Online by Kinnox
--	Author: Kinnox;
--	Date: 11/11/2021
--	Desc: Qu�i T�ng Kim ch�t
----------------------------------
Include("\\script\\mission\\battles\\functions.lua")

ITEM_DROPRATE_TABLE = { 
	{ { 7,81,1,1,-1,0 }, { 0.003,0.0200,0.0520,0.0400,0.0500,0.0600 } },	-- Chi�n c� 
	{ { 7,82,1,1,-1,0 }, { 0.003,0.0200,0.0520,0.0400,0.0500,0.0600 } },	-- L�nh b�i
	{ { 7,83,1,1,-1,0 }, { 0.003,0.0200,0.0300,0.0400,0.0500,0.0600 } },	-- Binh S� hi�u ph� 
	{ { 7,85,1,1,-1,0 }, { 0.002,0.0200,0.0180,0.0160,0.0376,0.0360 } },	-- Kim Chi Chi�n H�n 
	{ { 7,86,1,1,-1,0 }, { 0.002,0.0200,0.0180,0.0160,0.0376,0.0360 } },	-- M�c Chi Chi�n H�n 
	{ { 7,87,1,1,-1,0 }, { 0.002,0.0200,0.0180,0.0160,0.0376,0.0360 } },	-- Th�y Chi Chi�n H�n 
	{ { 7,88,1,1,-1,0 }, { 0.002,0.0200,0.0180,0.0160,0.0376,0.0360 } },	-- H�a Chi Chi�n H�n 
	{ { 7,89,1,1,-1,0 }, { 0.002,0.0200,0.0180,0.0160,0.0376,0.0360 } },	-- Th� Chi Chi�n H�n 
	{ { 7,90,1,1,-1,0 }, { 0.002,0.0200,0.0180,0.0160,0.0376,0.0120 } },	-- Kim Chi H� gi�p  
	{ { 7,91,1,1,-1,0 }, { 0.002,0.0200,0.0180,0.0160,0.0376,0.0120 } },	-- M�c Chi H� gi�p  
	{ { 7,92,1,1,-1,0 }, { 0.002,0.0200,0.0180,0.0160,0.0376,0.0120 } },	-- Th�y Chi H� gi�p  
	{ { 7,93,1,1,-1,0 }, { 0.002,0.0200,0.0180,0.0160,0.0376,0.0120 } },	-- H�a Chi H� gi�p  
	{ { 7,94,1,1,-1,0 }, { 0.002,0.0200,0.0180,0.0160,0.0376,0.0120 } },	-- Th� Chi H� gi�p  
	{ { 7,95,1,1,-1,0 }, { 0.002,0.0360,0.0180,0.0390,0.0140,0.0360 } },	-- Kim Chi L�i Nh�n
	{ { 7,96,1,1,-1,0 }, { 0.002,0.0360,0.0180,0.0390,0.0140,0.0360 } },	-- M�c Chi L�i Nh�n
	{ { 7,97,1,1,-1,0 }, { 0.002,0.0360,0.0180,0.0390,0.0140,0.0360 } },	-- Th�y Chi L�i Nh�n
	{ { 7,98,1,1,-1,0 }, { 0.002,0.0360,0.0180,0.0390,0.0140,0.0360 } },	-- H�a Chi L�i Nh�n
	{ { 7,99,1,1,-1,0 }, { 0.002,0.0360,0.0180,0.0390,0.0140,0.0360 } },	-- Th� Chi L�i Nh�n
	{ { 7,100,1,1,-1,0 }, { 0.002,0.0200,0.0400,0.0390,0.0140,0.0120 } },	-- H�nh qu�n ��n 
	{ { 7,101,1,1,-1,0 }, { 0.002,0.0200,0.0400,0.0390,0.0140,0.0120 } },	-- Ti�u ho�n ��n 
	{ { 7,102,1,1,-1,0 }, { 0.002,0.0200,0.0400,0.0390,0.0140,0.0120 } },	-- Ng� Hoa L� 
	{ { 7,103,1,1,-1,0 }, { 0.002,0.0200,0.0180,0.0160,0.0140,0.0120 } },	-- Phong V�n Ngo�i Ph� ho�n
	{ { 7,104,1,1,-1,0 }, { 0.002,0.0200,0.0180,0.0160,0.0140,0.0120 } },	-- Phong V�n Ngo�i ��c ho�n
	{ { 7,105,1,1,-1,0 }, { 0.002,0.0200,0.0180,0.0160,0.0140,0.0120 } },	-- Phong V�n Ngo�i B�ng ho�n
	{ { 7,106,1,1,-1,0 }, { 0.002,0.0200,0.0180,0.0160,0.0140,0.0120 } },	-- Phong V�n N�i Ph� ho�n
	{ { 7,107,1,1,-1,0 }, { 0.002,0.0200,0.0180,0.0160,0.0140,0.0120 } },	-- Phong V�n N�i ��c ho�n
	{ { 7,108,1,1,-1,0 }, { 0.002,0.0200,0.0180,0.0160,0.0140,0.0120 } },	-- Phong V�n N�i B�ng ho�n
	{ { 7,109,1,1,-1,0 }, { 0.002,0.0200,0.0180,0.0160,0.0140,0.0120 } },	-- Phong V�n N�i H�a ho�n
	{ { 7,110,1,1,-1,0 }, { 0.002,0.0200,0.0180,0.0160,0.0140,0.0120 } },	-- Phong V�n N�i L�i ho�n
	{ { 7,111,1,1,-1,0 }, { 0.002,0.0200,0.0180,0.0160,0.0140,0.0120 } },	-- Phong V�n Tr��ng M�nh ho�n
	{ { 7,112,1,1,-1,0 }, { 0.002,0.0200,0.0180,0.0160,0.0140,0.0120 } },	-- Phong V�n Gia B�o ho�n
	{ { 7,113,1,1,-1,0 }, { 0.002,0.0200,0.0180,0.0160,0.0140,0.0120 } },	-- Phong V�n Cao Thi�m ho�n
	{ { 7,114,1,1,-1,0 }, { 0.002,0.0200,0.0180,0.0160,0.0140,0.0120 } },	-- Phong V�n Cao Trung ho�n
	{ { 7,115,1,1,-1,0 }, { 0.002,0.0200,0.0180,0.0160,0.0140,0.0120 } },	-- Phong V�n Phi T�c ho�n
	{ { 7,116,1,1,-1,0 }, { 0.002,0.0200,0.0180,0.0160,0.0140,0.0120 } },	-- Phong V�n Ph� Ph�ng ho�n
	{ { 7,117,1,1,-1,0 }, { 0.002,0.0200,0.0180,0.0160,0.0140,0.0120 } },	-- Phong V�n B�ng Ph�ng ho�n
	{ { 7,118,1,1,-1,0 }, { 0.002,0.0200,0.0180,0.0160,0.0140,0.0120 } },	-- Chuy�n d�ng cho Phong V�n L�i ph�ng ho�n
	{ { 7,119,1,1,-1,0 }, { 0.002,0.0200,0.0180,0.0160,0.0140,0.0120 } },	-- Chuy�n d�ng cho Phong V�n H�a ph�ng ho�n
	{ { 7,120,1,1,-1,0 }, { 0.002,0.0200,0.0180,0.0160,0.0140,0.0120 } },	-- Chuy�n d�ng cho Phong V�n ��c ph�ng ho�n
	{ { 7,121,1,1,-1,0 }, { 0.002,0.0200,0.0180,0.0160,0.0140,0.0360 } },	-- T�t phong ngoa 	
	{ { 7,123,1,1,-1,0 }, { 0.002,0.0200,0.0180,0.0160,0.0140,0.0360 } },	-- B�ch C�u H� uy�n	
	{ { 7,124,1,1,-1,0 }, { 0.002,0.0200,0.0180,0.0160,0.0140,0.0120 } },	-- H�u Ngh� Chi Nh�n 	
	{ { 7,125,1,1,-1,0 }, { 0.002,0.0200,0.0130,0.0160,0.0140,0.0120 } },	-- Th�n b� v�t ph�m 
	{ { 7,122,1,1,-1,0 }, { 0.002,0.0200,0.0180,0.0160,0.0140,0.0120 } },	-- Tam Thanh Chi Kh� 
	{ { 7,126,1,1,-1,0 }, { 0.003,0.0200,0.0150,0.0200,0.0200,0.0200 } },	-- B� c�u 
	{ { 7,127,1,1,-1,0 }, { 0.003,0.0200,0.0520,0.0200,0.0200,0.0200 } },	-- Kh�ng ��n Chi Gi�c 
  }
					  
NPC_RANK_DROPRATE_TABLE = { 1, 1, 2, 3, 4, 5 }

----------------------------------
--
----------------------------------
function OnDeath(nNpcIdx,nLastDamage)
	local nPlayerIndex = NpcIdx2PIdx(nLastDamage);
	PlayerIndex = nPlayerIndex;
	
	if(GetMissionV(ZBattle.tbMission.STATE) ~= ZBattle.STATE_FIGHT) then
		return
	end
	if( (PlayerIndex == nil) or (PlayerIndex == 0) ) then
		return
	end
	dropItem(nNpcIdx, nRank, PlayerIndex);
	local nCamp = GetCurCamp()
	SetTaskTemp(ZBattle.tbTaskTmp.ANTI_POST,0)
	SetTask(ZBattle.tbTask.KILL_NPC, GetTask(ZBattle.tbTask.KILL_NPC) + 1)
	if(nRank < 6) then
		SetTask(ZBattle.tbTask.NPC_POINT, GetTask(ZBattle.tbTask.NPC_POINT) + ZBattle.tbNpcPoint[nRank])
		ZBattle:AddTotalPoint(ZBattle.tbNpcPoint[nRank])
		ZBattle:AddMissionPoint(nRank, nCamp)
	elseif(nRank == 6) then -- loi tong kim chua fix
		local i = GetTaskTemp(ZBattle.tbTaskTmp.TITLE)
		local nRate = 0
		if(nCamp == 1) then
			nRate,_ = ZBattle:BonusRate()
			nRate = floor(nRate * ZBattle.BOSS_BONUS_POINT)
			Msg2MSAll(ZBattle.tbMission.MAIN,"<color=sbrown>T�ng<color> "..ZBattle.tbRankName[i][1].."<color=wood>"..GetName().." <color>�� h� g�c <color=plum>Nguy�n So�i Kim<color>.")
			SetMissionV(ZBattle.tbMission.MARSHAL_DEATH,1)
		else
			_,nRate = ZBattle:BonusRate()
			nRate = floor(nRate * ZBattle.BOSS_BONUS_POINT)
			Msg2MSAll(ZBattle.tbMission.MAIN,"<color=plum>Kim<color> "..ZBattle.tbRankName[i][1].."<color=wood>"..GetName().." <color>�� h� g�c <color=sbrown>Nguy�n So�i T�ng<color>.")
			SetMissionV(ZBattle.tbMission.MARSHAL_DEATH,2)
		end
		ZBattle:AddTotalPoint(nRate)
		ZBattle:AddMissionPoint(nRate, nCamp)
		ZBattle:UpdateTitle(0,nCamp)
		CloseMission(ZBattle.tbMission.MAIN)
		UpdateTopTKNew();
		return
	end
	SyncTask(ZBattle.tbTask.KILL_NPC)
	SyncTask(ZBattle.tbTask.NPC_POINT)
	ZBattle:UpdateTitle(0,nCamp)
	UpdateTopTKNew();
end

function OnRevive(nNpcIdx)

end;
----------------------------------
--
----------------------------------
function dropItem(nNpcIndex, nNpcRank, nBelongPlayerIdx)
	local nItemCount = getn(ITEM_DROPRATE_TABLE)
	local nMpsX, nMpsY, nSubWorldIdx = GetNpcPos(nNpcIndex)
	for nDropTimes = 1, NPC_RANK_DROPRATE_TABLE[nNpcRank] do
		local nRandNum = random();
		local nSum = 0;
		for i = 1, nItemCount do
			nSum = nSum + ITEM_DROPRATE_TABLE[i][2][nNpcRank];
			if( nSum > nRandNum ) then
				DropItem(nSubWorldIdx, nMpsX, nMpsY, nBelongPlayerIdx, ITEM_DROPRATE_TABLE[i][1][1], ITEM_DROPRATE_TABLE[i][1][2], ITEM_DROPRATE_TABLE[i][1][3], ITEM_DROPRATE_TABLE[i][1][4], ITEM_DROPRATE_TABLE[i][1][5], ITEM_DROPRATE_TABLE[i][1][6])
				break
			end
		end
	end
	-- DropItem(nSubWorldIdx, nMpsX, nMpsY, nBelongPlayerIdx, ITEM_DROPRATE_TABLE[5][1][1], ITEM_DROPRATE_TABLE[5][1][2], ITEM_DROPRATE_TABLE[5][1][3], ITEM_DROPRATE_TABLE[5][1][4], ITEM_DROPRATE_TABLE[5][1][5], ITEM_DROPRATE_TABLE[5][1][6],0)
end