----------------------------------
--	Copyright: JX Online by Kinnox
--	Author: Kinnox;
--	Date: 11/11/2021
--	Desc: Qu�n Nhu T�ng Kim
----------------------------------

----------------------------------
--
----------------------------------
function main()
	local sInfo = "H�u doanh do ta ph�c tr�ch. Ng��i c�n ta gi�p g�??"
	local tbSay = {
		"Mua thu�c./OnTrade",
		-- "Nh�n qu�n l��ng./OnGetRice.",
		"Mua 30 b�nh Ng� hoa ng�c l� ho�n[5000l]/Buyblood",
		"Kh�ng c� g� c�./OnCancel",
	}
	Say(sInfo,getn(tbSay),tbSay)
end;

----------------------------------
--
----------------------------------
function OnTrade()
	Sale(29)
end;

----------------------------------
--
----------------------------------
function OnGetRice()
	-- FindEmptyPlace(1,1)
end;
function Buyblood()
	local nNeedCash = 5000;
	local nNum = 30;
	if (GetCash() < nNeedCash) then
	 Talk(1,"","Ta �� giao th��ng ph� gi� th� tr��ng r�i, ng��i kh�ng c� �� 5000 l��ng sao?")
	return end;
	for i = 1,nNum do
		AddItem(5,8,0,5,0,0,0);
	end;
	Pay(nNeedCash);
end;
----------------------------------
--
----------------------------------
function OnCancel()
end;