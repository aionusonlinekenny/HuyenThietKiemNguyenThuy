----------------------------------
--	Copyright: JX Online by Kinnox
--	Author: Kinnox;
--	Date: 11/11/2021
--	Desc: Ng��i ch�i T�ng Kim ch�t
----------------------------------
Include("\\script\\mission\\battles\\functions.lua")

----------------------------------
--
----------------------------------
function OnDeath(nLauncher, nAttacker)
	-- Ki�m tra tr�ng th�i T�ng Kim
	if(GetMissionV(ZBattle.tbMission.STATE) ~= ZBattle.STATE_FIGHT) then
		return
	end
	-- X� l� n�u l� Npc ��nh ch�t
	if(nAttacker == nil) then
		Msg2Player("��i hi�p �� b� ��nh tr�ng th��ng, li�n tr�m v� <color=green>0<color>.")
		SetTask(ZBattle.tbTask.BE_KILL, GetTask(ZBattle.tbTask.BE_KILL) + 1)
		if(GetTask(ZBattle.tbTask.SERIES) > 0) then
			SetTask(ZBattle.tbTask.SERIES, 0) 
			SyncTask(ZBattle.tbTask.SERIES)
		end
		if(GetTask(ZBattle.tbTask.SERIES_POINT) > 0) then
			SetTask(ZBattle.tbTask.SERIES_POINT, 0) 
			SyncTask(ZBattle.tbTask.SERIES_POINT)
		end
		SetTaskTemp(ZBattle.tbTaskTmp.LAST_DEATH, GetGameTime())
		SyncTask(ZBattle.tbTask.BE_KILL)
		return
	end
	-- L�y th�ng tin ng��i ch�t
	local sDeathName = GetName()
	local nDeathCamp = GetCurCamp()
	local nDeathRank = GetTaskTemp(ZBattle.tbTaskTmp.TITLE)
	local nCurDeath  = GetTaskTemp(ZBattle.tbTaskTmp.ANTI_POST) + 1
	-- Chuy�n Idx call script cho ng��i gi�t
	PlayerIndex = nAttacker
	-- N�u c�ng Camp => l�i n�n tr� v�
	local nKillCamp = GetCurCamp()
	if(nKillCamp == nDeathCamp) then
		return
	end
	-- L�y th�ng tin ng��i gi�t
	local sKillName = GetName()
	local nKillRank = GetTaskTemp(ZBattle.tbTaskTmp.TITLE)
	local nCalcPoint  = nKillRank - nDeathRank
	local nSeriesKill = 0
	-- Ki�m tra xem c� post �i�m hay kh�ng
	if( (nCalcPoint >= 3) or (nCurDeath >= 7) ) then
		Msg2Player("��i hi�p ��nh tr�ng th��ng ��i th� qu� y�u n�n kh�ng nh�n ���c t�ch l�y.")
	else
		-- T�nh li�n tr�m
		nSeriesKill = GetTask(ZBattle.tbTask.SERIES) + 1
		SetTask(ZBattle.tbTask.SERIES, nSeriesKill)
		if( nSeriesKill > GetTask(ZBattle.tbTask.MAX_SERIES) ) then
			SetTask(ZBattle.tbTask.MAX_SERIES, nSeriesKill)
			SyncTask(ZBattle.tbTask.MAX_SERIES)
		end
		-- T�nh PK
		local nPK = GetTask(ZBattle.tbTask.KILL_ROLE) + 1
		SetTask(ZBattle.tbTask.KILL_ROLE, nPK)
		SetTaskTemp(ZBattle.tbTaskTmp.ANTI_POST,0)
		-- T�nh �i�m th��ng theo li�n tr�m
		local nPointSeries = 0
		if(mod(nSeriesKill,3) == 0) then
			nPointSeries = 15 * nSeriesKill
			if(nPointSeries >= 100) then
				nPointSeries = 100
			end
			SetTask(ZBattle.tbTask.SERIES_POINT, nPointSeries)
			SyncTask(ZBattle.tbTask.SERIES_POINT)
		end 
		-- T�nh �i�m t�ch l�y
		local nPointKill = floor(150 * (nDeathRank/nKillRank))
		local nPoint = nPointSeries + nPointKill
		ZBattle:AddTotalPoint(nPoint)
		ZBattle:AddMissionPoint(nPoint, nKillCamp)
		SetTask(ZBattle.tbTask.ROLE_POINT, GetTask(ZBattle.tbTask.ROLE_POINT) + nPoint)
		-- L�m m�i qu�n h�m
		ZBattle:UpdateTitle(0,nKillCamp)
		--
		SyncTask(ZBattle.tbTask.SERIES)
		SyncTask(ZBattle.tbTask.KILL_ROLE)
		SyncTask(ZBattle.tbTask.ROLE_POINT)
	end
	UpdateTopTKNew();
	-- Chuy�n Idx call script cho ng��i ch�t
	PlayerIndex = nLauncher
	-- C�p nh�t th�ng tin ng��i ch�t
	SetTaskTemp(ZBattle.tbTaskTmp.ANTI_POST, nCurDeath)
	SetTask(ZBattle.tbTask.BE_KILL,GetTask(ZBattle.tbTask.BE_KILL) + 1)
	if(GetTask(ZBattle.tbTask.SERIES) > 0) then
		SetTask(ZBattle.tbTask.SERIES, 0) 
		SyncTask(ZBattle.tbTask.SERIES)
	end
	if(GetTask(ZBattle.tbTask.SERIES_POINT) > 0) then
		SetTask(ZBattle.tbTask.SERIES_POINT, 0) 
		SyncTask(ZBattle.tbTask.SERIES_POINT)
	end
	SetTaskTemp(ZBattle.tbTaskTmp.LAST_DEATH, GetGameTime())
	SyncTask(ZBattle.tbTask.BE_KILL)
	-- Th�ng b�o cho ng��i ch�t
	UpdateTopTKNew();
	if( (nCalcPoint >= 3) or (nCurDeath >= 7) ) then
		Msg2Player("Ch�nh l�ch s�c m�nh qu� l�n ho�c ��i hi�p �ang c� t�nh post �i�m.")
		return
	end
	if(nKillCamp == 1) then
		Msg2Player("��i hi�p �� b� <color=sbrown>T�ng<color> "..ZBattle.tbRankName[nKillRank][1].."<color=wood>"..sKillName.." <color> ��nh tr�ng th��ng, li�n tr�m v� <color=green>0<color>.")
		if((ZBattle.tbRankName[nKillRank][1] == nil) or (sKillName == nil) or (ZBattle.tbRankName[nDeathRank][1] == nil) or (sDeathName == nil) or (nSeriesKill == nil) or (nKillCamp == nil)) then
			return
		end
		Msg2MSGroup(ZBattle.tbMission.MAIN,""..ZBattle.tbRankName[nKillRank][1].."<color=wood>"..sKillName.." <color>�� ��nh tr�ng th��ng <color=plum>Kim<color> "..ZBattle.tbRankName[nDeathRank][1].."<color=wood>"..sDeathName.." <color>��t li�n tr�m <color=green>"..nSeriesKill.."<color>.",nKillCamp)
	else
		Msg2Player("��i hi�p �� b� <color=plum>Kim<color> "..ZBattle.tbRankName[nKillRank][1].."<color=wood>"..sKillName.." <color> ��nh tr�ng th��ng, li�n tr�m v� <color=green>0<color>.")
		if((ZBattle.tbRankName[nKillRank][1] == nil) or (sKillName == nil) or (ZBattle.tbRankName[nDeathRank][1] == nil) or (sDeathName == nil) or (nSeriesKill == nil) or (nKillCamp == nil)) then
			return
		end
		Msg2MSGroup(ZBattle.tbMission.MAIN,""..ZBattle.tbRankName[nKillRank][1].."<color=wood>"..sKillName.." <color>�� ��nh tr�ng th��ng <color=sbrown>T�ng<color> "..ZBattle.tbRankName[nDeathRank][1].."<color=wood>"..sDeathName.." <color>��t li�n tr�m <color=green>"..nSeriesKill.."<color>.",nKillCamp)
	end
end