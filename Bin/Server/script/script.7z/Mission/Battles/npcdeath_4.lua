----------------------------------
--	Copyright: JX Online by Kinnox
--	Author: Kinnox;
--	Date: 11/11/2021
--	Desc: Ph� T��ng T�ng Kim ch�t
----------------------------------
nRank = 4
Include("\\script\\mission\\battles\\npcdeath.lua")