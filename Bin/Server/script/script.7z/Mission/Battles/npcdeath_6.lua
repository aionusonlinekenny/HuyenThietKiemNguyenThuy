----------------------------------
--	Copyright: JX Online by Kinnox
--	Author: Kinnox;
--	Date: 11/11/2021
--	Desc: Nguy�n So�i T�ng Kim ch�t
----------------------------------
nRank = 6
Include("\\script\\mission\\battles\\npcdeath.lua")