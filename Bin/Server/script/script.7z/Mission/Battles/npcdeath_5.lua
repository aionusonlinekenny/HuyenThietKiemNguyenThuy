----------------------------------
--	Copyright: JX Online by Kinnox
--	Author: Kinnox;
--	Date: 11/11/2021
--	Desc: ��i T��ng T�ng Kim ch�t
----------------------------------
nRank = 5
Include("\\script\\mission\\battles\\npcdeath.lua")