----------------------------------
--	Copyright: JX Online by Kinnox
--	Author: Kinnox;
--	Date: 11/11/2021
--	Desc: L�nh T�ng Kim ch�t
----------------------------------
nRank = 1
Include("\\script\\mission\\battles\\npcdeath.lua")