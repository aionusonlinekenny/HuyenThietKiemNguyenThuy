----------------------------------
--	Copyright: JX Online by Kinnox
--	Copyright: Kinnox
--	Date: 16/08/2014
--	Desc: C�ng B�nh T� (T��ng D��ng)
----------------------------------
Include("\\script\\missions\\bw\\manager.lua")