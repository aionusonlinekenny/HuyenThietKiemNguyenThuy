----------------------------------
--	Copyright: JX Online by Kinnox
--	Copyright: Kinnox
--	Date: 16/08/2014
--	Desc: Th� vi�n L�i ��i C�ng B�nh T�
----------------------------------
Include("\\script\\player\\head.lua")

--
ZBW 				= {};	-- Kh�ng ���c s�a
--
ZBW.FRAME2TIME		= 18;	-- Kh�ng ���c s�a
ZBW.TIMER_1 		= 20 * ZBW.FRAME2TIME;	-- Th�i gian ch�y bw_small.lua - M�c ��nh: 20 * 18
ZBW.TIMER_2 		= 12 * 3 * ZBW.TIMER_1;	-- Th�i gian ch�y bw_total.lua - M�c ��nh: 12 * 3 * 20 * 18
ZBW.GO_TIME 		= 6;	-- Th�i gian b�t ��u ��u - M�c ��nh: 6	
--
ZBW.SMALLTIMER		= 4;
ZBW.TOTALTIMER		= 5;
--	
ZBW.tbMission = {
	MAIN 			= 6,
	STATE 			= 1,
	TIMER			= 3,
	KEY_TEAM_1		= 4,
	KEY_TEAM_2		= 5,
	KEY				= 6,
	INDEX_GROUP1	= 6,
	INDEX_GROUP2	= 14,
	MEMBER_COUNT	= 23,
}
--
ZBW.tbTask = {
	SIGN_WORLD 	= 22,
	SIGN_POSX	= 23,
	SIGN_POSY	= 24,
	CALC_DAMAGE = 2012,
}
--
ZBW.FIGHT_MAP	= 209;	-- B�n �� chi�n ��u
ZBW.tbFightPos	= {
	{1608,3209},
	{1612,3187},
	{1604,3202},
}
ZBW.tbNpc = {
	{1599, 3202, "Tr��ng Tam"},
	{1608, 3211, "L� T�"},
}
ZBW.sNpcFile = "\\script\\mission\\bw\\transport.lua"
--
ZBW.DEATH_FILE	= "\\script\\mission\\bw\\death.lua"

----------------------------------
-- R�i kh�i tr�n ��u
----------------------------------
function ZBW:LeaveGame()
	ZPlayer:Refresh()
	RestoreOwnFeature()
	ClearDamageCounter()
	SetTask(self.SIGN_WORLD,0)
	SetTask(self.SIGN_POSX,0)
	SetTask(self.SIGN_POSY,0)
	SetTask(self.tbTask.CALC_DAMAGE,0)
	RestoreCamp()
	SetFightState(0)
	SetPunish(0)
	SetCreateTeam(1)
	ForbitTrade(0)
	ForbidChangePK(0)
	SetPKFlag(0)
	ForbidTownPortal(0)
	SetDeathScript("")
end

----------------------------------
-- R�i kh�i b�n ��
----------------------------------
function ZBW:LeaveMap()
	local nW,nX,nY = GetTask(self.tbTask.SIGN_WORLD),GetTask(self.tbTask.SIGN_POSX),GetTask(self.tbTask.SIGN_POSY)
	NewWorld(nW, nX, nY)
	RestoreOwnFeature();
	ClearStateSkill(1);
	Msg2Player("Ng�i y�n! ch�ng ta r�i kh�i ch�n giang h� tranh ��u n�y!.")
end
