----------------------------------
--	Copyright: JX Online by Kinnox
--	Copyright: Kinnox
--	Date: 16/08/2014
--	Desc: Ng��i ch�t
----------------------------------
Include("\\script\\mission\\bw\\functions.lua")

----------------------------------
--
----------------------------------
function OnDeath(nLauncher, nAttacker)
	-- N�u kh�ng ph�i l� Player gi�t
	if(nAttacker == nil) then
		return
	end
	-- Ki�m tra trang th�i l�i ��i
	if(GetMissionV(ZBW.tbMission.STATE) ~= 2) then
		return
	end
	-- L�y th�ng tin ng��i ch�t
	local nDeathCamp = GetCurCamp()
	local tbCaptainName = ZBW:GetCaptainName()
	local szDeathName = GetName()
	-- Chuy�n Idx sang cho gi�t ch�t
	PlayerIndex = nAttacker
	local szKillName = GetName()
	local nKillCamp = GetCurCamp()
	local szStr
	if( (nKillCamp == 2) or (nKillCamp == 3) ) then
		szStr = "L�i ��i t� v� �ang di�n ra, ��i <color=wood>"..tbCaptainName[nKillCamp - 1].."<color> <color=metal>"..szKillName.."<color> ��nh b�i ��i <color=wood>"..tbCaptainName[4 - nKillCamp].."<color> <color=metal>"..szDeathName.."<color>."
		Msg2MSAll(ZBW.tbMission.MAIN, szStr)
	end
	-- Chuy�n Idx cho ng��i ch�t
	PlayerIndex = nLauncher
	if(szStr ~= nil) then
		DelMSPlayer(ZBW.tbMission.MAIN, PlayerIndex)
	end
end