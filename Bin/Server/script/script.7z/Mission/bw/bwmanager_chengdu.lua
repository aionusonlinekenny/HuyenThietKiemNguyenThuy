----------------------------------
--	Copyright: JX Online by Kinnox
--	Copyright: Kinnox
--	Date: 16/08/2014
--	Desc: C�ng B�nh T� (D��ng Ch�u)
----------------------------------
Include("\\script\\missions\\bw\\manager.lua")