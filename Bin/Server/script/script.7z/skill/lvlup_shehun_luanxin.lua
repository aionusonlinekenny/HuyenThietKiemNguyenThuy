Include("\\script\\skill\\skilllvlup.lua")

function main()
	return SOSkillLevelUp.Shehun_luanxin()
end