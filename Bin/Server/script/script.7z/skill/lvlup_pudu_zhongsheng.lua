Include("\\script\\skill\\skilllvlup.lua")

function main()
	return SOSkillLevelUp.Pudu_zhongsheng()
end