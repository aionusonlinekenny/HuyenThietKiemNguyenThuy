Include("\\script\\skill\\skilllvlup.lua")

function main()
	return SOSkillLevelUp.Zuixian_cuogu()
end