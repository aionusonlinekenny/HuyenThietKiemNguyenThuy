Include("\\script\\skill\\skilllvlup.lua")

function main()
	return SOSkillLevelUp.damo_dujiang()
end