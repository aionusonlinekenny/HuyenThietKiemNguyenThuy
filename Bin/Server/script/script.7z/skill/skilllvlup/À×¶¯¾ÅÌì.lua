Include("\\script\\skill\\skilllvlup.lua")

function main()
	return SOSkillLevelUp.leidong_jiutian()
end