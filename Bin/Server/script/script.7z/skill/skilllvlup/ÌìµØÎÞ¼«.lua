Include("\\script\\skill\\skilllvlup.lua")

function main()
	return SOSkillLevelUp.tiandi_wuji()
end