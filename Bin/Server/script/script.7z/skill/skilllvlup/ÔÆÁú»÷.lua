Include("\\script\\skill\\skilllvlup.lua")

function main()
	return SOSkillLevelUp.yunlong_ji()
end