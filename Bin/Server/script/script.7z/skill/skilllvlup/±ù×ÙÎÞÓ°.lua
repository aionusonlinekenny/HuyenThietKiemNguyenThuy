Include("\\script\\skill\\skilllvlup.lua")

function main()
	return SOSkillLevelUp.bingzong_wuying()
end