Include("\\script\\skill\\skilllvlup.lua")

function main()
	return SOSkillLevelUp.bingxin_xianzi()
end