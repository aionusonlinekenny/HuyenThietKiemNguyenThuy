Include("\\script\\skill\\skilllvlup.lua")

function main()
	return SOSkillLevelUp.sane_jixue()
end