Include("\\script\\skill\\skilllvlup.lua")

function main()
	return SOSkillLevelUp.xuanyin_zhan()
end