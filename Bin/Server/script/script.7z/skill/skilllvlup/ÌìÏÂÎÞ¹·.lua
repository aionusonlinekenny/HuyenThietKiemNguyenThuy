Include("\\script\\skill\\skilllvlup.lua")

function main()
	return SOSkillLevelUp.tianxia_wugou()
end