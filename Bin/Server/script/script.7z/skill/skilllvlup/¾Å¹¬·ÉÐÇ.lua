Include("\\script\\skill\\skilllvlup.lua")

function main()
	return SOSkillLevelUp.jiugong_feixing()
end