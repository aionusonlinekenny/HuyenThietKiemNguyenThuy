Include("\\script\\skill\\skilllvlup.lua")

function main()
	return SOSkillLevelUp.potian_zhan()
end