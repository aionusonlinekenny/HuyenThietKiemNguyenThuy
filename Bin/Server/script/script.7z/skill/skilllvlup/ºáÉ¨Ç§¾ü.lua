Include("\\script\\skill\\skilllvlup.lua")

function main()
	return SOSkillLevelUp.hengsao_qianjun()
end