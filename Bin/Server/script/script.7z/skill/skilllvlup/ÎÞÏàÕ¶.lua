Include("\\script\\skill\\skilllvlup.lua")

function main()
	return SOSkillLevelUp.wuxiang_zhan()
end