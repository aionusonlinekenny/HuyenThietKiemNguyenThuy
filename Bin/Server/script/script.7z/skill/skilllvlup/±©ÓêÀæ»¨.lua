Include("\\script\\skill\\skilllvlup.lua")

function main()
	return SOSkillLevelUp.baoyu_lihua()
end