Include("\\script\\skill\\skilllvlup.lua")

function main()
	return SOSkillLevelUp.zhuifeng_jue()
end