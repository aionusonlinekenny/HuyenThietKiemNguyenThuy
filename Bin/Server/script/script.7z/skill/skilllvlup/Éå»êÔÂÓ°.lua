Include("\\script\\skill\\skilllvlup.lua")

function main()
	return SOSkillLevelUp.shehun_yueying()
end