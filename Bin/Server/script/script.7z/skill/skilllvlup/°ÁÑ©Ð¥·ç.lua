Include("\\script\\skill\\skilllvlup.lua")

function main()
	return SOSkillLevelUp.aoxue_xiaofeng()
end