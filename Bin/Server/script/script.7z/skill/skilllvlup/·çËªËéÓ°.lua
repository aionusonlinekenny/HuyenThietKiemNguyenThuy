Include("\\script\\skill\\skilllvlup.lua")

function main()
	return SOSkillLevelUp.fengshuang_suiying()
end