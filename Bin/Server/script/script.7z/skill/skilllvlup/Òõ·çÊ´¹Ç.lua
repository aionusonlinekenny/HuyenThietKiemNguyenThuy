Include("\\script\\skill\\skilllvlup.lua")

function main()
	return SOSkillLevelUp.yinfeng_shigu()
end