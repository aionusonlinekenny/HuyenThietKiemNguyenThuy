
function GetSkillLevelData(levelname, data, level)
	if (levelname == "listen_msg") then
		return "1,1800,0"
	end;
	return ""
end;

