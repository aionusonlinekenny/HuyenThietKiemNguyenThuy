Include("\\script\\skill\\skilllvlup.lua")

function main()
	return SOSkillLevelUp.Duanjin_fugu()
end