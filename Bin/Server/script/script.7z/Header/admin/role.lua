GMRole = {}
GMRole.Task = {
	EQUIP_DETAIL		= 0,
	EQUIP_PARTICULAR 	= 1,
	EQUIP_LEVEL			= 2,
	SEX_CHOOSE			= 3,
}
