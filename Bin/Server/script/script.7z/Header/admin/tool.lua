-- Author:	Scorpius
-- Date:	15-09-2015
-- 
Include("\\script\\lib\\string.lua")
Include("\\script\\lib\\func.lua")
Include("\\script\\test_tool\\role.lua")

Include("\\script\\npc\\camfire.lua")

Include("\\script\\test_tool\\equip\\horse.lua")
Include("\\script\\test_tool\\equip\\basicgold.lua")
Include("\\script\\test_tool\\char.lua")
Include("\\script\\test_tool\\hkmp\\libhkmp.lua")

Include("\\script\\event\\great_night\\head.lua")
Include("\\script\\event\\great_night\\seed_data.lua")
Include("\\script\\event\\great_night\\fruit_data.lua")
Include("\\script\\event\\great_night\\functions.lua")

----------------------------
--
----------------------------
function OnUse(nIdx)
	dofile("script/data_test/tool.lua")
	GMTools(nIdx)
end

----------------------------
--
----------------------------
function GMTools(nIdx)
	-- if(GMRole:Change2GM() == 0) then
		-- local sIP = GetIP()
		-- sIP = split(sIP,":")
		-- Talk(1,"","T�i kho�n: <color=red>"..GetAccount().."<color> Nh�n v�t: <color=yellow>"..GetName().."<color> IP: <color=green>"..sIP[1].."<color> c� mu�n b� kh�a kh�ng?")
		-- DelItemByIndex(nIdx)
		-- return
	-- end
	local nW, nX, nY = GetWorldPos()
	local sInfo = "<color=gold>H� Th�ng<color>: T�a �� hi�n t�i ["..nW.." "..nX.." "..nY.."]"
	local tbDialog = {
		"K� n�ng h� tr� t�n th�./PL_BuffSkill",
		"Li�n quan nh�n v�t./GM_Char",
		"L�y �� Ho�ng Kim./GM_GetBasicGold",
		"L�y Chi�n M�./GM_GetHorse",
		"M� C�a H�ng D��c Li�u./PL_OpenMecidine",
		"K�t th�c ��i tho�i./ExitFunc"
	}
	Say(sInfo,getn(tbDialog),tbDialog)
	-- SetFightState(0)
end

--*--
function PL_BuffSkill()
	AddSkillState(1582,1,1,60*60*18)
end

function PL_OpenMecidine()
	Sale(1)
end