----------------------------------
--	Copyright: AJX Team
--	Author: [N]
--	Date: 16/08/2014
--	Desc: Script Support Point
----------------------------------

----------------------------
--
----------------------------
function WPlayer_Point()
	local sInfo = "Xin m�i <color=fire>[ "..GetName().." ]<color> tr�i nghi�m"
	local tbSay = {
			"��ng c�p 150./PL_Level",
			"Th�ng 10 c�p [T�i �a 150]./PL_Exp",
			"1000 v�n l��ng./PL_Cash",
			"1 v�n xu./PL_Coin",
			"T�i l�nh ��o./PL_LeadLevel",
			"Danh v�ng./PL_Repute",
			"Tr� v� tr��c./main",
			"Tho�t ra./ExitFunc",
		}
	SayImage(sInfo,"-85/-85/68",getn(tbSay),tbSay)
end

----------------------------
--
----------------------------
function PL_Level()
	if(GetLevel() >= 150) then
		Talk(1,"","��ng c�p �� ��t 150")
		return
	end
	SetLevel(150)
end

----------------------------
--
----------------------------
function PL_Exp()
	local nCurLevel = GetLevel()
	if(nCurLevel >= 150) then
		Talk(1,"","��ng c�p �� ��t 120")
		return
	end
	local nNextLevel = nCurLevel + 10
	if(nNextLevel > 150) then
		nNextLevel = 150
	end
	while(GetLevel() < nNextLevel) do
		AddOwnExp(1000000)
	end
end

----------------------------
--
----------------------------
function PL_Coin()
	local nCurCoin = GetJbCoin()
	-- if(nCurCoin >= 10000) then
		-- Talk(1,"","�� c� �� 1 v�n xu")
		-- return
	-- end
	-- local nNextCoin = 10000 - nCurCoin
	for i = 1,10000 do
		AddTaskItem(19)
	end
end

----------------------------
--
----------------------------
function PL_Cash()
	local nCurCash = GetCash()
	if(nCurCash >= 10000000) then
		Talk(1,"","�� c� �� 1000 v�n l��ng")
		return
	end
	local nNextCash = 10000000 - nCurCash
	Earn(nNextCash)
end

----------------------------
--
----------------------------
function PL_LeadLevel()
	local nCurLevel = GetLeadLevel()
	if(nCurLevel >= 20) then
		Talk(1,"","T�i l�nh ��o �� �� 20 c�p")
		return
	end
	while(GetLeadLevel() < 20) do
		AddLeadExp(1000000)
	end
end

----------------------------
--
----------------------------
function PL_Repute()
	if(GetRepute() >= 300) then
		Talk(1,"","Danh v�ng �� �� 300 �i�m")
		return
	end
	AddRepute(300)
end