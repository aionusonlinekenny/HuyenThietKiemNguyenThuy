----------------------------------
--	Copyright: JX Online by Kinnox Team
--	Author: Kinnox
--	Date: 06/06/2014
--	Desc: Script GM Equip
----------------------------------

function WPlayer_Equip()
	local sInfo = " Xin m�i <color=fire>[ "..GetName().." ]<color> tr�i nghi�m"
	local tbSay = {
			"Trang b� xanh./PL_BlueEquip",
			"Chi�n m�./GM_GetHorse",
			"M�t n�./PL_Mask",
			"Trang bi Ho�ng Kim./PL_BasicGoldEquip",
			"trang b� ho�ng kim m�n ph�i c� b�n/PL_PremiumGoldEquip",
			-- "Trang b� ho�ng kim cao c�p./setselect",
			"Tr� v� tr��c./main",
			"Tho�t ra./ExitFunc",
		}
	SayImage(sInfo,"-85/-85/68",getn(tbSay),tbSay)
end

----------------------------
--
----------------------------
function PL_BlueEquip()
	local sInfo = " Xin m�i <color=fire>[ "..GetName().." ]<color> tr�i nghi�m"
	local tbSay = {
			"V� Kh�./PL_BlueEquipA",
			"Y Ph�c./PL_BlueEquipA",
			"Nh�n./PL_BlueEquipA",
			"H�ng Li�n./PL_BlueEquipA",
			"H�i T�./PL_BlueEquipA",
			"Y�u ��i./PL_BlueEquipA",
			"��nh M�o./PL_BlueEquipA",
			"H� Uy�n./PL_BlueEquipA",
			"Ng�c B�i./PL_BlueEquipA",
			"Tr� v� tr��c./WPlayer_Equip",
			"Tho�t ra./ExitFunc",
		}
	Say(sInfo,getn(tbSay),tbSay)
end

----------------------------
--
----------------------------
function PL_BlueEquipA(nSel)
	local sInfo = " Xin m�i <color=fire>[ "..GetName().." ]<color> tr�i nghi�m"
	if(nSel == 0) then
		local tbSay = {
			"Tr��ng Ki�m./PL_Weapon",
			"��n �ao./PL_Weapon",
			"C�n-B�ng./PL_Weapon",
			"Th��ng-K�ch./PL_Weapon",
			"Song Ch�y./PL_Weapon",
			"Song �ao./PL_Weapon",
			"Phi Ti�u./PL_Weapon",
			"Phi �ao./PL_Weapon",
			"T� Ti�n./PL_Weapon",
			"Tr� v� tr��c./PL_BlueEquip",
			"Tho�t ra./ExitFunc",
		}
		Say(sInfo,getn(tbSay),tbSay)
	elseif(nSel == 1) then
		local tbSay = {
			"Nam./PL_Armor",
			"N�./PL_Armor",
			"Tr� v� tr��c./PL_BlueEquip",
			"Tho�t ra./ExitFunc",
		}
		Say(sInfo,getn(tbSay),tbSay)
	elseif(nSel == 2) then
		local tbSay = {
			"C�p 1./PL_Ring",
			"C�p 2./PL_Ring",
			"C�p 3./PL_Ring",
			"C�p 4./PL_Ring",
			"C�p 5./PL_Ring",
			"C�p 6./PL_Ring",
			"C�p 7./PL_Ring",
			"C�p 8./PL_Ring",
			"C�p 9./PL_Ring",
			"C�p 10./PL_Ring",
			"Tr� v� tr��c./PL_BlueEquip",
			"Tho�t ra./ExitFunc",
		}
		Say(sInfo,getn(tbSay),tbSay)
	elseif(nSel == 3) then	
		local tbSay = {
			"Nam./PL_Amulet",
			"N�./PL_Amulet",
			"Tr� v� tr��c./PL_BlueEquip",
			"Tho�t ra./ExitFunc",
		}
		Say(sInfo,getn(tbSay),tbSay)
	elseif(nSel == 4) then	
		local tbSay = {
			"Nam./PL_Boot",
			"N�./PL_Boot",
			"Tr� v� tr��c./PL_BlueEquip",
			"Tho�t ra./ExitFunc",
		}
		Say(sInfo,getn(tbSay),tbSay)
	elseif(nSel == 5) then
		local tbSay = {
			"�ai Da./PL_Belt",
			"�ai Kim Lo�i./PL_Belt",
			"Tr� v� tr��c./PL_BlueEquip",
			"Tho�t ra./ExitFunc",
		}
		Say(sInfo,getn(tbSay),tbSay)
	elseif(nSel == 6) then	
		local tbSay = {
			"Nam./PL_Helm",
			"N�./PL_Helm",
			"Tr� v� tr��c./PL_BlueEquip",
			"Tho�t ra./ExitFunc",
		}
		Say(sInfo,getn(tbSay),tbSay)
	elseif(nSel == 7) then	
		local tbSay = {
			"Nam./PL_Cuff",
			"N�./PL_Cuff",
			"Tr� v� tr��c./PL_BlueEquip",
			"Tho�t ra./ExitFunc",
		}
		Say(sInfo,getn(tbSay),tbSay)
	elseif(nSel == 8) then	
		local tbSay = {
			"Nam./PL_Pendant",
			"N�./PL_Pendant",
			"Tr� v� tr��c./PL_BlueEquip",
			"Tho�t ra./ExitFunc",
		}
		Say(sInfo,getn(tbSay),tbSay)
	end
end

----------------------------
--
----------------------------
function PL_Weapon(nSel)
	if(nSel < 6) then
		SetTaskTemp(GMRole.Task.EQUIP_DETAIL,0)
		SetTaskTemp(GMRole.Task.EQUIP_PARTICULAR,nSel)
	else
		SetTaskTemp(GMRole.Task.EQUIP_DETAIL,1)
		SetTaskTemp(GMRole.Task.EQUIP_PARTICULAR,nSel-6)
	end
	local sInfo = " Xin m�i <color=fire>[ "..GetName().." ]<color> tr�i nghi�m"
	local tbSay = {
			"C�p 1./PL_WeaponA",
			"C�p 2./PL_WeaponA",
			"C�p 3./PL_WeaponA",
			"C�p 4./PL_WeaponA",
			"C�p 5./PL_WeaponA",
			"C�p 6./PL_WeaponA",
			"C�p 7./PL_WeaponA",
			"C�p 8./PL_WeaponA",
			"C�p 9./PL_WeaponA",
			"C�p 10./PL_WeaponA",
			"Tr� v� tr��c./PL_BlueEquipA",
			"Tho�t ra./ExitFunc",
		}
	Say(sInfo,getn(tbSay),tbSay)
end

----------------------------
--
----------------------------
function PL_WeaponA(nSel)
	SetTaskTemp(GMRole.Task.EQUIP_LEVEL, nSel + 1)
	local sInfo = " Xin m�i <color=fire>[ "..GetName().." ]<color> tr�i nghi�m"
	local tbSay = {
			"H� Kim./PL_AddEquip",
			"H� M�c./PL_AddEquip",
			"H� Th�y./PL_AddEquip",
			"H� H�a./PL_AddEquip",
			"H� Th�./PL_AddEquip",
			"Tr� v� tr��c./PL_Weapon",
			"Tho�t ra./ExitFunc",
		}
	Say(sInfo,getn(tbSay),tbSay)
end

----------------------------
--
----------------------------
function PL_Armor(nSel)
	SetTaskTemp(GMRole.Task.SEX_CHOOSE, nSel)
	local sInfo = " Xin m�i <color=fire>[ "..GetName().." ]<color> tr�i nghi�m"
	local tbSay = {
			"T�ng Y�/PL_ArmorA",
			"��o Sܕ/PL_ArmorA",
			"S�t th�/PL_ArmorA",
			"��p Trai-Xinh G�i�/PL_ArmorA",
			"Kim Gi�p�/PL_ArmorA",
			"�n M�y�/PL_ArmorA",
			"Long B�o�/PL_ArmorA",
			"Tr� v� tr��c./PL_BlueEquipA",
			"Tho�t ra./ExitFunc",
		}
	Say(sInfo,getn(tbSay),tbSay)
end

----------------------------
--
----------------------------
function PL_ArmorA(nSel)
	local nSex = GetTaskTemp(GMRole.Task.SEX_CHOOSE)
	SetTaskTemp(GMRole.Task.EQUIP_DETAIL,2)
	if(nSex == 0) then
		SetTaskTemp(GMRole.Task.EQUIP_PARTICULAR, nSel)
	else
		SetTaskTemp(GMRole.Task.EQUIP_PARTICULAR, nSel + 7)
	end
	local sInfo = " Xin m�i <color=fire>[ "..GetName().." ]<color> tr�i nghi�m"
	local tbSay = {
			"C�p 1./PL_ArmorB",
			"C�p 2./PL_ArmorB",
			"C�p 3./PL_ArmorB",
			"C�p 4./PL_ArmorB",
			"C�p 5./PL_ArmorB",
			"C�p 6./PL_ArmorB",
			"C�p 7./PL_ArmorB",
			"C�p 8./PL_ArmorB",
			"C�p 9./PL_ArmorB",
			"C�p 10./PL_ArmorB",
			"Tr� v� tr��c./PL_Armor",
			"Tho�t ra./ExitFunc",
		}
	Say(sInfo,getn(tbSay),tbSay)
end

----------------------------
--
----------------------------
function PL_ArmorB(nSel)
	SetTaskTemp(GMRole.Task.EQUIP_LEVEL, nSel + 1)
	local sInfo = " Xin m�i <color=fire>[ "..GetName().." ]<color> tr�i nghi�m"
	local tbSay = {
			"H� Kim./PL_AddEquip",
			"H� M�c./PL_AddEquip",
			"H� Th�y./PL_AddEquip",
			"H� H�a./PL_AddEquip",
			"H� Th�./PL_AddEquip",
			"Tr� v� tr��c./PL_ArmorA",
			"Tho�t ra./ExitFunc",
		}
	Say(sInfo,getn(tbSay),tbSay)
end

----------------------------
--
----------------------------
function PL_Ring(nSel)
	SetTaskTemp(GMRole.Task.EQUIP_DETAIL,3)
	SetTaskTemp(GMRole.Task.EQUIP_PARTICULAR, 0)
	SetTaskTemp(GMRole.Task.EQUIP_LEVEL, nSel + 1)
	local sInfo = " Xin m�i <color=fire>[ "..GetName().." ]<color> tr�i nghi�m"
	local tbSay = {
			"H� Kim./PL_AddEquip",
			"H� M�c./PL_AddEquip",
			"H� Th�y./PL_AddEquip",
			"H� H�a./PL_AddEquip",
			"H� Th�./PL_AddEquip",
			"Tr� v� tr��c./PL_BlueEquipA",
			"Tho�t ra./ExitFunc",
		}
	Say(sInfo,getn(tbSay),tbSay)
end

----------------------------
--
----------------------------
function PL_Amulet(nSel)
	SetTaskTemp(GMRole.Task.SEX_CHOOSE, nSel)
	local nSex = GetTaskTemp(GMRole.Task.SEX_CHOOSE)
	SetTaskTemp(GMRole.Task.EQUIP_DETAIL,4)
	if(nSex == 0) then
		SetTaskTemp(GMRole.Task.EQUIP_PARTICULAR, 1)
	else
		SetTaskTemp(GMRole.Task.EQUIP_PARTICULAR, 0)
	end
	local sInfo = " Xin m�i <color=fire>[ "..GetName().." ]<color> tr�i nghi�m"
	local tbSay = {
			"C�p 1./PL_AmuletA",
			"C�p 2./PL_AmuletA",
			"C�p 3./PL_AmuletA",
			"C�p 4./PL_AmuletA",
			"C�p 5./PL_AmuletA",
			"C�p 6./PL_AmuletA",
			"C�p 7./PL_AmuletA",
			"C�p 8./PL_AmuletA",
			"C�p 9./PL_AmuletA",
			"C�p 10./PL_AmuletA",
			"Tr� v� tr��c./PL_BlueEquipA",
			"Tho�t ra./ExitFunc",
		}
	Say(sInfo,getn(tbSay),tbSay)
end

----------------------------
--
----------------------------
function PL_AmuletA(nSel)
	SetTaskTemp(GMRole.Task.EQUIP_LEVEL, nSel + 1)
	local sInfo = " Xin m�i <color=fire>[ "..GetName().." ]<color> tr�i nghi�m"
	local tbSay = {
			"H� Kim./PL_AddEquip",
			"H� M�c./PL_AddEquip",
			"H� Th�y./PL_AddEquip",
			"H� H�a./PL_AddEquip",
			"H� Th�./PL_AddEquip",
			"Tr� v� tr��c./PL_Amulet",
			"Tho�t ra./ExitFunc",
		}
	Say(sInfo,getn(tbSay),tbSay)
end

----------------------------
--
----------------------------
function PL_Boot(nSel)
	SetTaskTemp(GMRole.Task.SEX_CHOOSE, nSel)
	local sInfo = " Xin m�i <color=fire>[ "..GetName().." ]<color> tr�i nghi�m"
	local tbSay = {
			"Gi�y C�./PL_BootA",
			"Gi�y Da./PL_BootA",
			"Tr� v� tr��c./PL_BlueEquipA",
			"Tho�t ra./ExitFunc",
		}
	Say(sInfo,getn(tbSay),tbSay)
end

----------------------------
--
----------------------------
function PL_BootA(nSel)
	local nSex = GetTaskTemp(GMRole.Task.SEX_CHOOSE)
	SetTaskTemp(GMRole.Task.EQUIP_DETAIL,5)
	if(nSex == 0) then
		SetTaskTemp(GMRole.Task.EQUIP_PARTICULAR, nSel)
	else
		SetTaskTemp(GMRole.Task.EQUIP_PARTICULAR, nSel + 2)
	end
	local sInfo = " Xin m�i <color=fire>[ "..GetName().." ]<color> tr�i nghi�m"
	local tbSay = {
			"C�p 1./PL_BootB",
			"C�p 2./PL_BootB",
			"C�p 3./PL_BootB",
			"C�p 4./PL_BootB",
			"C�p 5./PL_BootB",
			"C�p 6./PL_BootB",
			"C�p 7./PL_BootB",
			"C�p 8./PL_BootB",
			"C�p 9./PL_BootB",
			"C�p 10./PL_BootB",
			"Tr� v� tr��c./PL_Boot",
			"Tho�t ra./ExitFunc",
		}
	Say(sInfo,getn(tbSay),tbSay)
end

----------------------------
--
----------------------------
function PL_BootB(nSel)
	SetTaskTemp(GMRole.Task.EQUIP_LEVEL, nSel + 1)
	local sInfo = " Xin m�i <color=fire>[ "..GetName().." ]<color> tr�i nghi�m"
	local tbSay = {
			"H� Kim./PL_AddEquip",
			"H� M�c./PL_AddEquip",
			"H� Th�y./PL_AddEquip",
			"H� H�a./PL_AddEquip",
			"H� Th�./PL_AddEquip",
			"Tr� v� tr��c./PL_BootA",
			"Tho�t ra./ExitFunc",
		}
	Say(sInfo,getn(tbSay),tbSay)
end

----------------------------
--
----------------------------
function PL_Belt(nSel)
	SetTaskTemp(GMRole.Task.EQUIP_DETAIL,6)
	SetTaskTemp(GMRole.Task.EQUIP_PARTICULAR, nSel)
	local sInfo = " Xin m�i <color=fire>[ "..GetName().." ]<color> tr�i nghi�m"
	local tbSay = {
			"C�p 1./PL_BeltA",
			"C�p 2./PL_BeltA",
			"C�p 3./PL_BeltA",
			"C�p 4./PL_BeltA",
			"C�p 5./PL_BeltA",
			"C�p 6./PL_BeltA",
			"C�p 7./PL_BeltA",
			"C�p 8./PL_BeltA",
			"C�p 9./PL_BeltA",
			"C�p 10./PL_BeltA",
			"Tr� v� tr��c./PL_BlueEquipA",
			"Tho�t ra./ExitFunc",
		}
	Say(sInfo,getn(tbSay),tbSay)
end

----------------------------
--
----------------------------
function PL_BeltA(nSel)
	SetTaskTemp(GMRole.Task.EQUIP_LEVEL, nSel + 1)
	local sInfo = " Xin m�i <color=fire>[ "..GetName().." ]<color> tr�i nghi�m"
	local tbSay = {
			"H� Kim./PL_AddEquip",
			"H� M�c./PL_AddEquip",
			"H� Th�y./PL_AddEquip",
			"H� H�a./PL_AddEquip",
			"H� Th�./PL_AddEquip",
			"Tr� v� tr��c./PL_Belt",
			"Tho�t ra./ExitFunc",
		}
	Say(sInfo,getn(tbSay),tbSay)
end

----------------------------
--
----------------------------
function PL_Helm(nSel)
	SetTaskTemp(GMRole.Task.SEX_CHOOSE, nSel)
	local sInfo = " Xin m�i <color=fire>[ "..GetName().." ]<color> tr�i nghi�m"
	local tbSay = {
			"T�ng Y�/PL_HelmA",
			"��o Sܕ/PL_HelmA",
			"S�t th�/PL_HelmA",
			"��p Trai-Xinh G�i�/PL_HelmA",
			"Kim Gi�p�/PL_HelmA",
			"�n M�y�/PL_HelmA",
			"Long B�o�/PL_HelmA",
			"Tr� v� tr��c./PL_BlueEquipA",
			"Tho�t ra./ExitFunc",
		}
	Say(sInfo,getn(tbSay),tbSay)
end

----------------------------
--
----------------------------
function PL_HelmA(nSel)
	local nSex = GetTaskTemp(GMRole.Task.SEX_CHOOSE)
	SetTaskTemp(GMRole.Task.EQUIP_DETAIL,7)
	if(nSex == 0) then
		SetTaskTemp(GMRole.Task.EQUIP_PARTICULAR, nSel)
	else
		SetTaskTemp(GMRole.Task.EQUIP_PARTICULAR, nSel + 7)
	end
	local sInfo = " Xin m�i <color=fire>[ "..GetName().." ]<color> tr�i nghi�m"
	local tbSay = {
			"C�p 1./PL_HelmB",
			"C�p 2./PL_HelmB",
			"C�p 3./PL_HelmB",
			"C�p 4./PL_HelmB",
			"C�p 5./PL_HelmB",
			"C�p 6./PL_HelmB",
			"C�p 7./PL_HelmB",
			"C�p 8./PL_HelmB",
			"C�p 9./PL_HelmB",
			"C�p 10./PL_HelmB",
			"Tr� v� tr��c./PL_Helm",
			"Tho�t ra./ExitFunc",
		}
	Say(sInfo,getn(tbSay),tbSay)
end

----------------------------
--
----------------------------
function PL_HelmB(nSel)
	SetTaskTemp(GMRole.Task.EQUIP_LEVEL, nSel + 1)
	local sInfo = " Xin m�i <color=fire>[ "..GetName().." ]<color> tr�i nghi�m"
	local tbSay = {
			"H� Kim./PL_AddEquip",
			"H� M�c./PL_AddEquip",
			"H� Th�y./PL_AddEquip",
			"H� H�a./PL_AddEquip",
			"H� Th�./PL_AddEquip",
			"Tr� v� tr��c./PL_HelmA",
			"Tho�t ra./ExitFunc",
		}
	Say(sInfo,getn(tbSay),tbSay)
end

----------------------------
--
----------------------------
function PL_Cuff(nSel)
	SetTaskTemp(GMRole.Task.SEX_CHOOSE, nSel)
	local nSex = GetTaskTemp(GMRole.Task.SEX_CHOOSE)
	SetTaskTemp(GMRole.Task.EQUIP_DETAIL,8)
	if(nSex == 0) then
		SetTaskTemp(GMRole.Task.EQUIP_PARTICULAR, 1)
	else
		SetTaskTemp(GMRole.Task.EQUIP_PARTICULAR, 0)
	end
	local sInfo = " Xin m�i <color=fire>[ "..GetName().." ]<color> tr�i nghi�m"
	local tbSay = {
			"C�p 1./PL_CuffA",
			"C�p 2./PL_CuffA",
			"C�p 3./PL_CuffA",
			"C�p 4./PL_CuffA",
			"C�p 5./PL_CuffA",
			"C�p 6./PL_CuffA",
			"C�p 7./PL_CuffA",
			"C�p 8./PL_CuffA",
			"C�p 9./PL_CuffA",
			"C�p 10./PL_CuffA",
			"Tr� v� tr��c./PL_BlueEquipA",
			"Tho�t ra./ExitFunc",
		}
	Say(sInfo,getn(tbSay),tbSay)
end

----------------------------
--
----------------------------
function PL_CuffA(nSel)
	SetTaskTemp(GMRole.Task.EQUIP_LEVEL, nSel + 1)
	local sInfo = " Xin m�i <color=fire>[ "..GetName().." ]<color> tr�i nghi�m"
	local tbSay = {
			"H� Kim./PL_AddEquip",
			"H� M�c./PL_AddEquip",
			"H� Th�y./PL_AddEquip",
			"H� H�a./PL_AddEquip",
			"H� Th�./PL_AddEquip",
			"Tr� v� tr��c./PL_Cuff",
			"Tho�t ra./ExitFunc",
		}
	Say(sInfo,getn(tbSay),tbSay)
end

----------------------------
--
----------------------------
function PL_Pendant(nSel)
	SetTaskTemp(GMRole.Task.SEX_CHOOSE, nSel)
	local nSex = GetTaskTemp(GMRole.Task.SEX_CHOOSE)
	SetTaskTemp(GMRole.Task.EQUIP_DETAIL,9)
	if(nSex == 0) then
		SetTaskTemp(GMRole.Task.EQUIP_PARTICULAR, 1)
	else
		SetTaskTemp(GMRole.Task.EQUIP_PARTICULAR, 0)
	end
	local sInfo = " Xin m�i <color=fire>[ "..GetName().." ]<color> tr�i nghi�m"
	local tbSay = {
			"C�p 1./PL_PendantA",
			"C�p 2./PL_PendantA",
			"C�p 3./PL_PendantA",
			"C�p 4./PL_PendantA",
			"C�p 5./PL_PendantA",
			"C�p 6./PL_PendantA",
			"C�p 7./PL_PendantA",
			"C�p 8./PL_PendantA",
			"C�p 9./PL_PendantA",
			"C�p 10./PL_PendantA",
			"Tr� v� tr��c./PL_BlueEquipA",
			"Tho�t ra./ExitFunc",
		}
	Say(sInfo,getn(tbSay),tbSay)
end

----------------------------
--
----------------------------
function PL_PendantA(nSel)
	SetTaskTemp(GMRole.Task.EQUIP_LEVEL, nSel + 1)
	local sInfo = " Xin m�i <color=fire>[ "..GetName().." ]<color> tr�i nghi�m"
	local tbSay = {
			"H� Kim./PL_AddEquip",
			"H� M�c./PL_AddEquip",
			"H� Th�y./PL_AddEquip",
			"H� H�a./PL_AddEquip",
			"H� Th�./PL_AddEquip",
			"Tr� v� tr��c./PL_Pendant",
			"Tho�t ra./ExitFunc",
		}
	Say(sInfo,getn(tbSay),tbSay)
end

----------------------------
--
----------------------------
function PL_AddEquip(nSel)
	local nDetail = GetTaskTemp(GMRole.Task.EQUIP_DETAIL)
	local nParti = GetTaskTemp(GMRole.Task.EQUIP_PARTICULAR)
	local nLevel = GetTaskTemp(GMRole.Task.EQUIP_LEVEL)
	for i=1,10 do
		if(FindEmptyPlace(2,4) == 0) then
			Msg2Player("<color=green>H�nh trang kh�ng �� ch� tr�ng!<color>")
			break
		end
		AddItem(0,nDetail,nParti,nLevel,nSel,10,10)
	end
end 

----------------------------
--
----------------------------
function PL_SelHorse(nPage)
	if(type(nPage) ~= "number") then return end
	
	local sInfo = "<color=gold>H� Th�ng<color>: Xin m�i <color=fire>[ "..GetName().." ]<color> tr�i nghi�m"
	local tbSay = {
			"� V�n ��p Tuy�t�/PL_HorseA",
			"X�ch Th�/PL_HorseA",
			"Tuy�t �nh/PL_HorseA",
			"��ch L�/PL_HorseA",
			"Chi�u D� Ng�c S� T�/PL_HorseA",
			"B�n Ti�u/PL_HorseA",
			"Phi�n V�/PL_HorseA",
			"Phi V�n�/PL_HorseC",
			"X�ch Long C�u/PL_HorseC",
			"Tuy�t ��a/PL_HorseC",
			"Du Huy/PL_HorseC",
			"��ng V�/PL_HorseC",
			"Si�u Quang/PL_HorseC",
			"�H�a Tinh Kim H� V��ng�/GM_Horse_5",
			"�Kim Tinh B�ch H� V��ng�/GM_Horse_5",
			"�Long Tinh H�c H� V��ng�/GM_Horse_5",
			"�H�n Huy�t Long C�u�/GM_Horse_5",
			"�Phong V�n B�ch M��/GM_Horse_5",
			"�Phong V�n Chi�n M��/GM_Horse_5",
			"�Phong V�n Th�n M��/GM_Horse_7",
			"�S� t��/GM_Horse_7",
			"�L�c ���/GM_Horse_7",
			"�D��ng ���/GM_Horse_7",
			"�Tu�n L�c�/GM_Horse_7",
			"�D��ng Sa�/GM_Horse_7",
			
			"Trang k�/PL_HorseB",
			"Tr� v�/WPlayer_Equip",
			"Tho�t/ExitFunc",
		}
	Say(sInfo,getn(tbSay),tbSay)	
end

----------------------------
--
----------------------------
function PL_HorseA(nSel)
	local nParti = 0
	local nLevel = 0
	local nSeries = GetSeries()
	if(nSel < 5) then
		nParti = 5
		nLevel = nSel + 6
	else
		nParti = nSel + 1
		nLevel = 10
	end
	if(FindEmptyPlace(2,3) == 0) then
		Msg2Player("<color=green>H�nh trang kh�ng �� ch� tr�ng!<color>")
		return
	end
	AddItem(0,10,nParti,nLevel,nSeries,0,0)
end

----------------------------
--
----------------------------
function PL_HorseB()
	local sInfo = " Xin m�i <color=fire>[ "..GetName().." ]<color> tr�i nghi�m"
	local tbSay = {
			"Phi V�n�/PL_HorseC",
			"X�ch Long C�u/PL_HorseC",
			"Tuy�t ��a/PL_HorseC",
			"Du Huy/PL_HorseC",
			"��ng V�/PL_HorseC",
			"Si�u Quang/PL_HorseC",
			"Trang tr��c/PL_Horse",
			"Trang k�/PL_HorseD",
			"Tho�t�/ExitFunc",
		}
	Say(sInfo,getn(tbSay),tbSay)	
end

----------------------------
--
----------------------------
function PL_HorseC(nSel)
	local nParti = 0
	local nLevel = 0
	local nSeries = GetSeries()
	nParti = nSel + 8
	nLevel = 10
	AddItem(0,10,nParti,nLevel,nSeries,0,0)
end

----------------------------
--
----------------------------
function GM_Horse_4()
	local sInfo = "<color=red>H� Th�ng<color>: Xin m�i<color=green> "..GetName().." <color>l�a ch�n!"
	local tbSay = {
			"�H�a Tinh Kim H� V��ng�/GM_Horse_5",
			"�Kim Tinh B�ch H� V��ng�/GM_Horse_5",
			"�Long Tinh H�c H� V��ng�/GM_Horse_5",
			"�H�n Huy�t Long C�u�/GM_Horse_5",
			"�Phong V�n B�ch M��/GM_Horse_5",
			"�Phong V�n Chi�n M��/GM_Horse_5",
			"�Trang tr��c�/GM_Horse_2",
			"�Trang kՕ/GM_Horse_6",
			"�Tr� vҕ/GM_Equip",
			"�Tho�t�/ExitFunc",
		}
	Say(sInfo,getn(tbSay),tbSay)	
end

----------------------------
--
----------------------------
function GM_Horse_5(nSel)
	local nParti = 0
	local nLevel = 0
	local nSeries = GetSeries()
	nParti = nSel + 15
	nLevel = 10
	AddItem(0,10,nParti,nLevel,nSeries,0,0)
end

----------------------------
--
----------------------------
function GM_Horse_6()
	local sInfo = "<color=red>H� Th�ng<color>: Xin m�i<color=green> "..GetName().." <color>l�a ch�n!"
	local tbSay = {
			"�Phong V�n Th�n M��/GM_Horse_7",
			"�S� t��/GM_Horse_7",
			"�L�c ���/GM_Horse_7",
			"�D��ng ���/GM_Horse_7",
			"�Tu�n L�c�/GM_Horse_7",
			"�D��ng Sa�/GM_Horse_7",
			"�Trang tr��c�/GM_Horse_4",
			"�Trang kՕ/GM_Horse_8",
			"�Tr� vҕ/GM_Equip",
			"�Tho�t�/ExitFunc",
		}
	Say(sInfo,getn(tbSay),tbSay)	
end

----------------------------
--
----------------------------
function GM_Horse_7(nSel)
	local nParti = 0
	local nLevel = 0
	local nSeries = GetSeries()
	nParti = nSel + 21
	nLevel = 10
	AddItem(0,10,nParti,nLevel,nSeries,0,0)
end

----------------------------
--
----------------------------
function GM_Horse_8()
	local sInfo = "<color=red>H� Th�ng<color>: Xin m�i<color=green> "..GetName().." <color>l�a ch�n!"
	local tbSay = {
			"�Ng� Phong�/GM_Horse_9",
			"�Truy �i�n�/GM_Horse_9",
			"�L�u Tinh�/GM_Horse_9",
			"�Trang tr��c�/GM_Horse_6",
			"�Tr� vҕ/GM_Equip",
			"�Tho�t�/ExitFunc",
		}
	Say(sInfo,getn(tbSay),tbSay)	
end

----------------------------
--
----------------------------
function GM_Horse_9(nSel)
	local nParti = 0
	local nLevel = 0
	local nSeries = GetSeries()
	nParti = nSel + 27
	nLevel = 10
	AddItem(0,10,nParti,nLevel,nSeries,0,0)
end


----------------------------
--
----------------------------
function PL_Mask()

		AddItem(0,11,0,1,0,0,0)
		AddItem(0,11,0,2,0,0,0)
		AddItem(0,11,0,3,0,0,0)
		AddItem(0,11,0,4,0,0,0)
	
end 

----------------------------
--
----------------------------
function PL_BasicGoldEquip()
	local sInfo = " Xin m�i <color=fire>[ "..GetName().." ]<color> tr�i nghi�m"
	local tbSay = {
			"Kim phong./PL_BasicGoldEquipA",
			"An Bang./PL_BasicGoldEquipA",
			"��nh Qu�c./PL_BasicGoldEquipA",
			"Thi�n Ho�ng./PL_BasicGoldEquipA",
			"��ng S�t./PL_BasicGoldEquipA",
			"H�ng �nh./PL_BasicGoldEquipA",
			"Hi�p C�t./PL_BasicGoldEquipA",
			"Nhu T�nh./PL_BasicGoldEquipA",
			"An Bang [Ho�n M�]./PL_BasicGoldEquipA",
			"Tr� v� tr��c./WPlayer_Equip",
			"Tho�t./ExitFunc",
		}
	Say(sInfo,getn(tbSay),tbSay)
end

----------------------------
--
----------------------------
function PL_BasicGoldEquipA(nSel)

	if(nSel == 0) then
		for i=177, 185 do
			AddGoldItem(i)
		end
	elseif(nSel == 1) then
		for i=216,219 do
			AddGoldItem(i)
		end
	elseif(nSel == 2) then
		for i=398, 402 do
			AddGoldItem(i)
		end
	elseif(nSel == 3) then
		for i=168, 176 do
			AddGoldItem(i)
		end
	elseif(nSel == 4) then
		for i=143, 146 do
			AddGoldItem(i)
		end
	elseif(nSel == 5) then
		for i=204, 207 do
			AddGoldItem(i)
		end
	elseif(nSel == 6) then
		for i=186, 189 do
			AddGoldItem(i)
		end
	elseif(nSel == 7) then
		for i=190, 193 do
			AddGoldItem(i)
		end
	elseif(nSel == 8) then
		for i=210, 213 do
			AddGoldItem(i)
		end
	end
end

-- do hang kim -
function PL_PremiumGoldEquip()
	Say("<color=metal>�n M�y<color>: �i ch�! L�u l�m r�i m�i th�y Admin gh� th�m k� h�n n�y. T�nh h�nh server c� g� b�t tr�c sao?",11,
				"�� HKMP Thi�u L�m/hkmp6",
				"�� HKMP Thi�n V��ng/hkmp1",
				"�� HKMP Ng� ��c/hkmp4",
				"�� HKMP ���ng M�n/hkmp5",
				"�� HKMP Nga My/hkmp2",
				"�� HKMP Th�y Y�n/hkmp3",
				"�� HKMP Thi�n Nh�n/hkmp7",
				"�� HKMP C�i Bang/hkmp8",
				"�� HKMP V� �ang/hkmp9",
				"�� HKMP C�n L�n/hkmp10",
				"Tr� v�/no")
end

function hkmp5()
Say("Xin ch�o <color=wood>"..GetName().."<color>!",5,
"���ng M�n B�ng H�n/dm1",
"���ng M�n Ti�u L�/dm2",
"���ng M�n Bao V�/dm3",
"���ng M�n B�y/dm4",
"K�t th�c ��i tho�i/no")
end


function dm1()
	for i=71,95 do
		AddGoldItem(i)
	end
end

function dm2()
	for i=81,85 do
		AddGoldItem(i)
	end
end

function dm3()
	for i=76,80 do
		AddGoldItem(i)
	end
end

function dm4()
	for i=86,90 do
		AddGoldItem(i)
	end
end

function hkmp4()
Say("Xin ch�o <color=wood>"..GetName().."<color>!",4,
"Ng� ��c �ao/nd1",
"Ng� ��c Ch��ng /nd2",
"Ng� ��c B�a /nm3",
"K�t th�c ��i tho�i/no")
end


function nd1()
	for i=61,65 do
		AddGoldItem(i)
	end
end

function nd2()
	for i=56,60 do
		AddGoldItem(i)
	end
end

function nd3()
	for i=66,70 do
		AddGoldItem(i)
	end
end


function hkmp3()
Say("Xin ch�o <color=wood>"..GetName().."<color>!",3,
"Th�y Y�n �ao/ty1",
"Th�y Y�n S�ng �ao/ty2",
"K�t th�c ��i tho�i/no")
end


function ty1()
	for i=46,50 do
		AddGoldItem(i)
	end
end

function ty2()
	for i=51,55 do
		AddGoldItem(i)
	end
end




function hkmp2()
Say("Xin ch�o <color=wood>"..GetName().."<color>!",4,
"Nga My Ki�m/nm1",
"Nga My Ch��ng /nm2",
"Nga My Buff /nm3",
"K�t th�c ��i tho�i/no")
end


function nm1()
	for i=31,35 do
		AddGoldItem(i)
	end
end

function nm2()
	for i=36,40 do
		AddGoldItem(i)
	end
end

function nm3()
	for i=41,45 do
		AddGoldItem(i)
	end
end

function hkmp1()
Say("Xin ch�o <color=wood>"..GetName().."<color>!",4,
"Thi�n V��ng Ch�y/tv1",
"Thi�n V��ng Th��ng /tv2",
"Thi�n V��ng �ao /tv3",
"K�t th�c ��i tho�i/no")
end


function tv1()
	for i=16,20 do
		AddGoldItem(i)
	end
end

function tv2()
	for i=21,25 do
		AddGoldItem(i)
	end
end

function tv3()
	for i=26,30 do
		AddGoldItem(i)
	end
end

function hkmp6()
Say("Xin ch�o <color=wood>"..GetName().."<color>!",4,
"Thi�u L�m Quy�n/tl1",
"Thi�u L�m B�ng /tl2",
"Thi�u L�m �ao /tl3",
"K�t th�c ��i tho�i/no")
end


function tl1()
	for i=1,5 do
		AddGoldItem(i)
	end
end

function tl2()
	for i=6,10 do
		AddGoldItem(i)
	end
end

function tl3()
	for i=11,15 do
		AddGoldItem(i)
	end
end

function hkmp7()
Say("Xin ch�o <color=wood>"..GetName().."<color>!",5,
"Thi�n Nh�n S�t/boTN1",
"Thi�n Nh�n Ho�ng/boTN2",
"Thi�n Nh�n Th�/boTN3",
"K�t th�c ��i tho�i/no")
end


function boTN1()
for i=101,105 do
		AddGoldItem(i)
	end
end

function boTN2()
for i=106,110 do
		AddGoldItem(i)
	end
end

function boTN3()
for i=111,115 do
		AddGoldItem(i)
	end
end

function hkmp8()
Say("Xin ch�o <color=wood>"..GetName().."<color>!",3,
"C�i Bang R�ng/boCB1",
"C�i Bang B�ng/boCB2",
"K�t th�c ��i tho�i/no")
end


function boCB1()
for i=91,95 do
		AddGoldItem(i)
	end
end

function boCB2()
for i=96,100 do
		AddGoldItem(i)
	end
end

function hkmp9()
Say("Xin ch�o <color=wood>"..GetName().."<color>!",3,
"V� �ang Kh�/boVD1",
"V� �ang Ki�m/boVD2",
"K�t th�c ��i tho�i/no")
end

function boVD1()
for i=116,120 do
		AddGoldItem(i)
	end
end

function boVD2()
for i=121,125 do
		AddGoldItem(i)
	end
end


function hkmp10()
Say("Xin ch�o <color=wood>"..GetName().."<color>!",4,
"C�n L�n �ao/boCL1",
"Con L�n Ki�m/boCL2",
"C�n L�n Buff/boCL3",
"K�t th�c ��i tho�i/no")
end

function boCL1()
for i=126,130 do
		AddGoldItem(i)
	end
end

function boCL2()
for i=131,135 do
		AddGoldItem(i)
	end
end

function boCL3()
for i=136,140 do
		AddGoldItem(i)
	end
end