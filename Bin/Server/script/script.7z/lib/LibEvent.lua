-- Author:	Kinnox;
-- Date:	17-04-2021
-- Functions: Lib Event;
function EventVuotAi()
	AddScriptItem(128);
	--event
	--for i = 1,10 do
	--	AddScriptItem(135,30) -- hop qua su kien
	--end;
end;

function DropVuotAi()
	for i = 1,random(2,3) do
		AddTaskItem(19);
		--event
		--AddScriptItem(135,30) -- hop qua su kien
	end;
end;


function BaoRuongVuotAi()
	local nRandom = random(1,100);
	Earn(50000);
	Msg2Player("<color=green>Nh�n ���c ti�n ��ng.<color>");

	if (nRandom <= 50) then
		AddOwnExp(random(1000000,2000000));
		return 1;
	elseif (nRandom > 50 and nRandom <= 80) then
		AddTaskItem(random(35,52));
		Msg2Player("Nh�n th�nh c�ng 1 B�c ��u Thu�n M� Thu�t.");
		return 1;
	else
		for i = 1,random(1,2) do
			AddTaskItem(19);
		end;
		return 1;
	end;
	return 0;
end;

function EventTongKim()
	AddScriptItem(129);
	--for i = 1,20 do
		--event
	--	AddScriptItem(135,30) -- hop qua su kien
	--end;
end;

function BonusTongKim()
	AddScriptItem(129);
	--event
	--for i = 1,3 do
	--	AddTaskItem(63) -- la goi
	--end;
	AddOwnExp(20000000);
end;

function WinTongKim()
 	--event
	--for i = 1,5 do
	--	AddTaskItem(63) -- la goi
	--end;
	AddOwnExp(50000000);
end;

function LoseTongKim()
	--event
	--for i = 1,3 do
	--	AddTaskItem(63) -- la goi
	--end;
	AddOwnExp(30000000);
end;

function BaoRuongTongKim()
	local nRandom = random(1,100);
	if (nRandom <= 50) then
		AddOwnExp(random(1000000,2000000));
		return 1;
	elseif (nRandom > 50 and nRandom <= 70) then
		AddTaskItem(random(29,34));
		Msg2Player("Nh�n th�nh c�ng 1 m�nh trang b� h�ng �nh.");
		return 1;
	elseif 	(nRandom > 70 and nRandom <= 90) then
		AddTaskItem(random(35,52));
		Msg2Player("Nh�n th�nh c�ng 1 B�c ��u Thu�n M� Thu�t.");
		return 1;
	else
		Earn(100000);
		return 1;
	end;
	nRandom = (random(1,2));
	for i = 1,nRandom do
		AddTaskItem(19);
	end;
	Msg2Player("Nh�n ���c "..nRandom.." ti�n ��ng.");
	return 0;
end;

function EventKillerBoss()
	local nRandom = random(53,58);	
	AddTaskItem(nRandom);
	AddOwnExp(3000000);
	Msg2Player("Nh�n ���c m�t Binh ch��ng k� n�ng 120.");
	--event
	--for i = 1,5 do
	--	AddScriptItem(135,30) -- hop qua su kien
	--end;
end;

function EventBossHoangKim(nNpcIndex,nW,nX,nY,PlayerIndex,nSeries)
	AddSumExp(20000000);
	DropItem(nW,nX,nY,PlayerIndex,6,random(29,34),1,1,-1,0,0);
	DropItem(nW,nX,nY,PlayerIndex,6,random(53,58),1,1,-1,0,0);
	local nXu = random(1,3);
	for i = 1,nXu do
		DropItem(nW,nX,nY,PlayerIndex,6,19,1,1,-1,0,0);
	end;
	if (random(1,10) < 6) then
		DropItem(nW,nX,nY,PlayerIndex,7,random(11,13),1,1,-1,0,0);
		DropItem(nW,nX,nY,PlayerIndex,7,random(11,13),1,1,-1,0,0);
	else
		DropItem(nW,nX,nY,PlayerIndex,6,random(16,18),1,1,-1,0,0);
	end;
	DropRateItem(nNpcIndex,5,"\\settings\\droprate\\boss\\bosstask_lev90.ini",1,10,nSeries)
	--event
	--for i = 1,10 do
	--	AddScriptItem(135,30) -- hop qua su kien
	--end;
end;

function AddEventLoanChien()
	-- local nXu = 2;
	AddOwnExp(2000000);
	Earn(10000);
	-- for i = 1,2 do
		-- AddTaskItem(19);
	-- end;
	--event
	--for i = 1,2 do
	--	AddScriptItem(135,30) -- hop qua su kien
	--end;
end;

function EventPhongLangDo(nNpcIndex,nW,nX,nY,PlayerIndex,nSeries)
	local nXu = random(1,2);
	for i = 1,nXu do
		DropItem(nW,nX,nY,PlayerIndex,6,19,1,1,-1,0,0);
	end;
		--event
	--for i = 1,10 do
	--	AddScriptItem(135,30) -- hop qua su kien
	--end;
end;

function AddEventThienBaoKho()
	TAB_REWARD = {
--phan loai theo kind nhiem vu
--[1] money;
--[2] exp;
--[3] item;
	[1] ={{1000,12345},{2000,23456},{3000,34567},{4000,45678},{5000,56789},{5000,678919},{5000,78919},{6000,89919},{6000,99999},{5000,86914}},
	[2] ={{200000,1234560},{300000,2345670},{400000,3456780},{500000,4567890},{600000,5678990},{700000,6789100},{800000,7899100},{900000,8915100},{1000000,9999999},{2000000,9999999},},
	[3] ={
		{"Thi�t La H�n",7,1},{"Long Huy�t Ho�n",7,23},{"Thi�t La H�n",7,1},
		{"Long Huy�t Ho�n",7,23},{"B�n nh��c t�m kinh",7,24},{"Thi�t La H�n",7,1},{"Long Huy�t Ho�n",7,23},{"Thi�t La H�n",7,1},{"B�n nh��c t�m kinh",7,24},
		{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"B�n nh��c t�m kinh",7,24},{"Thi�t La H�n",7,1},{"B�n nh��c t�m kinh",7,24},{"Thi�t La H�n",7,1},
		{"X� l�i kim ��n (ti�u)",7,28},{"X� l�i kim ��n (trung)",7,29},{"X� l�i kim ��n (��i)",7,30},{"X� l�i kim ��n (ti�u)",7,28},{"X� l�i kim ��n (trung)",7,29},{"X� l�i kim ��n (��i)",7,30},
		{"X� l�i kim ��n (ti�u)",7,28},{"X� l�i kim ��n (trung)",7,29},{"H�i Long Ch�u",7,137},{"X� l�i kim ��n (ti�u)",7,28},{"X� l�i kim ��n (trung)",7,29},{"X� l�i kim ��n (��i)",7,30},
		{"Phi Phong",7,73},
		{"Thi�t La H�n",7,1},{"Ti�n Th�o L�",7,3},{"Thi�n S�n B�o L�",7,5},{"Qu� Hoa T�u",7,6},
		{"Qu� Huy Ho�ng (cao)",7,9},{"B�n Nh��c T�m Kinh",7,24},{"Ph�c Duy�n L� (ti�u)",7,11},
		{"Ph�c Duy�n L� (trung)",7,12},{"Ph�c Duy�n L� (��i)",7,13},{"Danh V�ng L�",7,72},{"Tinh H�ng B�o Th�ch",6,15},
		{"Lam Thu� Tinh",6,16},{"L�c Thu� Tinh",6,18},{"T� Thu� Tinh",6,17},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},
		{"H�i Long Ch�u",7,137},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"H�i Long Ch�u",7,137},{"Thi�t La H�n",7,1},
		{"X� l�i kim ��n (ti�u)",7,28},{"X� l�i kim ��n (trung)",7,29},{"X� l�i kim ��n (��i)",7,30},{"X� l�i kim ��n (ti�u)",7,28},{"X� l�i kim ��n (trung)",7,29},{"X� l�i kim ��n (��i)",7,30},
		{"B�n nh��c t�m kinh",7,24},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"Thi�t La H�n",7,1},{"Long Huy�t Ho�n",7,23},{"Thi�t La H�n",7,1},
		{"H�i Long Ch�u",7,137},{"Long Huy�t Ho�n",7,23},{"Thi�t La H�n",7,1},{"Long Huy�t Ho�n",7,23},{"Thi�t La H�n",7,1},{"H�i Long Ch�u",7,137},
		{"Thi�t La H�n",7,1},{"T� V� Tri�u H�i Boss HK",7,137},{"Thi�t La H�n",7,1},{"Long Huy�t Ho�n",7,23},{"Thi�t La H�n",7,1},{"T� V� Tri�u H�i Boss HK",7,137},
	},
}

	local nRandomItem = random(1,getn(TAB_REWARD[3]));
	local szName = TAB_REWARD[3][nRandomItem][1];
	local szGr = TAB_REWARD[3][nRandomItem][2];
	local szDetail = TAB_REWARD[3][nRandomItem][3];
	AddItem(szGr,szDetail,0,0,0,0,0);
end;