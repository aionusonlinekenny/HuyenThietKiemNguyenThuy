----------------------------------
--	Copyright: JxOnline by kinnox;
--	Author: kinnox
--	Date: 15/11/2021
--	Desc: Script Support Point
----------------------------------

----------------------------
--
----------------------------
function PL_Level()
	if(GetLevel() >= 150) then
		Talk(1,"","��ng c�p �� ��t 150")
		return
	end
	SetLevel(150)
end

----------------------------
--
----------------------------
function PL_Exp()
	local nCurLevel = GetLevel()
	if(nCurLevel >= 150) then
		Talk(1,"","��ng c�p �� ��t 120")
		return
	end
	local nNextLevel = nCurLevel + 10
	if(nNextLevel > 150) then
		nNextLevel = 150
	end
	while(GetLevel() < nNextLevel) do
		AddOwnExp(1000000)
	end
end

----------------------------
--
----------------------------
function PL_Coin()
	local nCurCoin = GetJbCoin()
	for i = 1,1000 do
		AddTaskItem(19)
	end
end

----------------------------
--
----------------------------
function PL_Cash()
	local nCurCash = GetCash()
	if(nCurCash >= 10000000) then
		Talk(1,"","�� c� �� 1000 v�n l��ng")
		return
	end
	local nNextCash = 10000000 - nCurCash
	Earn(nNextCash)
end

----------------------------
--
----------------------------
function PL_LeadLevel()
	local nCurLevel = GetLeadLevel()
	if(nCurLevel >= 100) then
		Talk(1,"","T�i l�nh ��o �� �� 100 c�p")
		return
	end
	while(GetLeadLevel() < 100) do
		AddLeadExp(1000000)
	end
end

----------------------------
--
----------------------------
function PL_Repute()
	if(GetRepute() >= 300) then
		Talk(1,"","Danh v�ng �� �� 300 �i�m")
		return
	end
	AddRepute(300)
end
----------------------------
--
----------------------------
function PL_Fuyuan()
	if(GetFuyuan() >= 300) then
		Talk(1,"","Ph�c duy�n �� �� 300 �i�m")
		return
	end
	AddFuyuan(300)
end