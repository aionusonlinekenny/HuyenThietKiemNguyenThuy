----------------------------------
--	Copyright: AJX Team
--	Author: [N]
--	Date: 16/08/2015
--	Desc: GM l�m vi�c
----------------------------------
Include("\\script\\player\\head.lua")
Include("\\script\\lib\\TaskLib.lua")

----------------------------------
--
----------------------------------
MAX_PLAYER = 1200;
FindFALSE = "Kh�ng t�m th�y ��i t��ng!"
function Player_Action()
	local szHello = "M�i ��i hi�p ch�n ch�c n�ng b�n d��i!"
	local szSay = {
		"T�m t�n nh�n v�t/findName",
		"T�m t�n nh�n v�t b�ng ID/findID",
		"T�m ID nh�n v�t to�n m�y ch�/findAll",
		"Tho�t/Exit"
	};
	Say(szHello,getn(szSay),szSay);

end;

function findName()
	AskClientForString("ExcuterName","",1,"32","Nh�p t�n");
end;

function ExcuterName( __, szString)
	local String = tostring(szString);
	local nPlayerIndex = PlayerIndex;
	SetTaskTemp(TMP_INDEX_ADMIN,nPlayerIndex);
	for i = 1,MAX_PLAYER do
		PlayerIndex = i;
		if (GetName() == String) then
			PlayerIndex = nPlayerIndex;
			SetTaskTemp(TMP_INDEX_PLAYER,i);
			ActionManager();
			return 0;
		end;	
	end;
	PlayerIndex = nPlayerIndex;
	Talk(1,"",FindFALSE);
end;



function findID()
	AskClientForNumber("ExcuterID",0,1200,"Nh�p ID")
end;

function ExcuterID( __, nNumber)
	local nzNumber = tonumber(nNumber);
	local nPlayerIndex = PlayerIndex;
	SetTaskTemp(TMP_INDEX_PLAYER,nzNumber);
	PlayerIndex = GetTaskTemp(TMP_INDEX_PLAYER);
	if (GetNpcIdx() > 0) then
		PlayerIndex = nPlayerIndex;	
		ActionManager();
		return 0;
	else
		PlayerIndex = nPlayerIndex;	
		Msg2Player("Nh�n v�t hi�n t�i kh�ng c� tr�n m�ng ho�c ID kh�ng ��ng");
	end;
	SetTaskTemp(TMP_INDEX_PLAYER,0);
	PlayerIndex = nPlayerIndex;
end;

function findAll()
	local szStringName;
	local szStringAcName;
	local szStringCash;
	local nPlayerIndex = PlayerIndex;
	for i = 1,MAX_PLAYER do
		PlayerIndex = i;
		if (GetNpcIdx() > 0) then
			szStringName = GetName();
			szStringAcName = GetAccount();
			szStringCash = GetCash();
			PlayerIndex = nPlayerIndex;
			 Msg2Player("INFO <color=green>[ID:"..i.."]<color> - <color=yellow>[ID:"..szStringName.."]<color> - <color=blue>[Account:"..szStringAcName.."]<color> - <color=orange>[Money:"..szStringCash.."]<color>");
			--Msg2Player("INFO <color=green>[ID:"..i.."]<color> - <color=yellow>[ID:"..szStringName.."]<color> ");
		end;
	end;
end;

function ActionManager()
	local nPlayerIndex = PlayerIndex;
	local szName;
	PlayerIndex = GetTaskTemp(TMP_INDEX_PLAYER);
		szName = GetName();
	PlayerIndex = nPlayerIndex;
	local szHello = "��i hi�p �ang thao t�c tr�n ng��i ch�i : <color=red> "..szName.." <color>"
	local szSay = {
		"Ki�m tra th�ng tin/investex",
		"Kh�a tr� chuy�n/LockTalk#1",
		"M� tr� chuy�n/LockTalk#2",
		"Di chuy�n ��n g�n ng��i ch�i/MovePlayer#1",
		"Di chuy�n ng��i ch�i ��n g�n/MovePlayer#2",
		"Di chuy�n ng��i ch�i v� Ba L�ng Huy�n/MovePlayer#3", 
		"T�ng �i�m ph�c duy�n/PointNumber#1",
		"T�ng �i�m danh v�ng/PointNumber#2",
		"T�ng �i�m t�ng kim/PointNumber#3",
		"T�ng �i�m t�i l�nh ��o/PointNumber#4",
		"T�ng VIP/PointNumber#5",
		"Kh�a t�i kho�n v�nh vi�n/BandAccount",
		"M� kh�a t�i kho�n v�nh vi�n/UnBandAccount",
		"X�a m�t kh�u r��ng/ExcuterDelPW",
		"Tho�t/Exit"
	};
	Say(szHello,getn(szSay),szSay);
end;

function LockTalk(__,nSel)
	local nSel = tonumber(nSel);
	local nPlayerIndex = PlayerIndex;
	PlayerIndex = GetTaskTemp(TMP_INDEX_PLAYER);
	if (nSel == 1) then
		Msg2SubWorld("BQT game �� b�t th�nh c�ng m�t c�i m�m th�i")
		SetChatFlag(1);
		SetTitle(324);
	else
		Msg2Player("BQT game �� tha th� cho c�i m�m th�i ng�y x�a")
		SetChatFlag(0);
		SetTitle(0);
	end;
	SetTaskTemp(TMP_INDEX_PLAYER,0);
	PlayerIndex = nPlayerIndex;
	Success();
end;

function MovePlayer( __, nSel)
	local nSel = tonumber(nSel);
	local nPlayerIndex = PlayerIndex;
	local nFight = 0;
	local nW,nX,nY;
	if (nSel == 1) then
		PlayerIndex = GetTaskTemp(TMP_INDEX_PLAYER);
		nW,nX,nY = GetWorldPos();
		nFight = GetFightState();
		PlayerIndex = nPlayerIndex;
		NewWorld(nW,nX,nY);
		SetFightState(nFight);
		SetTaskTemp(TMP_INDEX_PLAYER,0);
		Success();
	elseif (nSel == 2) then
		PlayerIndex = nPlayerIndex;
		nW,nX,nY = GetWorldPos();
		nFight = GetFightState();
		PlayerIndex = GetTaskTemp(TMP_INDEX_PLAYER);
		NewWorld(nW,nX,nY);
		SetFightState(nFight);
		PlayerIndex = nPlayerIndex;
		SetTaskTemp(TMP_INDEX_PLAYER,0);
		Success();
	else
		PlayerIndex = GetTaskTemp(TMP_INDEX_PLAYER);
		NewWorld(53,1581,3242);
		SetFightState(0);
		PlayerIndex = nPlayerIndex;
		SetTaskTemp(TMP_INDEX_PLAYER,0);
		Success();
	end;
end;

function PointNumber( _, nSel)
	local nSel = tonumber(nSel);
	local nPlayerIndex = PlayerIndex;
	local szFunc;
	if (nSel == 1) then
		szFunc = "ExcuterFuYuan";
	elseif (nSel == 2) then
		szFunc = "ExcuterRepute";
	elseif (nSel == 3) then
		szFunc = "ExcuterSongJin";
	elseif (nSel == 4) then
		szFunc = "ExcuterLeadExp";
	elseif (nSel == 5) then
		szFunc = "ExcuterVIP";	
	end;
	AskClientForNumber(szFunc,0,1200,"Nh�p �i�m");
end;

function ExcuterFuYuan( _, nNumber)
	local nNumber = tonumber(nNumber);
	local nPlayerIndex = PlayerIndex;
	PlayerIndex = GetTaskTemp(TMP_INDEX_PLAYER);
	AddFuyuan(nNumber);
	Msg2Player("Ph�c duy�n c�a ��i hi�p �� t�ng th�m: "..nNumber.." t�ng �i�m:"..GetFuyuan().." �i�m");
	PlayerIndex = nPlayerIndex;
	SetTaskTemp(TMP_INDEX_PLAYER,0);
	Success();
end;

function ExcuterRepute( _, nNumber)
	local nNumber = tonumber(nNumber);
	local nPlayerIndex = PlayerIndex;
	PlayerIndex = GetTaskTemp(TMP_INDEX_PLAYER);
	AddRepute(nNumber);
	Msg2Player("Danh v�ng c�a ��i hi�p �� t�ng th�m : "..nNumber.." t�ng �i�m:"..GetRepute().." �i�m");
	PlayerIndex = nPlayerIndex;
	SetTaskTemp(TMP_INDEX_PLAYER,0);
	Success();
end;

function ExcuterSongJin( _, nNumber)
	local nNumber = tonumber(nNumber);
	local nPlayerIndex = PlayerIndex;
	PlayerIndex = GetTaskTemp(TMP_INDEX_PLAYER);
	SetTask(2013,GetTask(2013)+nNumber);
	PlayerIndex = nPlayerIndex;
	SetTaskTemp(TMP_INDEX_PLAYER,0);
	Success();
end;

function ExcuterLeadExp( _, nNumber)
	local nNumber = tonumber(nNumber);
	local nPlayerIndex = PlayerIndex;
	PlayerIndex = GetTaskTemp(TMP_INDEX_PLAYER);
	if ((nNumber >= 100) or (nNumber <= 0) or (nNumber >= GetLeadLevel() + nNumber)) then
		PlayerIndex = nPlayerIndex;
		SetTaskTemp(TMP_INDEX_PLAYER,0);
		Msg2Player("Thao t�c th�t b�i, kh�ng th� t�ng t�i l�nh ��o cho nh�n v�t");
		return 0;
	else
		while (GetLeadLevel() < nNumber) do 
			AddLeadExp(9E6);
		end;
		PlayerIndex = nPlayerIndex;
		SetTaskTemp(TMP_INDEX_PLAYER,0);
		Success();
	end;
end;

function ExcuterVIP( _, nNumber)
	local nNumber = tonumber(nNumber);
	local nPlayerIndex = PlayerIndex;
	PlayerIndex = GetTaskTemp(TMP_INDEX_PLAYER);
	if (nNumber == 1) then
		SetTask(914,1);
	elseif (nNumber == 2) then
		SetTask(915,1);
		nIndex = AddScriptItem(15);
		SetItemBindState(nIndex,2);
		nIndex = AddScriptItem(70);
		SetItemBindState(nIndex,2);
	elseif (nNumber == 3) then
		SetTask(916,1);
		while(GetLevel() < 100) do
			AddOwnExp(1000000)
		end
		nIndex = AddScriptItem(0);
		SetItemBindState(nIndex,2);
		nIndex = AddScriptItem(0);
		SetItemBindState(nIndex,2);
		nIndex = AddScriptItem(0);
		SetItemBindState(nIndex,2);
		nIndex = AddScriptItem(2);
		SetItemBindState(nIndex,2);
		nIndex = AddScriptItem(2);
		SetItemBindState(nIndex,2);
		nIndex = AddScriptItem(2);
		SetItemBindState(nIndex,2);
		nIndex = AddScriptItem(15);
		SetItemBindState(nIndex,2);
		nIndex = AddScriptItem(16);
		SetItemBindState(nIndex,2);
		nIndex = AddScriptItem(70);
		SetItemBindState(nIndex,2);	
	end;
	Msg2Player("Ch�c m�ng ��i hi�p tr� th�nh VIP "..nNumber.." c�a m�y ch� ");
	Msg2SubWorld("Ch�c m�ng ��i hi�p <color=yellow>"..GetName().." tr� th�nh VIP "..nNumber.." <color> c�a m�y ch� ")
	PlayerIndex = nPlayerIndex;
	SetTaskTemp(TMP_INDEX_PLAYER,0);
	Success();
end;

function investex()
	local nPlayerIndex 	= PlayerIndex;
	PlayerIndex 	= GetTaskTemp(TMP_INDEX_PLAYER);
	local Name 		= GetName();
	local TK 		= GetAccount();
	local IP 		= GetIP();
	local Level 	= GetLevel();
	local Exp 		= GetExp();
	local Tien 		= GetCash();
	local Pass		= GetTask(T_PWBOX);
	local Mau 		= GetLife(0);
	local Mau2 		= GetLife(1);
	local Mana 		= GetMana(0);
	local Mana2 	= GetMana(1);
	local VLMT 		= GetTask(T_VLMT)
	local TTK 		= GetTask(T_TTK)
	local DiemPD	= GetFuyuan();
	local DiemDV	= GetRepute();
	local TienD		= GetTaskItemCount(19);
	local nW,nX,nY 	= GetWorldPos();
	local nMapName	= GetMapName(nW);
	local TongName	= GetTongName();
	PlayerIndex = nPlayerIndex;
	Talk(3,"","- T�n:<color=yellow> "..Name.." <color>\n- T�i kho�n: <color=blue>"..TK.."<color>\n- IP: <color=green>"..IP.."<color>\n- C�p: <color=fire>"..Level.."<color>, kinh nghi�m: <color=fire>"..Exp.."<color>\n- Ti�n: <color=yellow>"..Tien.."<color>",
	"- M�t kh�u r��ng: <color=yellow>"..Pass.."<color>\n- M�u: <color=fire>"..Mau.."/"..Mau2.."<color>, mana: <color=blue>"..Mana.."/"..Mana2.."<color>\n- T�a ��: <color=green>"..nMapName.." :: ("..floor(nX/8).."/"..floor(nY/16)..")<color>\n- Ph�c duy�n: <color=green>"..DiemPD.."<color>\n- Danh v�ng: <color=green>"..DiemDV.."",
	"- Ti�n ��ng: <color=fire>"..TienD.."<color>\n- VLMT: <color=fire>"..VLMT.."<color>\n- VLMT: <color=fire>"..(TTK/5).."<color>\n- T�n Bang: <color=green>"..TongName.."<color>")	
	SetTaskTemp(TMP_INDEX_PLAYER,0);
	Success();		
end

function BandAccount()
	local nPlayerIndex = PlayerIndex;
	PlayerIndex = GetTaskTemp(TMP_INDEX_PLAYER);
	Msg2SubWorld("<color=pink>BQT Game v�a c�t chim d�ng h� nh� "..GetName().." <color>.");
	BanAccount(GetAccount()); -- khoa tai khoan vinh vien;
	SetTaskTemp(TMP_INDEX_PLAYER,0);
	PlayerIndex = nPlayerIndex;
	Success();
end;

function UnBandAccount()
	local nPlayerIndex = PlayerIndex;
	PlayerIndex = GetTaskTemp(TMP_INDEX_PLAYER);
	UnBanAccount(GetAccount()); -- khoa tai khoan vinh vien;
	SetTaskTemp(TMP_INDEX_PLAYER,0);
	PlayerIndex = nPlayerIndex;
	Success();
end;

function ExcuterDelPW()
	local nPlayerIndex = PlayerIndex;
	PlayerIndex = GetTaskTemp(TMP_INDEX_PLAYER);
	DelPwbox();
	Msg2Player("Admin �� x�a m�t kh�u r��ng cho ��i hi�p!");
	PlayerIndex = nPlayerIndex;
	SetTaskTemp(TMP_INDEX_PLAYER,0);
	Success();
end;

function Exit()

end;

function Success()
	Msg2Player("�� ho�n th�nh thao t�c qu�n l� ")
end;

