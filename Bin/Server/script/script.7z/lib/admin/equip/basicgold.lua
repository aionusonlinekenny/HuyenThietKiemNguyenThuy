----------------------------------
--	Copyright: JX Online by kinnox
--	Author: kinnox
--	Date: 15/11/2021
--	Desc: Script Get Basic Gold
----------------------------------

ZBASICGOLD = {
	[1] = {
		{"Kim Phong",1,9}, 
		{"Hi�p C�t",10,13},
		{"Nhu T�nh",14,17},
		{"Thi�n Ho�ng",18,26},
		{"An Bang",27,30},
		{"��nh Qu�c",31,35},
		{"��ng S�t",36,39}, 
		{"H�ng �nh",40,43},
		{"V� Danh",53,54},
	},
}

----------------------------
--
----------------------------
function GM_GetBasicGold()
	local sInfo = "<color=gold>H� Th�ng<color>: Xin m�i <color=fire>[ "..GetName().." ]<color> tr�i nghi�m"
	local tbSay = {
		"Ho�ng Kim Th��ng./GM_GetBasicGoldA",
		"K�t th�c ��i tho�i./ExitFunc",
	}
	Say(sInfo,getn(tbSay),tbSay)
end

----------------------------
--
----------------------------
function GM_GetBasicGoldA(nType)
	if(type(nType) ~= "number") then return end
	
	nType = nType + 1
	if( (nType < 1) or (nType > getn(ZBASICGOLD))) then return end
	
	local sInfo = "<color=gold>H� Th�ng<color>: Xin m�i <color=fire>[ "..GetName().." ]<color> tr�i nghi�m"
	local tbSay = {}
	for i = 1, getn(ZBASICGOLD[nType]) do
		tinsert(tbSay, ZBASICGOLD[nType][i][1].."/GM_AddBasicGold#"..nType)
	end
	tinsert(tbSay, "Tr� v�./GM_GetBasicGold")
	tinsert(tbSay, "K�t th�c ��i tho�i./ExitFunc")
	Say(sInfo,getn(tbSay),tbSay)
end

----------------------------
--
----------------------------
function GM_AddBasicGold(nItem, nType)	
	nType = tonumber(nType)
	if(type(nType) ~= "number") then return end
	if( (nType < 1) or (nType > getn(ZBASICGOLD))) then return end
	
	if(type(nItem) ~= "number") then return end
	nItem = nItem + 1
	if( (nItem < 1) or (nItem > getn(ZBASICGOLD[nType]))) then return end
	
	for i = ZBASICGOLD[nType][nItem][2], ZBASICGOLD[nType][nItem][3] do
		AddGoldItem(i)
	end
end

function ExitFunc()

end;


















