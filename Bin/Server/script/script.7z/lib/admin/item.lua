----------------------------------
--	Copyright: JxOnline by kinnox;
--	Author: kinnox
--	Date: 15/11/2021
--	Desc: Script GM Item
----------------------------------

----------------------------
--
----------------------------
function GM_Item()
	local sInfo =  "<color=red>H� Th�ng<color>: Xin m�i<color=green> "..GetName().." <color>l�a ch�n!G�i �:\nTh�n h�nh ph�[ID:20] --- LB Phong l�ng ��[ID:12]\nSTG[ID:7->11]"
	local tbSay = {
			"Nh�n Task Item/GMTask",
			"Nh�n Script Item/GMScript",
			"Tho�t/ExitFunc",
		}
	Say(sInfo,getn(tbSay),tbSay)
end

function GMTask()
AskClientForNumber("AddTaskItems" ,0,1316,"Nh�p ID.")
end;

function AddTaskItems(nIndex,nID)
AddTaskItem(nID);
Msg2Player("C�c h� nh�n ���c v�t ph�m TaskItem "..nID.."");
end;

function GMScript()
AskClientForNumber("AddScriptItems" ,0,1316,"Nh�p ID.")
end;

function AddScriptItems(nIndex,nID)
AddScriptItem(nID);
Msg2Player("C�c h� nh�n ���c v�t ph�m ScriptsItem");
end;

function ExitFunc()
end