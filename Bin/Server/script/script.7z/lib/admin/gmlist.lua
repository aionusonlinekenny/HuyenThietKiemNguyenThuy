-- Author:	Kinnox;
-- Date:	15-04-2021
-- 
List_GM ={
 "",
 "",
 "",
}
function AddGMMagic()
	for i = 1,getn(List_GM) do
		if (i == List_GM[i]) then
			ID = 0 ;
			AddTaskItem();
		end
	end
end;