--Author: Kinnox
--Date: 17/06/2023
--Tools Name: Tremble Item
Include("\\script\\lib\\TaskLib.lua");
Tremble = {}
Tremble.Gem =
{
	{ 6, 17, 1, "T� th�y tinh" },
	{ 6, 18, 1, "L�c th�y tinh" },
	{ 6, 16, 1, "Lam th�y tinh" },
}
function TrembleTalk()
	local tbSay = {
		"N�ng c�p trang b�/upLevel",
		"��i h� trang b�/chaSeries",
		"��i thu�c t�nh trang b�/chaOption",
		"Ta ch� gh� ngang qua/no",
	};
	Say(10227,getn(tbSay),tbSay);
end;

function CoverMelee()
	local tbSay = {
		"Tr��ng ki�m/CoverItem#1",
		"Y�u �ao/CoverItem#2",
		"C�n b�ng/CoverItem#3",
		"Th��ng k�ch/CoverItem#4",
		"Song Ch�y/CoverItem#5",
		"Song �ao/CoverItem#6",
		"Phi ti�u/CoverItem#7",
		"Phi �ao/CoverItem#8",
		"T� Ti�n/CoverItem#9",
		"Ta ch� gh� ngang qua/no",
	};
	Say(10227,getn(tbSay),tbSay);
end;

function upLevel()
	OpenGiveBox("��t trang b� v�o trong","Nguy�n li�u g�m: x1 T� th�y tinh,10 v�n l��ng, x1 ti�n ��ng\n**L�u �: Ch� ��t x1 trang b� xanh v�o trong.\n**T� l�: 50%","ExcuterUpLevel")
end;

function ExcuterUpLevel()
	local nIDGem = 17; -- ID GEM
	local Cash = 100000; -- CASH
	local nTienDong = 1; -- Tien Dong
	local nType = 1;	-- Select
	local nPecent = 2;	-- 2 la 50%; 1 la 100%;
	if (ConditionUpgrade(nType,nIDGem,Cash,nTienDong,0) ~= 1) then
		return
	end

	if (LuckyPercent(nIDGem,Cash,nTienDong,nPecent) ~= 1) then
		return
	end

	ExcuterAll(nType,nIDGem,nTienDong,Cash,0)
end

function chaSeries()
	SetTaskTemp(TMP_INDEX_TREMBLE,100);
	local tbSay = {
		"H� Kim/ExCalSeries#0",
		"H� M�c/ExCalSeries#1",
		"H� Th�y/ExCalSeries#2",
		"H� H�a/ExCalSeries#3",
		"H� Th�/ExCalSeries#4",
		"Ta ch� gh� ngang qua/no",
	};
	Say(10227,getn(tbSay),tbSay);

end;

function ExCalSeries(_,nSeries)
	local nSeries = tonumber(nSeries);
	SetTaskTemp(TMP_INDEX_TREMBLE,nSeries);
	OpenGiveBox("��t trang b� v�o trong","Nguy�n li�u g�m: x1 Lam th�y tinh,10 v�n l��ng, x1 ti�n ��ng\n**L�u �: Ch� ��t x1 trang b� xanh v�o trong.\n**T� l�: 50%","ExcuterChaSeries");
end;

function ExcuterChaSeries()
	local nSeries = GetTaskTemp(TMP_INDEX_TREMBLE);
	local nIDGem = 16; -- ID GEM
	local Cash = 100000; -- CASH
	local nTienDong = 1; -- Tien Dong
	local nType = 2;	-- Select

	if (ConditionUpgrade(nType,nIDGem,Cash,nTienDong,nSeries) ~= 1) then
		return
	end

	if (LuckyPercent(nIDGem,Cash,nTienDong) ~= 1) then
		return
	end

	ExcuterAll(nType,nIDGem,nTienDong,Cash,nSeries)
end


function chaOption()
	OpenGiveBox("��t trang b� v�o trong","Nguy�n li�u g�m: x1 L�c th�y tinh,10 v�n l��ng, x1 ti�n ��ng\n**L�u �: Ch� ��t x1 trang b� xanh v�o trong.\n**T� l�: 100%","ExcuterChaOp");
end;

function ExcuterChaOp()
	local nIDGem = 18; -- ID GEM
	local Cash = 100000; -- CASH
	local nTienDong = 1; -- Tien Dong
	local nType = 3;	-- Select
	local nPecent = 1; -- 2 la 50%; 1 la 100%;
	if (ConditionUpgrade(nType,nIDGem,Cash,nTienDong,0) ~= 1) then
		return
	end
	
	if (LuckyPercent(nIDGem,Cash,nTienDong,	nPecent) ~= 1) then
		return
	end
	ExcuterAll(nType,nIDGem,nTienDong,Cash,0)
end

function ExcuterAll(nType,nIDGem,nTienDong,Cash,nSeries)
	local nItemIdx, nG, nD, nP, nL, Ser
	local i = 0;
	local ROOMG = 8; --ID MAC DINH CUA GIVE BOX
	if ROOMG ~= 8 then
	return
	end	

	for i=0,5 do
		for j=0,3 do	
			nItemIdx = GetROItem(ROOMG,i,j);	
			nG, nD, nP, nL, Ser, nLuc = GetItemProp(nItemIdx)
			if (nG ~= -1 or nD ~= -1 or nP ~= -1 or nL ~= -1 or Ser ~= -1) then
					-- up level
				if (nType == 1) then
					nRecord = nP *10 + nL;
					SetItemRecord(nItemIdx,nRecord);
					 nL = nL + 1;
					SetItemLevel(nItemIdx,nL);	
					AddItemAgain(nItemIdx);			
					if (DelMyItem(nItemIdx) ~= 0) then
						AddMyItem(nItemIdx,11,0,0);	
					end;
				elseif (nType == 2) then
					-- change series
					SetItemSeries(nItemIdx,nSeries);	
					AddItemAgain(nItemIdx);
					if (DelMyItem(nItemIdx) ~= 0) then
						AddMyItem(nItemIdx,11,0,0);	
					end;
				elseif (nType == 3) then		
					-- new option
					if (DelItemByIndex(nItemIdx) ~= 0) then
						AddItemEx(nG, nD, nP, nL, Ser, GetLucky(0),10,10,10,10,10,10,1,0,11);
					end;
				end;

				DelTaskItem(nIDGem,1);
				DelTaskItem(19,nTienDong);
				Pay(Cash);

				break;					
			end
		end
	end

end;


function ConditionUpgrade(nType,nIDGem,Cash,nTienDong,nSeries)
	local nItemIdx, nG, nD, nP, nL, Ser
	local ROOMG = 8; --ID MAC DINH CUA GIVE BOX
	local i = 0;
	if ROOMG ~= 8 then
	return
	end	
	local nCount = 0;
	for i=0,5 do
		for j=0,3 do	
			nItemIdx = GetROItem(ROOMG,i,j);	
			nG, nD, nP, nL, Ser, nLuc = GetItemProp(nItemIdx)
			if (nG ~= -1 or nD ~= -1 or nP ~= -1 or nL ~= -1 or Ser ~= -1) then
				if(GetGoldItem(nItemIdx) > 0) then
					Talk(1,"","Trang b� ho�ng kim kh�ng th� n�ng c�p!");
					return 0
				end;
				local nAttrib,_,_,_ = GetItemMagicAttrib(nItemIdx,1)
				if(nAttrib == 0) then
					Talk(1,"","Trang b� tr�ng ho�c nguy�n li�u kh�ng ��ng!");
					return 0
				end;

				if (nType == 2) then
					if (Ser == nSeries) then
						Talk(1,"","Trang b� c�ng h� kh�ng th� ti�n h�nh ��i!");
						return 0
					end;
				end;

				if (nType == 1 and nL >= 10) then
					Talk(1,"","Trang b� �� ��t ��ng c�p t�i �a, kh�ng th� n�ng c�p!");
					return 0
				end;

				nCount = nCount + 1;				
			end
		end
	end

	if (nCount > 1) then
		Talk(1,"","Ch� ��t m�t trang b� xanh c�n n�ng c�p!");
		return 0
	end;

	if (GetItemCountInBag(6,nIDGem,0,0) < 1) then
		 for i = 1,getn(Tremble.Gem) do
		 	 if (nIDGem == Tremble.Gem[i][2]) then
		 	 	Talk(1,"","Kh�ng t�m th�y "..Tremble.Gem[i][4].." trong r��ng h�nh trang!");
		 	 	break;
		 	 end;
		 end;		
		return 0
	end;

	if (GetItemCountInBag(6,19,0,0) < 1) then
		Talk(1,"","Kh�ng t�m th�y x1 ti�n ��ng trong r��ng h�nh trang!");		
		return 0
	end;

	if (GetCash() < Cash) then
		Talk(1,"","C�c h� kh�ng c� �� 10 v�n l��ng b�c trong ng��i!");
		return 0
	end;

	return 1
end;

function LuckyPercent(nIDGem,Cash,nTienDong,nPecent)
	local nRandom = random(1,nPecent)
	if (nRandom == nPecent) then
		DelTaskItem(19,nTienDong);
		DelTaskItem(nIDGem,1);
		Pay(Cash,1);
		Msg2Player("R�t ti�t ��i hi�p �� <color=blue> th�t b�i <color>, xin th� l�i!");
		return 0
	end;
	Msg2Player("Ch�c m�ng ��i hi�p �� <color=green> th�nh c�ng <color>");
	return 1
end;

function CoverItem(_,nKind)
	SetTaskTemp(TMP_INDEX_PARACOVER,0);
	SetTaskTemp(TMP_INDEX_DETAILCOVER,0);
	local nKind = tonumber(nKind);
	local nPaticular = -1;
	local nDetail 	 = -1;
	if (nKind == 1) then
		nDetail		= 0;
		nPaticular 	= 0;
	elseif(nKind == 2) then
		nDetail		= 0;
		nPaticular 	= 1;
	elseif(nKind == 3) then
		nDetail		= 0;
		nPaticular 	= 2;
	elseif(nKind == 4) then
		nDetail		= 0;
		nPaticular 	= 3;
	elseif(nKind == 5) then
		nDetail		= 0;
		nPaticular 	= 4;
	elseif(nKind == 6) then
		nDetail		= 0;
		nPaticular 	= 5;
	elseif(nKind == 7) then
		nDetail		= 1;
		nPaticular 	= 0;
	elseif(nKind == 8) then
		nDetail		= 1;
		nPaticular 	= 1;
	elseif(nKind == 9) then
		nDetail		= 1;
		nPaticular 	= 2;
	end;

	if (nPaticular < 0 or nDetail < 0) then
		return
	end;
	SetTaskTemp(TMP_INDEX_PARACOVER,nPaticular);
	SetTaskTemp(TMP_INDEX_DETAILCOVER,nDetail);
	OpenGiveBox("��t trang b� v�o trong","Nguy�n li�u g�m: 30 v�n l��ng, x10 ti�n ��ng\n**L�u �: Ch� ��t x1 trang b� xanh v�o trong.\n**T� l�: 75% th�nh c�ng","CalExcuterCover");
end;

function CalExcuterCover()
	local nCash = 300000;
	local nTienDong = 10;
	local nDetail = GetTaskTemp(TMP_INDEX_DETAILCOVER);
	local nPaticular = GetTaskTemp(TMP_INDEX_PARACOVER);

	if (ConditionCover(nPaticular,nDetail,nCash,nTienDong) ~= 1) then
		return
	end;
	if (LuckyPercentCover(Cash,nTienDong) ~= 1) then
		return
	end;

	ExcuterCoverAll(nCash,nTienDong,nDetail,nPaticular) ------DANG LAM O DAY 
end;

function ExcuterCoverAll(nCash,nTienDong,nDetail,nPaticular)
	local nItemIdx, nG, nD, nP, nL, Ser
	local i = 0;
	local ROOMG = 8; --ID MAC DINH CUA GIVE BOX
	if ROOMG ~= 8 then
	return
	end	

	for i=0,5 do
		for j=0,3 do	
			nItemIdx = GetROItem(ROOMG,i,j);	
			nG, nD, nP, nL, Ser, nLuc = GetItemProp(nItemIdx)
			if (nG ~= -1 or nD ~= -1 or nP ~= -1 or nL ~= -1 or Ser ~= -1) then
				if (nD ~= nDetail) then
					SetItemDetail(nItemIdx,nDetail);
				end;

				if (nP ~= nPaticular) then
					SetItemParticular(nItemIdx,nPaticular);
					if (nPaticular > nP) then
						Msg2Player("Recorde 1: P-"..nPaticular.." D- "..nDetail.." " ..((nL-1 + nP*10) +(nPaticular - nP)*10).."" );
						SetItemRecord(nItemIdx,(nL-1 + nP*10) +(nPaticular - nP)*10);
						AddItemAgain(nItemIdx);
					elseif (nP > nPaticular) then
						Msg2Player("Recorde 2:  P-"..nPaticular.." D- "..nDetail.." "..((nL-1 + nP*10) +(nP - nPaticular)*10).."" );
						SetItemRecord(nItemIdx,(nL-1 + nP*10) - (nP - nPaticular)*10);	
						AddItemAgain(nItemIdx);					
					end;
				end;

				if (DelMyItem(nItemIdx) ~= 0) then
					AddMyItem(nItemIdx,11,0,0);	
				end;
				DelTaskItem(19,nTienDong);
				Pay(nCash);
				break;					
			end
		end
	end

end;

function ConditionCover(nPaticular,nDetail,nCash,nTienDong)
	local nItemIdx, nG, nD, nP, nL, Ser
	local ROOMG = 8; --ID MAC DINH CUA GIVE BOX
	local i = 0;
	if ROOMG ~= 8 then
	return
	end	
	local nCount = 0;
	for i=0,5 do
		for j=0,3 do	
			nItemIdx = GetROItem(ROOMG,i,j);	
			nG, nD, nP, nL, Ser, nLuc = GetItemProp(nItemIdx)
			if (nG ~= -1 or nD ~= -1 or nP ~= -1 or nL ~= -1 or Ser ~= -1) then
				if(GetGoldItem(nItemIdx) > 0) then
					Talk(1,"","Trang b� ho�ng kim kh�ng th� n�ng c�p!");
					return 0
				end;
				local nAttrib,_,_,_ = GetItemMagicAttrib(nItemIdx,1)
				if(nAttrib == 0) then
					Talk(1,"","Trang b� tr�ng ho�c nguy�n li�u kh�ng ��ng!");
					return 0
				end;

				if(nD == nDetail and nP == nPaticular ) then
					Talk(1,"","Kh�ng th� ho�n binh c�ng lo�i trang b�!");
					return 0
				end;

				if(nD > 1) then
					Talk(1,"","Trang b� n�y kh�ng ph�i l� v� kh�!");
					return 0
				end;

				nCount = nCount + 1;				
			end
		end
	end

	if (nCount > 1) then
		Talk(1,"","Ch� ��t m�t trang b� xanh c�n n�ng c�p!");
		return 0
	end;

	if (GetItemCountInBag(6,19,0,0) < nTienDong) then
		Talk(1,"","Kh�ng t�m th�y x10 ti�n ��ng trong r��ng h�nh trang!");		
		return 0
	end;

	if (GetCash() < nCash) then
		Talk(1,"","C�c h� kh�ng c� �� 10 v�n l��ng b�c trong ng��i!");
		return 0
	end;

	return 1
end;


function LuckyPercentCover(Cash,nTienDong)
	local nRandom = random(1,2)
	if (nRandom == 2) then
		DelTaskItem(19,nTienDong);
		Pay(Cash,1);
		Msg2Player("R�t ti�t ��i hi�p �� <color=blue> th�t b�i <color>, xin th� l�i!");
		return 0
	end;
	Msg2Player("Ch�c m�ng ��i hi�p �� <color=green> th�nh c�ng <color>");
	return 1
end;


function no()

end;