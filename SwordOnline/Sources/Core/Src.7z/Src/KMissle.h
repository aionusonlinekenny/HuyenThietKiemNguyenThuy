//////////////////////////////////////////////////////////////////////
// KMissle.h: interface for the KMissle class.
//////////////////////////////////////////////////////////////////////
#ifndef	KMissleH
#define KMissleH

#ifdef  _SERVER
#define MAX_MISSLE  200000
#else
#define MAX_MISSLE 500
#endif
#include "KCore.h"
#include "SkillDef.h"
#include "KObj.h"
#ifndef _SERVER
#include "KMissleRes.h"
#endif

#include "KNode.h"
#include "KITabFile.h"
#include "KSkills.h"
#include "KNpcSet.h"
#include "Scene/ObstacleDef.h"
#include "KSubWorld.h"
#include "KIndexNode.h"
#include "GameDataDef.h"
#ifdef _SERVER
#include "KMissleMagicAttribsData.h"
#endif
enum 
{
	Interupt_None,
		Interupt_EndNewMissleWhenMove,
		Interupt_EndOldMissleLifeWhenMove,
};

#ifndef _SERVER
struct TMissleForShow
{
	int nPX ;
	int nPY ;
	int nPZ ;
	int nNpcIndex;
	int nLauncherIndex;
};
#endif

#ifndef TOOLVERSION
class KMissle
#else
class CORE_API KMissle  
#endif
{
	friend class	KSkill;
private:
public:
	KIndexNode			m_Node;
	char				m_szMissleName[30];		
	int					m_nAction;				
	BOOL				m_bIsSlow;				
	BOOL				m_bClientSend;			
	BOOL				m_bRemoving;			
	BOOL				m_bIsMelee;				
	eMissleMoveKind		m_eMoveKind;
	eMissleFollowKind	m_eFollowKind;			
	int					m_nHeight;
	int					m_nHeightSpeed;
	int					m_nLifeTime;
	int					m_nSpeed;
	int					m_nSkillId;
	BOOL				m_bRangeDamage;	
	int					m_eRelation;
	BOOL				m_bAutoExplode;
	BOOL				m_bTargetSelf;
	BOOL				m_bBaseSkill;
	BOOL				m_bByMissle;
	INT					m_nInteruptTypeWhenMove;
	BOOL				m_bHeelAtParent;
	int					m_nLauncherSrcPX;		
	int					m_nLauncherSrcPY;
	int					m_nCollideRange;
	int					m_nDamageRange;
	BOOL				m_bCollideVanish;
	BOOL				m_bCollideFriend;
	BOOL				m_bCanSlow;
	int					m_nKnockBack;
	int					m_nStunTime;
	
	BOOL				m_bFlyEvent;
	int					m_nFlyEventTime;
	BOOL				m_bSubEvent;
	BOOL				m_bStartEvent;
	BOOL				m_bCollideEvent;
	BOOL				m_bVanishedEvent;
	
	unsigned long		m_ulDamageInterval;
	BOOL				m_bMustBeHit;
	int					m_nCurrentLife;
	int					m_nStartLifeTime;
	int					m_nCollideOrVanishTime; 
	int					m_nCurrentMapX;
	int					m_nCurrentMapY;
	int					m_nCurrentMapZ;
	int					m_nXOffset;
	int					m_nYOffset;
	int					m_nRefPX;
	int					m_nRefPY;
	
	int					m_nDesMapX;
	int					m_nDesMapY;				
	int					m_nDesRegion;
	BOOL				m_bNeedReclaim;	
	TMisslePos			m_NeedReclaimPos[4];
	BOOL				m_bDoHurt;				
	int					m_nXFactor;
	int					m_nYFactor;
	int					m_nLevel;				//	���ܵȼ�
	
	int					m_nFollowNpcIdx;		
	DWORD				m_dwFollowNpcID;		
	
	int					m_nLauncher;			//	��������NpcSet�е�Index
	DWORD				m_dwLauncherId;			//	�����ߵ�ΨһID
	int					m_nParentMissleIndex;   // if 0 then means parent is npclauncher	
	int					m_nCurrentSpeed;		//	��ǰ�ٶȣ����ܱ����٣�
	int					m_nZAcceleration;		//	Z��ļ��ٶ�
	eMissleStatus		m_eMissleStatus;		//	�ӵ���ǰ��״̬
	int					m_nMissleId;			//	�ӵ���Missle�е�ID
	int					m_nSubWorldId;			//	������ID
	int					m_nRegionId;			//	����ID
	int					m_nMaxDamage;			//	����˺�
	int					m_nElementType;			//	Ԫ���˺�����
	int					m_nMaxElementDamage;	//	���Ԫ���˺�(�״�)
	int					m_nElementTime;			//	Ԫ�س���ʱ��
	int					m_nElementInterval;		//	Ԫ�ؼ��ʱ��
	int					m_nElementPerDamage;	//	Ԫ���˺�ʱ��ÿ�η������ܵ��˺�ֵ
	int					m_nParam1;				//	����һ
	int					m_nParam2;				//	������
	int					m_nParam3;				//	������
	int					m_nFirstReclaimTime;
	int					m_nEndReclaimTime;
	int					m_nTempParam1;			//	������ʹ�õĲ���
	int					m_nTempParam2;
	int					m_nDirIndex;			
	int					m_nDir;					
	int					m_nAngle;				
	DWORD				m_dwBornTime;			
	BOOL				m_bUseAttackRating;	
	BYTE				m_btMissRate;
	BYTE				m_btHitCount;
	int					m_nLastDoCollisionIdx;// fix skills con lon dao	
#ifdef _SERVER
	unsigned long		m_ulNextCalDamageTime;
	BYTE				m_btRandomParam;
#endif

#ifndef _SERVER
	BOOL				m_bMultiShow;			//	�ӵ���������ʾ
	BOOL				m_bFollowNpcWhenCollid; //	��ըЧ�����汻���е�����
	int					m_btRedLum;
	int					m_btGreenLum;
	int					m_btBlueLum;
	unsigned short		m_usLightRadius;
	KMissleRes			m_MissleRes;			//	�ӵ�����Դ
	unsigned int		m_SceneID;
#endif
	
	
private:
	BOOL				Init( int nLauncher, int nMissleId, int nXFactor, int nYFactor, int nLevel);
	void				OnVanish();//������ʧ
	void				OnCollision();//��ײ
	void				OnFly();//���й�����
	void				OnWait();
	void				DoWait();
	void				DoFly();
	BOOL				PrePareFly();
	void				DoVanish();
	void				DoCollision();
	int					CheckNearestCollision();
	int					FindNearestCollision(int nLauncher, int nRelation);
	friend				class KMissleSet;
	void				Release();
	int					CheckCollision();//����Ƿ���ײ// 1��ʾ������ײ�����壬0��ʾδ��ײ���κ�����, -1��ʾ���
	BOOL				CheckBeyondRegion(int nDOffsetX, int nDOffsetY);//����Ƿ�Խ��   //FALSE��ʾԽ��һ����Ч��λ�ã�TRUE��ʾOK
	int					GetDir(int dx,int dy);
	KMissle&			operator=(KMissle& Missle);
	DWORD				GetCurrentSubWorldTime();
	BOOL				ProcessDamage(int nNpcId);
	int					ProcessCollision();//������ײ
	int					ProcessCollision(int nLauncherIdx, int nRegionId, int nMapX, int nMapY, int nRange , int eRelation);

	inline void	ZAxisMove()
	{
		if (m_nZAcceleration)
		{
			m_nHeight += m_nHeightSpeed;
			if (m_nHeight < 0) m_nHeight = 0;
			m_nHeightSpeed -= m_nZAcceleration;
			m_nCurrentMapZ = m_nHeight >> 10;
		}
	}
	//TRUE��ʾ�����ϰ���FALSE��ʾδ������һ������
	inline BOOL TestBarrier()
	{
		int nBarrierKind = SubWorld[m_nSubWorldId].TestBarrier(m_nRegionId, m_nCurrentMapX, m_nCurrentMapY, m_nXOffset, m_nYOffset, 0, 0);
		if (nBarrierKind == Obstacle_Normal || nBarrierKind == Obstacle_Jump)
		{
			
			return TRUE;
		}
		return FALSE;
	}
	
public:	
	KMissle();
	virtual ~KMissle();
	BOOL				GetInfoFromTabFile(int nMissleId);
	BOOL				GetInfoFromTabFile(KITabFile * pTabFile, int nMissleId);
	void				GetMpsPos(int *pPosX, int *pPosY);
	int					Activate();
static	BOOL			GetOffsetAxis(int nSubWorld, int nSrcRegionId, int nSrcMapX, int nSrcMapY,
							int nOffsetMapX, int nOffsetMapY, 
							int &nDesRegionId, int &nDesMapX, int &nDesMapY);
	
#ifdef _SERVER
	KMissleMagicAttribsData * m_pMagicAttribsData;
	int					SetMagicAttribsData(KMissleMagicAttribsData * pData)
	{
		m_pMagicAttribsData = pData;
		if (pData)
			return pData->AddRef();
		else 
			return 0;
	};
#endif

#ifndef _SERVER
	void				Paint();
	void				GetLightInfo(KLightInfo * pLightInfo);
	BOOL				CreateSpecialEffect(eMissleStatus eStatus,  int nPX, int nPY, int nPZ, int nNpcIndex = 0);
	static BOOL				CreateMissleForShow(char * szMovie, char * szSprInfo, char * szSound, TMissleForShow * pShowParam);
#endif //_SERVER
	
};


extern CORE_API KMissle			Missle[MAX_MISSLE];
extern CORE_API KMissle			g_MisslesLib[MAX_MISSLESTYLE];//Base 1
#endif
