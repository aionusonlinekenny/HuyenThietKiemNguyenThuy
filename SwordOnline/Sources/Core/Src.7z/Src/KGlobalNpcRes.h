#ifndef KGlobalNpcResH
#define	KGlobalNpcResH

class KGlobalNpcRes
{
	
};

#endif //KGlobalNpcResH
