#include "KCore.h"
#include "KGlobalNpcRes.h"

KGlobalNpcRes g_NpcResSetting;

