// --
// Sword3 Engine (c) 1999-2000 by Kingsoft
//
// File:	KClientNpc.cpp
// Date:	2003.03.06
// Code:	�߳�����
// Desc:	ClientNpc Class
// --

#ifndef _SERVER

#include "KCore.h"
#include "KSubWorld.h"
#include "KClientNpc.h"



#endif