#include "KCore.h"
/*
int				KPartnerSkill::GetSkillId()
{

}

const char *	KPartnerSkill::GetSkillName()
{

}

int				KPartnerSkill::GetSkillStyle()
{

}

void			KPartnerSkill::LoadSkillLevelData(unsigned long  ulLevel, int nParam)
{

}

BOOL			KPartnerSkill::Cast(int nLauncher,  int nParam1, int nParam2)
{


}

BOOL			KPartnerSkill::InitSkill()
{
	
}
*/