/*****************************************************************************************
//	������Ϣ������
//	Copyright : Kingsoft 2003
//	Author	:   Wooy(Wu yue)
//	CreateTime:	2002-1-10
// --
*****************************************************************************************/

#ifndef MSGGENREDEF_H
#define MSGGENREDEF_H

enum MSG_GENRE_LIST
{
	MSG_G_CHAT = 0,
	MSG_G_CMD,		
};
#endif
