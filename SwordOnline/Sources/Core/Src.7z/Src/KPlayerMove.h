#ifndef KAUTOFINDPATH_H
#define KAUTOFINDPATH_H

#ifndef _SERVER
#include "scene/KScenePlaceC.h"

#endif
#endif


