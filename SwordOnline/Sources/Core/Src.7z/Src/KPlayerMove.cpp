#include	"KCore.h"

#ifndef _SERVER
#include	"KPlayerMove.h"

#endif
